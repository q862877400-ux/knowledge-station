import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: './',
  build: { outDir: 'dist' },
  server: {
    host: '127.0.0.1',
    // 仓库内的 SQLite 快照/测试库会被引擎或测试进程锁住，vite 文件监听撞 EBUSY 直接崩——
    // 排除数据类目录（var/eval/wenjianmulu 用户文档目录）与 .db/.sqlite 文件
    // （历史坑：eval/golden/knowledge-snapshot.db、wenjianmulu/*.pdf 锁死 dev server）
    watch: { ignored: ['**/eval/**', '**/var/**', '**/wenjianmulu/**', '**/node_modules/**', '**/*.db', '**/*.sqlite', '**/*.zstd'] },
  },
});
