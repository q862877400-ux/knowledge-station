"""T00 契约冒烟测试：模型可实例化、SSE 事件与通道枚举冻结、DDL 可执行。"""
import pytest

from src.core.domain.models import (
    SSE_EVENT_ORDER, SEARCH_CHANNELS, MODALITY_STRENGTH,
    ClauseRevisionModel, DocumentMetaModel, EvidenceEdgeModel, ModalityViolation,
    PageGeometryModel, ReviewPointModel, SourceSpanModel, VerificationResult,
)


def test_sse_event_order_frozen():
    assert SSE_EVENT_ORDER == ["evidence", "status", "delta", "verification", "done"]


def test_search_channels_frozen():
    assert SEARCH_CHANNELS == [
        "exact", "fts", "vec", "modality", "legal_element", "behavior_scope"]


def test_modality_strength_dict_frozen():
    assert MODALITY_STRENGTH["严禁"] == 5
    assert MODALITY_STRENGTH["不得"] == 4
    assert MODALITY_STRENGTH["应"] == 3
    assert MODALITY_STRENGTH["宜"] == 2
    assert MODALITY_STRENGTH["可以"] == 1
    assert MODALITY_STRENGTH["鼓励"] == 0


def test_models_instantiate():
    span = SourceSpanModel(span_id="s1", page_number=3, bbox=[72.0, 310.5, 520.0, 395.2])
    geo = PageGeometryModel(page_number=3, width=595, height=842, rotation=90,
                            crop_box=[0, 0, 595, 842], media_box=[0, 0, 612, 792])
    clause = ClauseRevisionModel(
        clause_revision_id="clrev_1", doc_id="doc_1", clause_key="k" * 24,
        standard_no="GB 50016-2022", clause_number="5.2.3", content_text="防火间距不应小于13m",
        knowledge_type="rule", modality="不应", modality_strength=4,
        page_start=42, page_end=42, source_spans=[span])
    assert clause.modality_strength == 4
    assert geo.rotation == 90
    doc = DocumentMetaModel(
        doc_id="doc_1", standard_no="GB 50016-2022", standard_name="建筑设计防火规范",
        short_code="GB50016", current_revision_id="r1", legal_status="effective",
        file_path="x.pdf", file_hash="h" * 64)
    edge = EvidenceEdgeModel(edge_id="e1", edge_type="exception_relation",
                             source_clause_id="a", target_clause_id="b")
    point = ReviewPointModel(point_id="p1", task_id="t1", point_type="违约金条款",
                             point_content="违约金30%", verdict="yellow", verdict_reason="过高")
    viol = ModalityViolation(clause_revision_id="clrev_1", source_modality="应",
                             output_modality="宜", source_strength=3, output_strength=2,
                             violation_type="modality_weakened")
    result = VerificationResult(is_valid=False, modality_violations=[viol])
    assert not result.is_valid


def test_invalid_knowledge_type_rejected():
    with pytest.raises(Exception):
        ClauseRevisionModel(
            clause_revision_id="x", doc_id="d", clause_key="k", standard_no="s",
            clause_number="1", content_text="t", knowledge_type="bogus",
            page_start=1, page_end=1)


def test_schema_all_tables(db):
    from src.core.storage.sqlite_db import list_tables
    tables = set(list_tables())
    expected = {
        "doc_meta", "doc_page_geometry", "clause_revision", "source_span",
        "clause_fts", "clause_vec", "alias_store", "evidence_edge",
        "user_bookmark", "user_annotation", "project_list", "review_task",
        "review_point", "obligation_list", "gap_analysis", "legal_obligation",
        "internal_policy", "app_config", "write_queue", "event_log", "debug_dump",
        "remapping_queue", "snapshot_meta", "operation_log", "audit_log",
        "feedback_log", "watch_list", "clause_patch",
    }
    missing = expected - tables
    assert not missing, f"缺少表: {missing}"


def test_egress_audit_contract(db):
    """Task 10.0 契约（v5 红线 #4 外发可审计）：debug_dump 必须承载外发审计所需字段。"""
    cols = {r[1] for r in db.execute("PRAGMA table_info(debug_dump)").fetchall()}
    required = {"dump_id", "trigger_type", "query", "prompt",
                "llm_output", "verification_result", "logs", "created_at"}
    missing = required - cols
    assert not missing, f"debug_dump 缺审计字段: {missing}"
    # 统一登记入口必须存在（后续 rerank/VLM/云解析共用）
    from src.core.llm import egress_audit
    assert callable(getattr(egress_audit, "record_egress", None))
    assert callable(getattr(egress_audit, "query_egress", None))


# ===== 更新模块数据契约（阶段三，契约先行：先改本文件再动 schema） =====


def test_update_tables_exist(db):
    """29/30 号表存在性（pipeline/02 §2 数据契约增量）。"""
    from src.core.storage.sqlite_db import list_tables
    tables = set(list_tables())
    for name in ("update_check_batch", "update_change_event"):
        assert name in tables, f"缺少更新模块契约表: {name}"


def test_update_tables_ulid_pk_style(db):
    """29/30 表主键为 ULID 风格 TEXT 主键，DDL 注释声明 upd_/chg_ 前缀。"""
    from pathlib import Path
    import src.core.storage.sqlite_db as sqlite_db_mod
    ddl = Path(sqlite_db_mod.__file__).with_name("schema.sql").read_text(encoding="utf-8")
    assert "-- ULID 前缀 upd_" in ddl, "update_check_batch 主键缺 ULID 前缀注释"
    assert "-- ULID 前缀 chg_" in ddl, "update_change_event 主键缺 ULID 前缀注释"
    for table, pk in (("update_check_batch", "batch_id"),
                      ("update_change_event", "change_id")):
        info = {r["name"]: r for r in db.execute(f"PRAGMA table_info({table})").fetchall()}
        col = info[pk]
        assert col["pk"] == 1 and col["type"] == "TEXT", f"{table} 主键须为 TEXT ULID 风格"


def test_update_batch_check_enums(db):
    """update_check_batch：trigger_type 二枚举、status 五枚举 CHECK。"""
    import sqlite3
    db.execute("INSERT INTO update_check_batch(batch_id, trigger_type, status)"
               " VALUES('upd_ct_01', 'manual', 'running')")
    db.execute("INSERT INTO update_check_batch(batch_id, trigger_type)"
               " VALUES('upd_ct_02', 'scheduled')")  # status 走缺省
    assert db.execute("SELECT status FROM update_check_batch WHERE batch_id='upd_ct_02'"
                      ).fetchone()[0] == "pending"
    with pytest.raises(sqlite3.IntegrityError):
        db.execute("INSERT INTO update_check_batch(batch_id, trigger_type)"
                   " VALUES('upd_ct_bad1', 'auto')")
    with pytest.raises(sqlite3.IntegrityError):
        db.execute("INSERT INTO update_check_batch(batch_id, trigger_type, status)"
                   " VALUES('upd_ct_bad2', 'manual', 'canceled')")


def test_update_event_change_type_enum(db):
    """update_change_event：change_type 恰好五枚举。"""
    import sqlite3
    sql = ("INSERT INTO update_change_event(change_id, batch_id, standard_no,"
           " change_type, source_channel) VALUES(?, 'upd_ev_01', 'GB 50016-2022', ?, 'official_gb')")
    db.execute("INSERT INTO update_check_batch(batch_id) VALUES('upd_ev_01')")
    for i, ct in enumerate(("new_version", "superseded",
                            "withdrawn", "not_found", "no_change")):
        db.execute(sql, (f"chg_ev_{i}", ct))
    with pytest.raises(sqlite3.IntegrityError):
        db.execute(sql, ("chg_ev_bad", "renamed"))


def test_update_event_legal_status_and_nullable_doc(db):
    """current_legal_status 四枚举且可空；doc_id 可空（公告命中但库内无文档）。"""
    import sqlite3
    sql = ("INSERT INTO update_change_event(change_id, batch_id, standard_no,"
           " change_type, current_legal_status, source_channel)"
           " VALUES(?, 'upd_ls_01', 'GB/T 1234-2020', 'new_version', ?, 'govcn')")
    db.execute("INSERT INTO update_check_batch(batch_id) VALUES('upd_ls_01')")
    for i, st in enumerate(("effective", "upcoming", "superseded", "withdrawn")):
        db.execute(sql, (f"chg_ls_{i}", st))
    # 显式 NULL 与缺省两种写法都必须放行（公告命中但库内无文档 → doc_id 为 NULL）
    db.execute(sql, ("chg_ls_null", None))
    db.execute("INSERT INTO update_change_event(change_id, batch_id, standard_no,"
               " change_type, source_channel)"
               " VALUES('chg_ls_default', 'upd_ls_01', 'GB 9999-2019', 'not_found', 'web')")
    # 非空路径同样合法（库内命中文档时回填）
    db.execute("INSERT INTO update_change_event(change_id, batch_id, standard_no,"
               " doc_id, change_type, current_legal_status, source_channel)"
               " VALUES('chg_ls_hit', 'upd_ls_01', 'GB/T 1234-2020', 'doc_ls_hit',"
               " 'new_version', 'superseded', 'laws_db')")
    total = db.execute("SELECT count(*) FROM update_change_event"
                       " WHERE batch_id='upd_ls_01'").fetchone()[0]
    null_doc = db.execute("SELECT count(*) FROM update_change_event"
                          " WHERE batch_id='upd_ls_01' AND doc_id IS NULL").fetchone()[0]
    assert total == 7 and null_doc == 6
    with pytest.raises(sqlite3.IntegrityError):
        db.execute(sql, ("chg_ls_bad", "expired"))


def test_update_event_fk_cascade(db):
    """batch_id 外键：孤儿事件插入被拒、删批次级联删事件。"""
    import sqlite3
    ev = ("INSERT INTO update_change_event(change_id, batch_id, standard_no,"
          " change_type, source_channel)"
          " VALUES(?, 'upd_fk_missing', 'GB 50016-2022', 'superseded', 'laws_db')")
    with pytest.raises(sqlite3.IntegrityError):  # 批次不存在不得写入
        db.execute(ev, ("chg_fk_orphan",))
    db.execute("INSERT INTO update_check_batch(batch_id) VALUES('upd_fk_01')")
    db.execute(ev.replace("upd_fk_missing", "upd_fk_01"), ("chg_fk_01",))
    db.execute("DELETE FROM update_check_batch WHERE batch_id='upd_fk_01'")
    left = db.execute("SELECT count(*) FROM update_change_event"
                      " WHERE change_id='chg_fk_01'").fetchone()[0]
    assert left == 0


# ===== 批量导入批次表契约（阶段六·批次2，pipeline/06 §4；巡检侧最小版） =====


def test_bulk_import_batch_exists_and_columns(db):
    """31 号表存在性 + 巡检侧最小列集（tier/checkpoint_json 是编排器刚需）。"""
    from src.core.storage.sqlite_db import list_tables
    tables = set(list_tables())
    assert "bulk_import_batch" in tables, "缺少 bulk_import_batch 契约表"
    cols = {r["name"] for r in db.execute("PRAGMA table_info(bulk_import_batch)").fetchall()}
    required = {"batch_id", "batch_kind", "trigger_type", "status",
                "total", "checked", "red_count", "yellow_count",
                "green_count", "gray_count", "tier", "checkpoint_json",
                "started_at", "finished_at", "created_at"}
    missing = required - cols
    assert not missing, f"bulk_import_batch 缺列: {missing}"


def test_bulk_import_batch_ulid_pk_style(db):
    """主键为 ULID 风格 TEXT 主键，DDL 注释声明 bul_ 前缀。"""
    from pathlib import Path
    import src.core.storage.sqlite_db as sqlite_db_mod
    ddl = Path(sqlite_db_mod.__file__).with_name("schema.sql").read_text(encoding="utf-8")
    assert "-- ULID 前缀 bul_" in ddl, "bulk_import_batch 主键缺 ULID 前缀注释"
    col = {r["name"]: r for r in
           db.execute("PRAGMA table_info(bulk_import_batch)").fetchall()}["batch_id"]
    assert col["pk"] == 1 and col["type"] == "TEXT", "batch_id 须为 TEXT ULID 风格主键"


def test_bulk_import_batch_check_enums_and_defaults(db):
    """CHECK 枚举（batch_kind/trigger_type/status/tier）+ 默认值（status/计数/tier）。"""
    import sqlite3
    # 默认值路径：status=pending、五计数 0、tier=tier1、checkpoint_json 可空
    db.execute("INSERT INTO bulk_import_batch(batch_id, batch_kind, trigger_type)"
               " VALUES('bul_ct_01', 'inspect', 'manual')")
    row = db.execute("SELECT status, total, checked, red_count, yellow_count,"
                     " green_count, gray_count, tier, checkpoint_json"
                     " FROM bulk_import_batch WHERE batch_id='bul_ct_01'").fetchone()
    assert tuple(row) == ("pending", 0, 0, 0, 0, 0, 0, "tier1", None)
    # tier0 显式落值合法；bulk_ingest 枚举为批量导入预留
    db.execute("INSERT INTO bulk_import_batch(batch_id, batch_kind, trigger_type, tier)"
               " VALUES('bul_ct_02', 'bulk_ingest', 'scheduled', 'tier0')")
    # 四个 CHECK 枚举域逐一拒绝非法值
    bad = [("INSERT INTO bulk_import_batch(batch_id, batch_kind)"
            " VALUES('bul_bad1', 'crawl')"),
           ("INSERT INTO bulk_import_batch(batch_id, trigger_type)"
            " VALUES('bul_bad2', 'cron')"),
           ("INSERT INTO bulk_import_batch(batch_id, batch_kind, status)"
            " VALUES('bul_bad3', 'inspect', 'canceled')"),
           ("INSERT INTO bulk_import_batch(batch_id, batch_kind, tier)"
            " VALUES('bul_bad4', 'inspect', 'tier9')")]
    for sql in bad:
        with pytest.raises(sqlite3.IntegrityError):
            db.execute(sql)
