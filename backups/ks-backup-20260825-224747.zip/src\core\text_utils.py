"""OCR 文本清洗公共模块（2026-08-23 整合）。

normalize_wraps：OCR 折行拼接——MinerU 把 PDF 一行在版面上的折行硬切成 \n，
本函数按规则合并：单换行拼接（CJK 直连、字母数字补空格）；仅当「句末标点 + 下一行是
编号/表/注/第X条/图」才保留段落断行。

latex_to_text / clean_eq_tags：MinerU 行内公式 <eq>LaTeX</eq> → 可读 Unicode 文本
（h_w/m 等），入库即转换，卡片/WPS/编辑器全链路一致。

用途（单一来源，消除多处复制）：
  1) 入库管线：content_text 落库前清洗 + 表格 html 的 <eq> 转换
  2) 显示层兜底（幂等：已清洗的再拼无变化）
  3) WPS 导出前
"""
from __future__ import annotations

import re

_PARA_START_RE = re.compile(
    r"^(\d{1,2}(\.\d+)*\s*[、．.]?|（[一二三四五六七八九十]+）|"
    r"[一二三四五六七八九十]+、|表\d+|附录|注[:：]?|"
    r"第[一二三四五六七八九十]+[章条节]|图\d+)")
_SENT_END_RE = re.compile(r"[。！？；：]$")
_ASCII_RE = re.compile(r"[A-Za-z0-9]")

_SUB_SCRIPTS = str.maketrans(
    "0123456789aeiouxhklmnpst",
    "₀₁₂₃₄₅₆₇₈₉ₐₑᵢₒᵤₓₕₖₗₘₙₚₛₜ")
_SUP_SCRIPTS = str.maketrans(
    "0123456789aeiouxhklmnprsty",
    "⁰¹²³⁴⁵⁶⁷⁸⁹ᵃᵉⁱᵒᵘˣʰᵏˡᵐⁿᵖʳˢᵗʸ")

_LATEX_SYMBOLS = {
    "\\leq": "≤", "\\geq": "≥", "\\neq": "≠", "\\times": "×",
    "\\div": "÷", "\\pm": "±", "\\cdot": "·", "\\alpha": "α",
    "\\beta": "β", "\\gamma": "γ", "\\delta": "δ", "~": " ",
}


def normalize_wraps(s: str | None) -> str:
    """OCR 折行拼接。幂等：对已拼接文本再执行无变化。"""
    if not s:
        return ""
    lines = [l.strip() for l in s.split("\n")]
    out: list[str] = []
    for l in lines:
        if not l:
            if out and out[-1] != "":
                out.append("")
            continue
        last = out[-1] if out else None
        if last and last != "":
            prev_ends = bool(_SENT_END_RE.search(last))
            this_para = bool(_PARA_START_RE.match(l))
            if prev_ends and this_para:
                out.append(l)
            else:
                need_space = bool(_ASCII_RE.search(last)) and bool(_ASCII_RE.match(l))
                out[-1] = last + (" " if need_space else "") + l
        else:
            out.append(l)
    return "\n".join(out)


def latex_to_text(latex: str) -> str:
    r"""MinerU <eq> LaTeX → 可读文本。
    例：'h _ { \mathrm { ~ w ~ } } / \mathrm { m }' → 'hw/m'"""
    t = latex
    # 1) 剥命令包裹：\mathrm{...} 等取其内容（迭代处理嵌套）
    for _ in range(3):
        t2 = re.sub(r"\\(?:mathrm|text|mathbf|mathit)\s*\{([^{}]*)\}", r"\1", t)
        if t2 == t:
            break
        t = t2
    # 2) 下标：_ { x } 或 _x → Unicode 下标
    def sub_repl(m):
        inner = m.group(1) if m.group(1) is not None else m.group(2)
        return inner.translate(_SUB_SCRIPTS)
    t = re.sub(r"_\s*\{([^{}]*)\}|_\s*(\S)", sub_repl, t)
    # 3) 上标：^ { x } 或 ^x → Unicode 上标
    def sup_repl(m):
        inner = m.group(1) if m.group(1) is not None else m.group(2)
        return inner.translate(_SUP_SCRIPTS)
    t = re.sub(r"\^\s*\{([^{}]*)\}|\^\s*(\S)", sup_repl, t)
    # 4) 符号映射 + 清理残留命令与花括号
    for pat, rep in _LATEX_SYMBOLS.items():
        t = t.replace(pat, rep)
    t = re.sub(r"\\[A-Za-z]+", "", t)
    t = t.replace("{", "").replace("}", "")
    return re.sub(r"\s+", " ", t).strip()


def clean_eq_tags(html: str | None) -> str:
    """把 content_markdown/content_html 里的 <eq>LaTeX</eq> 转成可读文本（其余标签保留）。"""
    if not html:
        return ""
    return re.sub(r"<eq>(.*?)</eq>", lambda m: latex_to_text(m.group(1)), html)


def html_unescape(s: str | None) -> str:
    """HTML 实体解码（&lt; → < 等）。WPS 导出/纯文本提取前必须做，否则显示字面 &lt;。"""
    if not s:
        return ""
    import html as _html
    return _html.unescape(s)


def strip_tags(s: str | None) -> str:
    """剥除 HTML 标签 + 解码实体（表格单元格 → 纯文本）。"""
    if not s:
        return ""
    t = re.sub(r"<[^>]+>", "", s)
    return html_unescape(t).strip()


def table_html_to_pipe(table_html: str) -> str:
    """<table> html → 管道行文本（与前端 table_md 同源格式），单元格已解码实体。"""
    rows: list[str] = []
    for tr in re.findall(r"<tr>(.*?)</tr>", table_html or "", re.S):
        cells = [strip_tags(c) for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", tr, re.S)]
        if cells:
            rows.append(" | ".join(cells))
    return "\n".join(rows)


def strip_embedded_table_text(text: str, table_md: str | None) -> str:
    """后端版 stripEmbeddedTable：正文里与表格重复的文字块剔除
    （MinerU 会把表格文字也抽进正文块 → 卡片"正文后再放一遍表格文字"的根因）。
    判定：一行中表格 token 的覆盖率高（该行几乎全由表格内容组成）→ 视为泄漏丢弃。"""
    t = text or ""
    md = table_md or ""
    if not md:
        return t.strip()
    tokens: set[str] = set()
    for cell in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", md, re.S):
        c = strip_tags(cell).replace(" ", "")
        if len(c) >= 1 and c != "-":
            tokens.add(c)
    if not tokens:
        return t.strip()
    kept: list[str] = []
    for line in t.split("\n"):
        flat = line.replace(" ", "")
        if not flat:
            kept.append(line)
            continue
        hits = [tok for tok in tokens if tok in flat]
        overlap_len = sum(len(tok) for tok in hits)
        coverage = overlap_len / max(len(flat), 1)
        # 行几乎全由表格内容组成，或命中 ≥3 个不同表格 token → 泄漏，丢弃
        if coverage >= 0.5 or len(hits) >= 3:
            continue
        kept.append(line)
    return "\n".join(kept).strip()
