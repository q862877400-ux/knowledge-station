"""OCR 折行清洗公共模块测试（2026-08-23）。"""
from src.core.text_utils import normalize_wraps


def test_join_plain_wrap():
    """普通折行（CJK 直连）→ 拼接。"""
    assert normalize_wraps("有毒气体及氧\n气浓度") == "有毒气体及氧气浓度"


def test_keep_para_boundary():
    """句末标点 + 下一行是编号/条款 → 保留段落断行。"""
    s = "作业前应清除现场可燃物。\n5.2.1 动火作业应有专人监护"
    assert normalize_wraps(s) == s


def test_ascii_space():
    """字母数字跨界拼接补空格；数字-中文直连不补。"""
    assert normalize_wraps("0.3m\n0.6m") == "0.3m 0.6m"
    assert normalize_wraps("0.3m\n至 0.6m") == "0.3m至 0.6m"


def test_idempotent():
    """幂等：已清洗文本再执行无变化。"""
    s = "作业现场应配置移动式气体检测报警仪，连续检测受限空间内可燃气体、有毒气体及氧气浓度，并 2 h 记录 1次。"
    assert normalize_wraps(s) == s
    once = normalize_wraps("有毒气体及氧\n气浓度，并 2 h 记录 1次。")
    assert normalize_wraps(once) == once


def test_empty_and_none():
    assert normalize_wraps("") == ""
    assert normalize_wraps(None) == ""
