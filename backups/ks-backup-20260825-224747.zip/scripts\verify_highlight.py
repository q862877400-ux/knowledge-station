"""高亮 bbox 离屏验证：把 source_span bbox（顶部原点）画到 PDF 页，对比框内文本是否是该条款。

结论判定：框内文本 == 条款文本 → bbox 正确（问题在前端）；否则 → 入库 bbox 有问题。
"""
import json
from pathlib import Path

import fitz

from src.core.storage.sqlite_db import get_db_connection


def main() -> None:
    conn = get_db_connection()
    row = conn.execute(
        "SELECT cr.clause_revision_id, cr.clause_number, cr.content_text, dm.file_path"
        " FROM clause_revision cr JOIN doc_meta dm ON dm.doc_id=cr.doc_id"
        " WHERE cr.clause_number IN ('5.2.1','6.4.2') LIMIT 1").fetchone()
    if row is None:
        print("未找到测试条款")
        return
    pdf = Path(row["file_path"])
    if not pdf.exists():
        print("PDF 不存在:", pdf)
        return
    spans = conn.execute(
        "SELECT page_number, bbox_json FROM source_span WHERE clause_revision_id=?",
        (row["clause_revision_id"],)).fetchall()
    print(f"条款 {row['clause_number']} 来自 {pdf.name}")
    print("条款文本前 30 字:", row["content_text"][:30].replace("\n", " "))
    doc = fitz.open(str(pdf))
    for s in spans:
        pno = s["page_number"]
        bbox = json.loads(s["bbox_json"])
        page = doc[pno - 1]
        rect = fitz.Rect(*bbox)  # 顶部原点坐标 = PyMuPDF 坐标系
        words = page.get_text("words")
        inside = [w[4] for w in words
                  if fitz.Rect(w[:4]).intersects(rect)]
        text_in_box = "".join(inside)[:60]
        print(f"  页{pno} bbox={bbox} 框内文本: {text_in_box}")
        # 画框到验证图
    page0 = doc[spans[0]["page_number"] - 1]
    r = fitz.Rect(*json.loads(spans[0]["bbox_json"]))
    page0.draw_rect(r, color=(1, 0, 0), width=2)
    out = Path("var/highlight_verify.png")
    page0.get_pixmap(dpi=120).save(str(out))
    print("验证图:", out)


if __name__ == "__main__":
    main()
