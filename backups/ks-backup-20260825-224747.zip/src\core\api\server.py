"""FastAPI 服务组装（全量路由）：随机端口 + token 鉴权 + /health + SSE 流式 + 证据/补丁/更新 API。"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import secrets
import time
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, StreamingResponse

from src.core.config import get_settings
from src.core.storage.sqlite_db import init_schema, get_db_connection

_STARTED_AT = time.monotonic()


def create_app(token: str) -> FastAPI:
    app = FastAPI(title="KnowledgeStation Engine", version="0.1.0")
    init_schema()

    # 开发期前端 (vite localhost) 跨域访问本引擎；引擎本身仅绑 127.0.0.1 + token
    from fastapi.middleware.cors import CORSMiddleware
    app.add_middleware(
        CORSMiddleware,
        allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$",
        allow_methods=["*"],
        allow_headers=["*"])

    @app.middleware("http")
    async def auth_middleware(request: Request, call_next):
        if request.url.path == "/api/v1/health":
            return await call_next(request)
        if request.method == "OPTIONS":
            return await call_next(request)  # CORS 预检不带 token
        auth = request.headers.get("Authorization", "")
        if not secrets.compare_digest(auth, f"Bearer {token}"):
            return _json_error(401, "unauthorized", "缺少或无效的 token")
        return await call_next(request)

    def _json_error(status: int, code: str, message: str):
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=status,
                            content={"code": status, "status": "error", "error": code,
                                     "message": message})

    @app.get("/api/v1/health")
    async def health():
        from src.core.retrieval import embedder
        try:
            conn = get_db_connection()
            conn.execute("SELECT 1")
            db_status = "ok"
        except Exception:
            db_status = "error"
        return {
            "status": "healthy" if db_status == "ok" else "degraded",
            "uptime_seconds": int(time.monotonic() - _STARTED_AT),
            "db_status": db_status,
            "vector_engine": "ok" if embedder.is_available() else "offline",
            "parser_worker": "ok",
        }

    # ===== 阶段2.1 纠错补丁 API（外部评审响应：OCR/解析错误人工纠偏）=====

    @app.post("/api/v1/clauses/patches")
    async def create_patch(request: Request):
        """创建纠错补丁。内置防乱检测（patch guard）：
        - reject：与原文几乎无关/大量乱码 → 422 拒绝落库
        - warning：长度/语言突变 → 首次返回 code=466 + 警告原因，
          前端二次确认后带 force=true 重新提交才落库（P1 红线：不写脏补丁）。"""
        body = await request.json()
        from src.core.storage import clause_repo
        from src.core.exceptions import KnowledgeStationError
        from src.core.verification.patch_guard import check_patch
        clause_id = body.get("clause_revision_id") or ""
        field = body.get("field_name") or ""
        new_val = body.get("patched_value") or ""
        force = bool(body.get("force"))

        # 防乱检测（仅内容字段；取原值做比对）
        if field in ("content_text", "content_markdown"):
            try:
                conn = get_db_connection()
                orig_row = conn.execute(
                    "SELECT content_text, content_markdown FROM clause_revision"
                    " WHERE clause_revision_id=?", (clause_id,)).fetchone()
                patches = conn.execute(
                    "SELECT patched_value FROM clause_patch WHERE clause_revision_id=?"
                    " AND field_name=?", (clause_id, field)).fetchone()
                original = None
                if orig_row is not None:
                    base = orig_row["content_markdown"] if field == "content_markdown" \
                        else orig_row["content_text"]
                    original = patches["patched_value"] if patches else base
                guard = check_patch(original or "", str(new_val), field)
            except Exception:
                # 防乱检测内部异常：fail-closed（P1 不写脏补丁红线）——
                # 保守拒绝写入，绝不把脏/乱码补丁当合法数据落库
                return _json_error(422, "patch_guard_error",
                                   "防乱检测内部异常，已保守拒绝写入；请稍后重试")
            if guard["verdict"] == "reject" and not force:
                return _json_error(422, "patch_rejected",
                                   "修正被拒绝：" + "；".join(guard["reasons"]))
            if guard["verdict"] == "warning" and not force:
                return {"code": 466, "status": "warning",
                        "data": {"warnings": guard["reasons"],
                                 "similarity": round(guard.get("similarity", 1), 2)},
                                "message": "检测到可疑修改，请确认后重新提交"}

        try:
            out = clause_repo.upsert_patch(
                clause_id, field, new_val, body.get("patch_reason"))
        except KnowledgeStationError as e:
            status = 404 if e.code == "clause_not_found" else 422
            return _json_error(status, e.code, str(e))
        return {"code": 200, "status": "success", "data": out}

    @app.get("/api/v1/clauses/resolve")
    async def resolve_clause(standard_no: str, clause_number: str):
        """引用兜底：按标准号+条款号解析条款（LLM 引用未进证据列表的条款时定位用）。
        标准号做年份宽容（GB/T 3608-2008 → GB 3608-2025 现行版）。"""
        from src.core.storage import clause_repo, user_data
        c = clause_repo.resolve_clause(standard_no, clause_number)
        if c is None:
            return _json_error(404, "clause_not_found",
                               f"条款不存在: {standard_no} {clause_number}")
        bm = user_data.bookmarked_clause_keys()
        ann = user_data.annotations_by_clause_keys([c.clause_key])
        return {"code": 200, "data": _ev_dict(c, bm, ann)}

    @app.get("/api/v1/data/quality-issues")
    async def data_quality_issues(limit: int = 200):
        """数据体检：自动识别 OCR/切分录入质量问题的条款，供前端集中纠错。
        检查项：正文含内嵌表格文本（与 table_md 重复）、英文粘连、页脚/下节标题泄漏、
        表格列数不一致（阶梯）、表格脏单元格。零副作用只读。"""
        import re
        from src.core.storage import clause_repo as _cr
        conn = get_db_connection()
        rows = conn.execute(
            "SELECT cr.clause_revision_id, cr.clause_number, cr.content_text,"
            " cr.content_markdown, cr.is_suspicious, dm.standard_no"
            " FROM clause_revision cr JOIN doc_meta dm ON dm.doc_id = cr.doc_id"
            " ORDER BY dm.standard_no, cr.clause_number").fetchall()
        patch_rows = conn.execute(
            "SELECT clause_revision_id, field_name FROM clause_patch").fetchall()
        patched: dict[str, list[str]] = {}
        for p in patch_rows:
            patched.setdefault(p["clause_revision_id"], []).append(p["field_name"])
        issues: list[dict] = []
        for row in rows:
            ct = row["content_text"] or ""
            table_md = _html_to_text(row["content_markdown"]) if row["content_markdown"] else ""
            tags: list[str] = []
            if table_md:
                tokens = {c.strip() for ln in table_md.split("\n")
                          for c in ln.split("|") if c.strip()}
                lines = {re.sub(r"\s+", " ", l.strip()) for l in ct.split("\n") if l.strip()}
                if tokens & lines:
                    tags.append("正文含内嵌表格文本")
                counts = [len([c for c in r.split("|") if c.strip()])
                          for r in table_md.split("\n") if "|" in r]
                # 跳过首行（常为标题/合并表头），仅比较数据行列数
                data_counts = counts[1:] if len(counts) > 1 else counts
                if data_counts and max(data_counts) - min(data_counts) >= 2:
                    tags.append("表格列数不一致")
                if re.search(r"\|\s*\d{3,}\s*\|", table_md) or                         re.search(r"\|\s*(IN|NV|IVI|VI)\s*\|", table_md):
                    tags.append("表格脏单元格")
            if re.search(r"[a-z]{16,}", ct):
                tags.append("英文粘连")
            if re.search(r"\d+\s+GB\s+[0-9—–-]+\s*$", ct) or                     re.search(r"\n\s*\d{1,2}\s+[\u4e00-\u9fa5]{4,}\s*$", ct):
                tags.append("页脚/下节标题泄漏")
            if re.search(r"[\u4e00-\u9fa5A-Za-z0-9]\n[\u4e00-\u9fa5A-Za-z0-9]", ct):
                tags.append("正文换行残留")
            if tags:
                issues.append({
                    "clause_revision_id": row["clause_revision_id"],
                    "standard_no": row["standard_no"],
                    "clause_number": row["clause_number"],
                    "is_suspicious": bool(row["is_suspicious"]),
                    "issues": tags,
                    "content_text": ct[:200],
                    "table_md": table_md[:200],
                    "patched_fields": patched.get(row["clause_revision_id"], []),
                })
                if len(issues) >= limit:
                    break
        return {"code": 200, "status": "success",
                "data": issues, "total": len(issues)}

    @app.get("/api/v1/clauses/patches")
    async def get_patches(clause_revision_id: str | None = None, limit: int = 100):
        from src.core.storage import clause_repo
        return {"code": 200, "status": "success",
                "data": clause_repo.list_patches(clause_revision_id, limit)}

    @app.delete("/api/v1/clauses/patches/{patch_id}")
    async def remove_patch(patch_id: str):
        from src.core.storage import clause_repo
        ok = clause_repo.delete_patch(patch_id)
        if not ok:
            return _json_error(404, "patch_not_found", f"补丁不存在: {patch_id}")
        return {"code": 200, "status": "success", "data": {"patch_id": patch_id,
                                                            "rolled_back": True}}

    # ===== T06a 合规审查接口（契约 7.3）=====

    @app.get("/api/v1/documents/{doc_id}/file")
    async def get_document_file(doc_id: int | str):
        """PDF 原件字节流（R7 穿透高亮用；受 token 保护）。"""
        conn = get_db_connection()
        row = conn.execute(
            "SELECT file_path FROM doc_meta WHERE doc_id=?", (str(doc_id),)).fetchone()
        if row is None or not row["file_path"]:
            return _json_error(404, "doc_not_found", f"文档不存在: {doc_id}")
        p = Path(row["file_path"])
        if not p.exists() or not str(p).lower().endswith(".pdf"):
            return _json_error(404, "file_not_found",
                               f"PDF 原件不可用（法律文本直灌文档无原页）: {p.name}")
        return FileResponse(str(p), media_type="application/pdf", filename=p.name)

    @app.post("/api/v1/compliance/review")
    async def create_review(request: Request):
        body = await request.json()
        from src.core.compliance.engine import create_review_task
        out = create_review_task(
            body.get("review_type", "contract"), body.get("object_name", ""),
            body.get("object_content", ""), body.get("project_id"))
        return {"code": 200, "status": "success", "data": out}

    @app.post("/api/v1/compliance/review/{task_id}/execute")
    async def execute_review(task_id: str, request: Request):
        body = await request.json()
        confirmed = body.get("confirmed_point_ids")
        from src.core.compliance.engine import execute_review as run_review

        async def event_stream():
            for item in run_review(task_id, confirmed):
                yield _sse("point_verdict", item)
            conn = get_db_connection()
            row = conn.execute(
                "SELECT red_count, yellow_count, green_count, report_path FROM review_task"
                " WHERE task_id=?", (task_id,)).fetchone()
            yield _sse("report_ready", {
                "red_count": row["red_count"], "yellow_count": row["yellow_count"],
                "green_count": row["green_count"], "report_path": row["report_path"]})
            yield _sse("done", {})

        return StreamingResponse(event_stream(), media_type="text/event-stream")

    # ===== 阶段4 "能用"档：用户资产 / 导出 / 义务清单 / 目录树 =====

    @app.get("/api/v1/documents")
    async def doc_list():
        """知识库文档列表（对比选择器/知识库浏览用）。"""
        conn = get_db_connection()
        rows = conn.execute(
            "SELECT doc_id, standard_no, standard_name, legal_status, legal_hierarchy,"
            " effective_from, superseded_by, quality_grade, doc_type FROM doc_meta"
            " ORDER BY standard_no").fetchall()
        return {"code": 200, "data": [dict(r) for r in rows]}

    @app.get("/api/v1/documents/categories")
    async def doc_categories():
        """文件目录面板数据源（4 级树）：
        标准：L1 国家标准·行标·团标 → L2 CCS 大类 → L3 CCS 区间 → L4 CCS 具体类目+文档
        法规：L1 法律法规 → L2 效力等级 → L3 领域 → **文档叶节点**（法规名称不再作为目录级别，2026-08-24）
        空分类不返回；叶节点含 doc_id/standard_no/standard_name/legal_status。"""
        from src.core.knowledge.doc_catalog import classify_document
        conn = get_db_connection()
        rows = conn.execute(
            "SELECT doc_id, standard_no, standard_name, legal_status, legal_hierarchy,"
            " effective_from, superseded_by, quality_grade, doc_type, domain_tags FROM doc_meta"
            " ORDER BY standard_no").fetchall()
        top: dict[str, dict] = {}   # top -> {name, order, l2: {l2 -> {l3 -> {l4 -> [docs]} | {docs}}}}
        for r in rows:
            d = dict(r)
            try:
                tags = json.loads(d.get("domain_tags") or "[]")
                d["domain_tags"] = tags if isinstance(tags, list) else []
            except Exception:
                d["domain_tags"] = []
            cl = classify_document(d)
            node = top.setdefault(cl["top"], {"name": cl["top_name"], "order": cl["order"], "levels": {}})
            l2 = node["levels"].setdefault(cl["level2"], {})
            l3 = l2.setdefault(cl["level3"], {})
            l4 = l3.setdefault(cl["level4"], [])
            l4.append(dict(r))
        out = []
        for tk, node in sorted(top.items(), key=lambda kv: kv[1]["order"]):
            l2s = []
            for l2name, l2map in sorted(node["levels"].items()):
                l3s = []
                for l3name, l3map in sorted(l2map.items()):
                    l4s = [{"name": l4name, "docs": docs}
                           for l4name, docs in sorted(l3map.items())]
                    l3s.append({"name": l3name, "items": l4s})
                l2s.append({"name": l2name, "items": l3s})
            out.append({"name": node["name"], "items": l2s})
        return {"code": 200, "data": out}

    @app.get("/api/v1/documents/{doc_id}/tree")
    async def document_tree(doc_id: str):
        """R37 目录树：优先读 PDF 自带书签（最全最准，含层级+页码），
        无书签时回退「库内 N.M 小节标题 + 文本层猜章标题」；法规类（law-text）用库内「第X章」。

        - 有书签（GB30871 识别版等）：fitz.get_toc() 直接给完整目录，过滤前言/引言/编号/附录表格噪声。
        - 无书签：库内 clause_number 形如 N.M 且正文 ≤15 字为小节标题；章标题从 PDF 文本层猜
          （`^N 标题$` 独立行，且该章在库内有 N.M 子条款）。
        - 法规类（file_path 为 law-text://）：条款号「第一条」格式，无 N.M 小节——
          从库内「第X章」条款提取章标题，返回 level=1。
        返回 [{clause_number, title, page_start, level, source}]，level=1 章 / level=2 小节。
        """
        import re as _re
        conn = get_db_connection()
        doc = conn.execute(
            "SELECT standard_no, file_path FROM doc_meta WHERE doc_id=?", (str(doc_id),)).fetchone()
        if doc is None:
            return _json_error(404, "doc_not_found", f"文档不存在: {doc_id}")

        rows = conn.execute(
            "SELECT clause_number, content_text, page_start FROM clause_revision"
            " WHERE doc_id=? AND content_type='normal' ORDER BY rowid", (str(doc_id),)).fetchall()

        # ---- 策略 1：PDF 自带书签（最优先）----
        bookmarks: list[dict] = []
        if doc["file_path"] and doc["file_path"].startswith(("http", "law-text")) is False \
                and Path(doc["file_path"]).exists():
            try:
                import fitz
                pdf = fitz.open(doc["file_path"])
                toc = pdf.get_toc()
                noise = ("前言", "引言", "起草说明", "目录", "编制说明")
                for lvl, title, page in toc:
                    t = (title or "").strip()
                    if not t or page is None or int(page) <= 0:
                        continue
                    t_flat = t.replace(" ", "").replace("\u3000", "")
                    if t_flat.startswith(noise) or _re.match(r"^page-\d+$", t):
                        continue
                    # 书签页码是 PDF 物理页（与渲染页码一致）；L1 里标题形如 N.M 自动降为 L2
                    eff_lvl = min(lvl, 2)
                    if eff_lvl == 1 and _re.match(r"^\d{1,2}\.\d{1,2}\s", t):
                        eff_lvl = 2
                    bookmarks.append({"clause_number": "", "title": t,
                                      "page_start": int(page), "level": eff_lvl,
                                      "source": "bookmark"})
                pdf.close()
            except Exception:
                bookmarks = []
        # 书签有效性：垃圾书签（文件名标题 / 负页码）→ 视为无效回退
        if bookmarks:
            junk = [b for b in bookmarks
                    if _re.match(r"^[\w\-]+\.pdf$", b["title"]) or b["page_start"] <= 0]
            if len(junk) > len(bookmarks) / 2:
                bookmarks = []
        if len(bookmarks) >= 3:
            # 剔除附录表格噪声（表A.N / 编号），但保留附录章（附 录 A）与 B.x 小节
            bookmarks = [b for b in bookmarks
                         if not _re.match(r"^(表[A-Z]\.\d+|编号)", b["title"])]
            if bookmarks:
                return {"code": 200, "data": bookmarks}

        # ---- 策略 2：法规类（条款号「第X条」格式，无论 file_path 是 law-text 还是测试 PDF）----
        # GB/T 3608 等 N.M 格式（虽 law-text）→ 落策略 3
        if any(_re.match(r"^第[一二三四五六七八九十百千零]+条", (r["clause_number"] or ""))
               for r in rows):
            law_items = []
            for r in rows:
                no = (r["clause_number"] or "").strip()
                body = (r["content_text"] or "").replace("\n", " ").strip()
                m_ch = _re.match(r"^第([一二三四五六七八九十百]+)章", no)
                if m_ch and len(body) <= 60:
                    law_items.append({"clause_number": no,
                                      "title": body[len(no):].strip() or no,
                                      "page_start": r["page_start"], "level": 1,
                                      "source": "law"})
            # 无章结构（纯条文）→ 全部条文进目录，标题取条文首句（≤24 字）
            if not law_items:
                seen_law: set[str] = set()
                for r in rows:
                    no = (r["clause_number"] or "").strip()
                    if not _re.match(r"^第[一二三四五六七八九十百千零]+条", no) or no in seen_law:
                        continue
                    seen_law.add(no)
                    body = (r["content_text"] or "").replace("\n", " ").strip()
                    title = body[len(no):].strip()
                    # 去掉 "（...）" 注音/重复前缀
                    title = _re.sub(r"^[（(][^）)]*[）)]\s*", "", title)[:24] or no
                    law_items.append({"clause_number": no, "title": title,
                                      "page_start": r["page_start"], "level": 2,
                                      "source": "law"})
            if law_items:
                return {"code": 200, "data": law_items}

        # ---- 策略 2.5：law-text 且 N.M 格式（如 GB/T 3608-2008，无 PDF 但术语表干净）----
        # 判定：条款形如 N.M，且正文首行 "N.M 标题"（同行）→ 视为标题条款
        if doc["file_path"] and "law-text" in str(doc["file_path"]):
            gl_items = []
            seen_gl: set[str] = set()
            for r in rows:
                no = (r["clause_number"] or "").strip()
                if not _re.match(r"^\d{1,2}\.\d{1,2}$", no) or no in seen_gl:
                    continue
                lines = (r["content_text"] or "").splitlines()
                first = lines[0].strip() if lines else ""
                if first.startswith(no) and len(first) <= 20:
                    seen_gl.add(no)
                    gl_items.append({"clause_number": no,
                                     "title": first[len(no):].strip() or no,
                                     "page_start": r["page_start"], "level": 2,
                                     "source": "db"})
            if gl_items:
                return {"code": 200, "data": gl_items}

        # ---- 策略 3：库内 N.M 小节标题 + PDF 文本层猜章标题 ----
        items: list[dict] = []
        seen: set[str] = set()
        sub_nos: set[str] = set()
        for r in rows:
            no = (r["clause_number"] or "").strip()
            m2 = _re.match(r"^(\d{1,2})\.\d{1,2}$", no)
            if m2:
                sub_nos.add(m2.group(1))
            body = (r["content_text"] or "").replace("\n", " ").strip()
            lines = (r["content_text"] or "").splitlines()
            first_line = lines[0].strip() if lines else ""
            # 小节标题判定（严格）：正文极短 ≤15 字。术语表/正文混排文档（GB 3608-2025）不硬猜，
            # 避免误判；law-text 且 N.M 的干净术语表走下方专门分支。
            if m2 and len(body) <= 15:
                title = body[len(no):].strip() or no
                items.append({"clause_number": no, "title": title,
                              "page_start": r["page_start"], "level": 2,
                              "source": "db"})
                seen.add(no)

        chapters: list[dict] = []
        if doc["file_path"] and doc["file_path"].startswith("law-text") is False \
                and Path(doc["file_path"]).exists():
            try:
                import fitz
                pdf = fitz.open(doc["file_path"])
                for pno in range(pdf.page_count):
                    text = pdf[pno].get_text()
                    for m in _re.finditer(
                            r"(?m)^\s*(\d{1,2})\s*([\u4e00-\u9fa5]{2,12})\s*$", text):
                        num, title = m.group(1), m.group(2)
                        if num not in sub_nos or num in seen:
                            continue
                        chapters.append({"clause_number": num, "title": title,
                                         "page_start": pno + 1, "level": 1,
                                         "source": "pdf"})
                        seen.add(num)
                pdf.close()
            except Exception:
                pass

        def sort_key(x: dict):
            parts = x["clause_number"].split(".")
            try:
                return (int(parts[0]), int(parts[1]) if len(parts) > 1 else 0, x["level"])
            except ValueError:
                return (999, 0, x["level"])
        items = sorted(chapters + [i for i in items if i["clause_number"] not in
                                   {c["clause_number"] for c in chapters}],
                       key=sort_key)
        if not items:
            return _json_error(404, "doc_not_found", f"文档无标题条款: {doc_id}")
        return {"code": 200, "data": items}

    @app.get("/api/v1/bookmarks")
    async def get_bookmarks():
        from src.core.storage import user_data
        return {"code": 200, "data": user_data.list_bookmarks()}

    @app.post("/api/v1/bookmarks")
    async def add_bookmark(request: Request):
        body = await request.json()
        from src.core.storage import user_data
        return {"code": 200, "data": user_data.add_bookmark(
            body["clause_key"], body.get("remark"))}

    @app.delete("/api/v1/bookmarks/{bookmark_id}")
    async def del_bookmark(bookmark_id: str):
        from src.core.storage import user_data
        if not user_data.remove_bookmark(bookmark_id):
            return _json_error(404, "bookmark_not_found", f"收藏不存在: {bookmark_id}")
        return {"code": 200, "data": {"removed": True}}

    @app.get("/api/v1/annotations")
    async def get_annotations(clause_key: str | None = None):
        from src.core.storage import user_data
        return {"code": 200, "data": user_data.list_annotations(clause_key)}

    @app.post("/api/v1/annotations")
    async def add_annotation(request: Request):
        body = await request.json()
        from src.core.storage import user_data
        from src.core.exceptions import KnowledgeStationError
        try:
            out = user_data.add_annotation(body["clause_key"], body["content"],
                                           body.get("annotation_type", "personal"))
        except KnowledgeStationError as e:
            return _json_error(422, e.code, str(e))
        return {"code": 200, "data": out}

    @app.delete("/api/v1/annotations/{annotation_id}")
    async def del_annotation(annotation_id: str):
        from src.core.storage import user_data
        if not user_data.delete_annotation(annotation_id):
            return _json_error(404, "annotation_not_found", f"批注不存在: {annotation_id}")
        return {"code": 200, "data": {"removed": True}}

    @app.get("/api/v1/projects")
    async def get_projects():
        from src.core.storage import user_data
        return {"code": 200, "data": user_data.list_projects()}

    @app.post("/api/v1/projects")
    async def create_project(request: Request):
        body = await request.json()
        from src.core.storage import user_data
        return {"code": 200, "data": user_data.create_project(
            body["project_name"], body.get("project_type", "engineering"))}

    @app.post("/api/v1/projects/{project_id}/clauses")
    async def project_add_clause(project_id: str, request: Request):
        body = await request.json()
        from src.core.storage import user_data
        from src.core.exceptions import KnowledgeStationError
        try:
            out = user_data.add_clause_to_project(project_id, body["clause_revision_id"])
        except KnowledgeStationError as e:
            return _json_error(404, e.code, str(e))
        return {"code": 200, "data": out}

    @app.delete("/api/v1/projects/{project_id}/clauses/{clause_revision_id}")
    async def project_remove_clause(project_id: str, clause_revision_id: str):
        from src.core.storage import user_data
        from src.core.exceptions import KnowledgeStationError
        try:
            out = user_data.remove_clause_from_project(project_id, clause_revision_id)
        except KnowledgeStationError as e:
            return _json_error(404, e.code, str(e))
        return {"code": 200, "data": out}

    @app.post("/api/v1/compliance/obligations")
    async def gen_obligations(request: Request):
        body = await request.json()
        from src.core.compliance.obligation import generate_obligation_list
        return {"code": 200, "data": generate_obligation_list(body["business_description"])}

    @app.get("/api/v1/compliance/obligations/{list_id}")
    async def get_obligations(list_id: str):
        from src.core.storage import user_data
        data = user_data.get_obligation_list(list_id)
        if data is None:
            return _json_error(404, "list_not_found", f"清单不存在: {list_id}")
        return {"code": 200, "data": data}

    @app.post("/api/v1/compliance/obligations/{list_id}/checklist")
    async def to_checklist(list_id: str):
        from src.core.compliance.obligation import to_checklist
        from src.core.exceptions import KnowledgeStationError
        try:
            return {"code": 200, "data": to_checklist(list_id)}
        except KnowledgeStationError as e:
            return _json_error(404, e.code, str(e))

    @app.post("/api/v1/compliance/obligations/{list_id}/check")
    async def toggle_check(list_id: str, request: Request):
        body = await request.json()
        from src.core.compliance.obligation import toggle_check
        ok = toggle_check(list_id, body["clause_revision_id"], body["checked"])
        if not ok:
            return _json_error(404, "list_not_found", "清单不存在或条目不存在")
        return {"code": 200, "data": {"updated": True}}

    # ===== Phase 6：知识管理与时效治理（R29/R42/R16/R8/R11/R48）=====

    # ===== Phase 7：合规审查纵深（R-L11~14）=====

    @app.post("/api/v1/compliance/policies")
    async def import_policy(request: Request):
        body = await request.json()
        from src.core.compliance.gap_analysis import import_internal_policy
        return {"code": 200, "data": import_internal_policy(
            body["policy_name"], body["policy_text"])}

    @app.get("/api/v1/compliance/policies")
    async def list_policies():
        conn = get_db_connection()
        rows = conn.execute(
            "SELECT policy_id, policy_name, file_path, created_at"
            " FROM internal_policy ORDER BY created_at DESC").fetchall()
        return {"code": 200, "data": [dict(r) for r in rows]}

    @app.post("/api/v1/compliance/gap-analysis")
    async def run_gap(request: Request):
        body = await request.json()
        from src.core.compliance.gap_analysis import run_gap_analysis
        from src.core.exceptions import KnowledgeStationError
        try:
            return {"code": 200, "data": run_gap_analysis(body["policy_id"])}
        except KnowledgeStationError as e:
            return _json_error(404, e.code, str(e))

    @app.post("/api/v1/compliance/obligations/build")
    async def build_obligations():
        from src.core.compliance.gap_analysis import build_obligations
        return {"code": 200, "data": {"obligations": build_obligations()}}

    @app.post("/api/v1/export/obligations/{list_id}")
    async def export_obligations(list_id: str):
        """R-L10 义务清单导出 Word。"""
        from src.core.storage import user_data
        from src.core.exports.report_export import _exports_dir
        from datetime import datetime
        from docx import Document
        data = user_data.get_obligation_list(list_id)
        if data is None:
            return _json_error(404, "list_not_found", f"清单不存在: {list_id}")
        doc = Document()
        doc.add_heading("义务清单与检查表", level=1)
        doc.add_paragraph(f"业务活动：{data['business_description']}")
        doc.add_paragraph(f"模式：{data['mode']}｜导出时间：{datetime.now():%Y-%m-%d %H:%M}")
        for it in data["items"]:
            p = doc.add_paragraph()
            mark = "☑" if it.get("checked") else "☐"
            p.add_run(f"{mark} [{it['standard_no']} {it['clause_number']}] ").bold = True
            p.add_run(it.get("question") or it["obligation_text"][:200])
        out = _exports_dir() / f"义务清单_{datetime.now():%Y%m%d_%H%M%S}.docx"
        doc.save(str(out))
        return {"code": 200, "data": {"path": str(out), "name": out.name}}

    @app.get("/api/v1/documents/{doc_id}/versions")
    async def doc_versions(doc_id: str):
        """R29 版本替代链（旧→新）。"""
        from src.core.storage.versioning import version_chain
        chain = version_chain(doc_id)
        if not chain:
            return _json_error(404, "doc_not_found", f"文档不存在: {doc_id}")
        return {"code": 200, "data": {"chain": chain,
                                        "has_versions": len(chain) > 1}}

    @app.get("/api/v1/documents/{doc_id}/clauses-by-prefix")
    async def clauses_by_prefix(doc_id: str, prefix: str):
        """目录展开：某章/节前缀下的全部条款（如 prefix=5 → 5.x 全部；prefix=5.1 → 5.1.x 全部）。
        目录点小三角时懒加载；每项含 clause_number/page_start 供跳转。"""
        prefix = (prefix or "").strip().rstrip(".")
        import re as _re
        if not prefix or not _re.match(r"^\d{1,2}(\.\d{1,2})?$", prefix):
            return _json_error(422, "invalid_prefix", f"前缀格式非法: {prefix}")
        conn = get_db_connection()
        rows = conn.execute(
            "SELECT clause_number, page_start FROM clause_revision"
            " WHERE doc_id=? AND content_type='normal'"
            " AND (clause_number=? OR clause_number LIKE ?) ORDER BY rowid",
            (str(doc_id), prefix, prefix + ".%")).fetchall()
        if not rows:
            return _json_error(404, "no_clauses", f"无条款: 前缀 {prefix}")
        return {"code": 200, "data": [dict(r) for r in rows]}

    @app.post("/api/v1/compare")
    async def compare_docs_endpoint(request: Request):
        """R42 版本对照 / R16 跨标准对比（含 R49 模态变化清单）。"""
        body = await request.json()
        from src.core.storage.versioning import compare_docs
        from src.core.exceptions import KnowledgeStationError
        try:
            data = compare_docs(body["doc_a"], body["doc_b"])
        except KnowledgeStationError as e:
            return _json_error(404, e.code, str(e))
        return {"code": 200, "data": data}

    @app.get("/api/v1/operation-log")
    async def operation_log(limit: int = 50):
        """R8/R11 知识库更新时间线（operation_log + event_log 聚合，倒序）。"""
        conn = get_db_connection()
        rows = conn.execute(
            "SELECT 'op' AS src, operation AS event_type, target_type, target_id,"
            " detail, created_at FROM operation_log"
            " UNION ALL"
            " SELECT 'ev', event_type, target_type, target_id, metadata, created_at"
            " FROM event_log"
            " WHERE event_type NOT LIKE 'write_queue%'"
            " ORDER BY created_at DESC, src DESC LIMIT ?", (limit,)).fetchall()
        return {"code": 200, "data": [dict(r) for r in rows]}

    @app.post("/api/v1/aliases/extract")
    async def aliases_extract(request: Request):
        """R48 术语抽取（对库内已有文档的'术语和定义'章节）。"""
        body = await request.json()
        doc_id = body.get("doc_id")
        conn = get_db_connection()
        # 整文档按 rowid 拼接再抽取：MinerU 切分会把"编号/术语/定义"拆到
        # 不同条款，逐条款抽取会丢失行结构
        if doc_id:
            rows = conn.execute(
                "SELECT content_text FROM clause_revision WHERE doc_id=?"
                " ORDER BY rowid", (doc_id,)).fetchall()
        else:
            rows = conn.execute(
                "SELECT content_text FROM clause_revision ORDER BY rowid").fetchall()
        from src.core.knowledge.alias_extract import extract_terms_from_text
        total = len(extract_terms_from_text(
            "\n".join(r["content_text"] for r in rows), source_doc_id=doc_id))
        n = conn.execute("SELECT COUNT(*) FROM alias_store").fetchone()[0]
        return {"code": 200, "data": {"extracted": total, "alias_total": n}}

    @app.post("/api/v1/export/review/{task_id}")
    async def export_review(task_id: str):
        from src.core.exports.report_export import export_review_report_docx
        from src.core.exceptions import KnowledgeStationError
        try:
            path = export_review_report_docx(task_id)
        except KnowledgeStationError as e:
            return _json_error(404, e.code, str(e))
        return {"code": 200, "data": {"path": str(path), "name": Path(path).name}}

    @app.post("/api/v1/export/citations")
    async def export_citations(request: Request):
        """R19 引用块 + R35 问答依据 Word 导出。"""
        body = await request.json()
        from src.core.exports.report_export import build_citation_block, export_qa_citations_docx
        conn = get_db_connection()
        ids = body.get("clause_revision_ids") or []
        evidences = []
        ph = ",".join("?" * len(ids)) if ids else None
        if ph:
            evidences = [dict(r) for r in conn.execute(
                f"SELECT cr.clause_number, cr.title, cr.content_text, cr.page_start,"
                f" dm.standard_no FROM clause_revision cr"
                f" JOIN doc_meta dm ON dm.doc_id=cr.doc_id"
                f" WHERE cr.clause_revision_id IN ({ph})", ids).fetchall()]
        text = build_citation_block(evidences)
        path = export_qa_citations_docx(body.get("query", ""), evidences) if evidences else None
        return {"code": 200, "data": {"citation_text": text,
                                      "docx": str(path) if path else None}}

    @app.get("/api/v1/export/download")
    async def download_export(name: str):
        """下载导出文件（严格限制在 exports 目录内，防路径穿越）。"""
        from src.core.exports.report_export import _exports_dir
        base = _exports_dir().resolve()
        target = (base / name).resolve()
        if base not in target.parents:
            return _json_error(403, "forbidden", "非法路径")
        if not target.exists():
            return _json_error(404, "file_not_found", f"文件不存在: {name}")
        return FileResponse(str(target), filename=target.name)

    @app.post("/api/v1/chat/completions")
    async def chat_completions(request: Request):
        """SSE 骨架：evidence → status → delta → verification → done。

        第一阶段 delta 为规则拼装的占位答案；DeepSeek 真实流式在 T06 接入。
        """
        body = await request.json()
        query = body.get("query", "")
        history = body.get("history") or []   # R60: 多轮历史 [{role, content}]（可选）
        top_k = body.get("top_k", 3)
        channels = body.get("channels")
        include_superseded = body.get("include_superseded", False)
        # P9.4: Debug Trace 默认全量落库（回答不如意时回溯定位问题环节）
        dump_enabled = bool(body.get("dump", True))
        query_mode = body.get("query_mode", "default")  # R9 四档：thorough/default/quick/guess
        answer_scope = body.get("answer_scope", "concise")  # R59: concise/full
        import time as _t
        _trace_start = _t.perf_counter()
        trace = {"stage": "start", "query": query, "query_mode": query_mode,
                 "answer_scope": answer_scope, "history_turns": len(history)}

        # ===== Phase 9.2 Query Understanding Layer（R9/R40/R41/R52/R53/R60）=====
        from src.core.query import understanding as qu

        declared_slots, clean_query = qu.parse_declared(query)
        # 主题作用域槽位提取（通用）：非建筑主题不提取高度等建筑槽位，
        # 避免「4米高处作业」被误标为建筑高度（数值在原文里，LLM 直接可见）
        theme0 = qu.detect_theme(clean_query)
        slots = {**declared_slots, **qu.extract_slots(clean_query, theme=theme0)}
        intent = qu.classify_intent(clean_query)
        # R60 基础：否定维度纠错 → 以正确维度重检索
        correction = qu.detect_correction(clean_query)
        if correction and correction.get("right"):
            clean_query = f"{clean_query} {correction['right']}"
        search_query_raw = clean_query or query
        trace.update({"stage": "query_understanding",
                      "intent": intent, "slots": slots,
                      "declared_slots": declared_slots,
                      "clean_query": clean_query,
                      "correction": correction,
                      "elapsed_ms": round((_t.perf_counter() - _trace_start) * 1000)})

        # R9（v2，通用路径）：不再用规则槽位表判定追问——
        # 统一走检索 + LLM 单次自判「问还是答」（SYSTEM_PROMPT 规则 9）：
        #   关键信息缺失且无法用常识/默认场景推断 → LLM 只输出一行 {"ask":["...",...≤3]}
        #   否则直接作答（常识/假设可用）。一次最多问 3 个点，历史中已有追问不再重复问。
        theme = qu.detect_theme(clean_query)
        user_turns = sum(1 for m in history if m.get("role") == "user")
        trace.update({"stage": "clarify_policy", "theme": theme,
                      "user_turns": user_turns, "mode": "llm-judged"})

        from src.core.retrieval.hybrid_engine import (
            search_with_details, expand_query_with_history)
        from src.core.knowledge.alias_extract import expand_with_alias
        refined = qu.refine_search_query(search_query_raw, intent, theme)
        search_query = expand_with_alias(  # R48 别名反查 + R9 追问增强
            expand_query_with_history(refined, history))
        _t_retr = _t.perf_counter()
        out = search_with_details(search_query, top_k=top_k, channels=channels,
                                  include_superseded=include_superseded)
        # R5a 证据链扩展：被引用条款并入证据（LLM 可见），主证据不足时自动补链
        evidences = list(out["results"])
        _seen_ids = {e.clause_revision_id for e in evidences}
        for _ex in out.get("expanded", []):
            _cl = _ex.get("clause")
            if _cl and _cl.clause_revision_id not in _seen_ids:
                evidences.append(_cl)
                _seen_ids.add(_cl.clause_revision_id)
        trace.update({"stage": "retrieval",
                      "refined_query": refined,
                      "search_query": search_query,
                      "raw_results": [f"{e.standard_no}-{e.clause_number}"
                                      for e in evidences],
                      "retrieval_ms": round((_t.perf_counter() - _t_retr) * 1000)})
        # R52 条件感知过滤 + R40 强标/层级置顶
        filtered = qu.apply_condition_filter(evidences, slots)
        evidences = qu.rank_with_hierarchy(filtered)
        trace.update({"stage": "filter_rank",
                      "filtered_out": [f"{e.standard_no}-{e.clause_number}"
                                       for e in evidences
                                       if e not in filtered],
                      "final_evidence": [f"{e.standard_no}-{e.clause_number}"
                                         for e in evidences],
                      "elapsed_ms": round((_t.perf_counter() - _trace_start) * 1000)})

        # 阶段4 富化上下文：收藏集合 + 批注映射 + 时效警示（R11/R24/R25/R33）
        from src.core.storage import user_data
        try:
            _bm_keys = user_data.bookmarked_clause_keys()
            _ann_cache = user_data.annotations_by_clause_keys(
                [e.clause_key for e in evidences])
        except Exception:
            _bm_keys, _ann_cache = set(), {}
        time_warnings = []
        _warned_docs = set()
        for e in evidences:
            if e.legal_status in ("upcoming", "superseded") and e.doc_id not in _warned_docs:
                _warned_docs.add(e.doc_id)
                if e.legal_status == "upcoming":
                    time_warnings.append(
                        f"【时效提醒】{e.standard_no} 尚未生效（即将实施版本），以下为即将实施的规定")
                else:
                    time_warnings.append(
                        f"【时效提醒】{e.standard_no} 已废止，请确认是否需要现行版本")
        # 标题条款子条款聚合：命中"8.1 作业分级"标题时附带 8.1.1~8.1.x 内容条款
        evidences = _expand_title_clauses(evidences)
        ev_dicts = [_ev_dict(e, _bm_keys, _ann_cache) for e in evidences]

        # T06: 优先真实 LLM 流式；未配 Key / 调用失败 → 占位答案降级（R30 精神）
        use_llm = bool(get_settings().llm_api_key)

        # R9 参数标注 + R53 依据充分度（回答尾部追加）
        # 标注与注入仅限建筑主题（防「高度3米」被误当建筑高度带偏 LLM）；
        # 其他主题的槽位在后台保留但不展示不注入（数字在原文/历史里，LLM 直接可见）
        slots_note = ""
        if slots and theme == 'building':
            labels = {"building_type": "建筑类型", "fire_risk": "火灾危险性",
                      "fire_resistance": "耐火等级", "height": "建筑高度",
                      "subject": "主体", "object": "客体", "behavior": "行为",
                      "consent": "同意状态"}
            slots_note = "已识别参数/要素：" + "、".join(
                f"{labels.get(k, k)}={v}" for k, v in slots.items())
        suff_note = qu.sufficiency_note(intent, len(evidences))
        llm_prompt_query = query
        if slots and theme == 'building':
            llm_prompt_query = f"{query}\n（场景参数：{slots_note}；若参数不适用请说明，"
            "回答时标注前提假设）"

        async def event_stream():
            yield _sse("evidence", {
                "evidences": ev_dicts,
                "time_warnings": time_warnings,
                "expanded_evidences": [
                    {"clause_revision_id": x["clause"].clause_revision_id,
                     "expanded_from": x["expanded_from"],
                     "edge_type": x["edge_type"],
                     "standard_no": x["clause"].standard_no,
                     "clause_number": x["clause"].clause_number,
                     "content_text": (x["clause"].content_text or "")[:400],
                     "page_start": x["clause"].page_start}
                    for x in out.get("expanded", [])]})
            yield _sse("status", {"phase": "streaming_with_verification_pending",
                                  "message": "核验中..."})
            answer_parts: list[str] = []
            try:
                if use_llm:
                    import anyio
                    import json as _json
                    from src.core.llm.deepseek_client import stream_chat_completion
                    # 档位提示：guess 强制作答；quick 仅在完全缺失关键信息时提问
                    mode_hint = ""
                    if query_mode == "guess":
                        mode_hint = "\n（用户档位：guess——请直接作答，不要提问。）"
                    elif query_mode == "quick":
                        mode_hint = "\n（用户档位：quick——除非关键信息完全缺失，否则直接作答。）"
                    gen = stream_chat_completion(
                        llm_prompt_query + mode_hint, ev_dicts, history=history,
                        allow_clarify=user_turns < 2)  # 追问死循环修复：≥2 轮强制作答

                    def _next_chunk():
                        try:
                            return next(gen)
                        except StopIteration:
                            return None

                    # ask 检测：LLM 若选择追问，只会输出一行 {"ask":[...]}；否则是正文。
                    # 缓冲开头若干字符，解析成功则发 clarify 事件，否则按答案流式输出。
                    ask_buf = ""
                    ask_done = False
                    while True:
                        part = await anyio.to_thread.run_sync(_next_chunk)
                        if part is None:
                            break
                        if ask_done:
                            answer_parts.append(part)
                            yield _sse("delta", {"content": part})
                            continue
                        ask_buf += part
                        stripped = ask_buf.lstrip()
                        if stripped.startswith("{"):
                            if len(ask_buf) >= 6:
                                try:
                                    _obj = _json.loads(ask_buf)
                                    _qs = _obj.get("ask")
                                    if isinstance(_qs, list) and _qs and all(
                                            isinstance(x, str) for x in _qs):
                                        ask_done = True
                                        questions = _qs[:3]
                                        if dump_enabled:
                                            trace.update({"stage": "clarify_llm",
                                                          "questions": questions})
                                            _write_debug_dump(
                                                query, search_query, ev_dicts, "",
                                                None, None, history, trace,
                                                clarify=questions)
                                        yield _sse("clarify", {
                                            "questions": questions,
                                            "mode": "llm",
                                            "hint": "请一次性补充以上关键信息后继续提问（最多问一轮）。"})
                                        yield _sse("done", {})
                                        return
                                except Exception:
                                    pass
                                if len(ask_buf) > 800:
                                    ask_done = True
                                    answer_parts.append(ask_buf)
                                    yield _sse("delta", {"content": ask_buf})
                                    ask_buf = ""
                        else:
                            ask_done = True
                            if ask_buf:
                                answer_parts.append(ask_buf)
                                yield _sse("delta", {"content": ask_buf})
                            ask_buf = ""
                    # 流结束仍残留缓冲：最后再判定一次
                    if ask_buf:
                        stripped = ask_buf.lstrip()
                        if stripped.startswith("{"):
                            try:
                                _obj = _json.loads(ask_buf)
                                _qs = _obj.get("ask")
                                if isinstance(_qs, list) and _qs and all(
                                        isinstance(x, str) for x in _qs):
                                    if dump_enabled:
                                        _write_debug_dump(
                                            query, search_query, ev_dicts, "",
                                            None, None, history, trace,
                                            clarify=_qs[:3])
                                    yield _sse("clarify", {
                                        "questions": _qs[:3], "mode": "llm",
                                        "hint": "请一次性补充以上关键信息后继续提问（最多问一轮）。"})
                                    yield _sse("done", {})
                                    return
                            except Exception:
                                pass
                        answer_parts.append(ask_buf)
                        yield _sse("delta", {"content": ask_buf})
                else:
                    answer = _placeholder_answer(query, evidences)
                    for i in range(0, len(answer), 8):
                        chunk = answer[i:i + 8]
                        answer_parts.append(chunk)
                        yield _sse("delta", {"content": chunk})
                        await asyncio.sleep(0.01)
            except Exception as e:  # noqa: BLE001 - LLM 失败降级占位答案
                answer = _placeholder_answer(query, evidences)
                for i in range(0, len(answer), 8):
                    chunk = answer[i:i + 8]
                    answer_parts.append(chunk)
                    yield _sse("delta", {"content": chunk})
                    await asyncio.sleep(0.01)
                yield _sse("status", {"phase": "llm_degraded",
                                      "message": f"大模型不可用，已降级占位答案: {e}"})

            trace.update({"stage": "llm_generation",
                          "llm_used": use_llm,
                          "llm_ms": round((_t.perf_counter() - _trace_start) * 1000)})
            # R9/R53: 回答尾部追加已识别参数标注与依据充分度提示
            tail_notes = []
            joined = "".join(answer_parts)
            # 去重：LLM 可能已复述标注/提示，避免重复追加
            if slots_note and slots_note not in joined:
                tail_notes.append(f"\n\n[{slots_note}]")
            if suff_note and suff_note not in joined:
                tail_notes.append(f"\n{suff_note}")
            if tail_notes:
                for seg in tail_notes:
                    answer_parts.append(seg)
                    yield _sse("delta", {"content": seg})

            # T06: 分型核验（数值/模态/法理）——核验输入用全量条款文本
            # （ev_dicts 的 content_text 被截断，数值可能落在截断外 → 误判篡改，v5 实测修复）
            from src.core.verification.typed_verifier import verify_llm_output
            ev_full = _full_evidence(ev_dicts)
            verification = verify_llm_output("".join(answer_parts), ev_full)
            # R24: 答案层置信度分级（high/mid/low）
            answer_confidence = _answer_confidence(verification, ev_dicts)
            yield _sse("verification", {
                "is_valid": verification.is_valid,
                "answer_confidence": answer_confidence["level"],
                "confidence_reasons": answer_confidence["reasons"],
                "knowledge_types_involved": sorted({e["knowledge_type"] for e in ev_dicts}),
                "unsupported_clauses": verification.unsupported_clauses,
                "unverified_numbers": verification.unverified_numbers,
                "modality_violations": [v.model_dump() for v in verification.modality_violations],
                "legal_element_violations": verification.legal_element_violations,
            })
            if dump_enabled:
                trace.update({"stage": "verification",
                              "is_valid": verification.is_valid,
                              "answer_confidence": answer_confidence["level"],
                              "total_ms": round((_t.perf_counter() - _trace_start) * 1000)})
                _write_debug_dump(query, search_query, ev_dicts,
                                   "".join(answer_parts), verification,
                                   answer_confidence, history, trace)
            yield _sse("done", {})

        return StreamingResponse(event_stream(), media_type="text/event-stream")

    def _write_debug_dump(query, search_query, ev_dicts, answer,
                           verification, answer_confidence, history,
                           trace: dict | None = None, clarify: list | None = None) -> None:
        """P9.4 Debug Trace：完整数据流（理解层→检索→过滤→LLM→核验）落库。
        回答不如意时按阶段回溯定位问题环节。默认每次提问都记录。
        """
        from ulid import ULID
        try:
            conn = get_db_connection()
            evs = [{'standard_no': e.get('standard_no'),
                    'clause_number': e.get('clause_number'),
                    'modality': e.get('modality'),
                    'knowledge_type': e.get('knowledge_type')} for e in ev_dicts]
            vres = (verification.model_dump()
                    if verification is not None and hasattr(verification, 'model_dump')
                    else {'is_valid': bool(verification is not None
                                           and verification.is_valid)})
            vjson = json.dumps(vres, ensure_ascii=False, default=str)
            logs = json.dumps({'trace': trace or {},
                              'answer_confidence': answer_confidence,
                              'clarify': clarify}, ensure_ascii=False)
            retr = json.dumps({'search_query': search_query, 'evidences': evs},
                              ensure_ascii=False)
            prompt = json.dumps({'history': history[-4:]}, ensure_ascii=False)
            conn.execute(
                'INSERT INTO debug_dump (dump_id, trigger_type, query,'
                ' retrieval_result, prompt, llm_output, verification_result, logs)'
                ' VALUES (?,?,?,?,?,?,?,?)',
                (f'dump_{ULID()}', 'user_export', query, retr, prompt,
                 (answer or '')[:4000], vjson, logs))
            conn.execute(
                'DELETE FROM debug_dump WHERE dump_id NOT IN ('
                ' SELECT dump_id FROM debug_dump ORDER BY created_at DESC LIMIT 1000)')
            conn.commit()
        except Exception as e:  # noqa: BLE001
            logger.warning("debug_dump 写入失败: %s", e)



    def _safe_count(conn, table: str) -> int:
        """统计失败（如 vec 扩展未加载）时降级返回 0。"""
        try:
            return conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        except Exception:
            return 0

    @app.get("/api/v1/egress/audit")
    async def egress_audit(limit: int = 50, offset: int = 0):
        """外发审计（Task 10.0 / 红线 v2 #4）：云端调用记录只读聚合。"""
        from src.core.llm.egress_audit import query_egress
        return {"code": 200, "data": query_egress(limit=limit, offset=offset)}

    @app.get("/api/v1/egress/audit/export")
    async def egress_audit_export():
        """导出全部外发记录为 JSON（落 exports 目录，经 /export/download 下载）。"""
        from src.core.llm.egress_audit import export_egress
        path = export_egress()
        return {"code": 200, "data": {"name": path.name, "path": str(path)}}

    @app.post("/api/v1/documents/{old_doc_id}/migrate-patches")
    async def migrate_patches_api(old_doc_id: str, request: Request):
        """Task 10.4：旧版文档补丁跨修订平移到新版（三分支：平移/冲突入队/孤儿入队）。"""
        body = await request.json()
        new_doc_id = body.get("to")
        if not new_doc_id:
            return _json_error(422, "missing_target", "缺少目标文档 id (to)")
        from src.core.storage import clause_repo
        out = clause_repo.migrate_patches(old_doc_id, new_doc_id)
        return {"code": 200, "data": out}

    # ===== Task 12.1 Office 往返编辑 =====

    @app.post("/api/v1/clauses/{clause_revision_id}/office-edit")
    async def office_edit_start(clause_revision_id: str, request: Request):
        from src.core.exports.office_roundtrip import create_edit_session
        from src.core.exceptions import KnowledgeStationError
        rect = None
        try:
            body = await request.json()
            rect = body.get("rect") if isinstance(body, dict) else None
        except Exception:
            rect = None
        try:
            sess = create_edit_session(clause_revision_id, rect=rect)
        except KnowledgeStationError as e:
            return _json_error(404, e.code, str(e))
        return {"code": 200, "data": sess.to_dict()}

    @app.get("/api/v1/clauses/office-edit/poll")
    async def office_edit_poll(session_id: str):
        from src.core.exports.office_roundtrip import poll_edit_session
        from src.core.exceptions import KnowledgeStationError
        try:
            sess = poll_edit_session(session_id)
        except KnowledgeStationError as e:
            return _json_error(404, e.code, str(e))
        return {"code": 200, "data": sess.to_dict()}

    @app.post("/api/v1/clauses/office-edit/commit")
    async def office_edit_commit(request: Request):
        body = await request.json()
        from src.core.exports.office_roundtrip import commit_edit_session
        from src.core.exceptions import KnowledgeStationError
        try:
            out = commit_edit_session(body["session_id"])
        except KnowledgeStationError as e:
            return _json_error(422, e.code, str(e))
        return {"code": 200, "data": out}

    @app.delete("/api/v1/clauses/office-edit/{session_id}")
    async def office_edit_cancel(session_id: str):
        from src.core.exports.office_roundtrip import cancel_edit_session
        if not cancel_edit_session(session_id):
            return _json_error(404, "session_not_found", "会话不存在")
        return {"code": 200, "data": {"cancelled": True}}

    # ===== Task 12.2 双向溯源 =====

    @app.get("/api/v1/clauses/{clause_revision_id}/backlinks")
    async def clause_backlinks(clause_revision_id: str):
        from src.core.exports.backlinks import query_backlinks
        from src.core.exceptions import KnowledgeStationError
        try:
            data = query_backlinks(clause_revision_id)
        except KnowledgeStationError as e:
            return _json_error(404, e.code, str(e))
        return {"code": 200, "data": data}

    # ===== Task 12.3 批量问答 =====

    @app.post("/api/v1/batch/qa")
    async def batch_qa(request: Request):
        body = await request.json()
        questions = body.get("questions") or []
        from src.core.compliance.batch_qa import run_batch_qa
        from src.core.exceptions import KnowledgeStationError
        try:
            data = run_batch_qa(questions, body.get("budget", 20000))
        except KnowledgeStationError as e:
            return _json_error(422, e.code, str(e))
        return {"code": 200, "data": data}

    # ===== Task 11.4 本地视觉反查（截图 OCR → 检索，零云端） =====

    @app.post("/api/v1/vision/locate")
    async def vision_locate(request: Request):
        """截图/图纸反查：本地 MinerU OCR → 混合检索 → 条款定位。"""
        body = await request.json()
        image_path = body.get("image_path")
        if not image_path or not Path(image_path).exists():
            return _json_error(422, "missing_image", "缺少有效的 image_path")
        from src.core.vision.local_vision import vision_locate as do_locate
        from src.core.exceptions import KnowledgeStationError
        try:
            return {"code": 200, "data": do_locate(Path(image_path))}
        except KnowledgeStationError as e:
            return _json_error(422, e.code, str(e))

    # ===== Task 13.5 快照备份与回滚 =====

    @app.post("/api/v1/snapshots")
    async def create_snapshot(request: Request):
        body = await request.json()
        from src.core.storage.backup import create_snapshot as do_snapshot
        snap_type = body.get("type", "manual")
        return {"code": 200, "data": do_snapshot(snap_type)}

    @app.get("/api/v1/snapshots")
    async def list_snapshots():
        from src.core.storage.backup import list_snapshots as do_list
        return {"code": 200, "data": do_list()}

    @app.post("/api/v1/snapshots/{snapshot_id}/restore")
    async def restore_snapshot(snapshot_id: str):
        from src.core.storage.backup import restore_snapshot as do_restore
        from src.core.exceptions import KnowledgeStationError
        try:
            return {"code": 200, "data": do_restore(snapshot_id)}
        except KnowledgeStationError as e:
            status = 404 if e.code in ("snapshot_not_found", "snapshot_file_missing") else 422
            return _json_error(status, e.code, str(e))

    @app.post("/api/v1/documents/impact")
    async def impact_analysis(request: Request):
        """R49 影响面分析：旧版被新版替代的影响统计。"""
        body = await request.json()
        from src.core.storage.impact import analyze_impact
        try:
            return {"code": 200, "data": analyze_impact(
                body["old_doc_id"], body["new_doc_id"])}
        except Exception as e:
            return _json_error(404, "impact_error", str(e))

    @app.get("/api/v1/diagnostics/health-board")
    async def health_board():
        """P8 健康看板：六引擎状态 + 知识库统计。"""
        from src.core.retrieval import embedder
        from src.core.ingestion.mineru_adapter import mineru_available
        conn = get_db_connection()
        try:
            conn.execute("SELECT 1")
            db_ok = True
        except Exception:
            db_ok = False
        from src.core.config import get_settings
        return {
            "code": 200,
            "data": {
                "status": "healthy" if db_ok else "degraded",
                "engines": {
                    "db": "ok" if db_ok else "error",
                    "vector": "ok" if embedder.is_available() else "offline",
                    "fts": "ok",
                    "parser": "ok" if mineru_available() else "not-installed",
                    "llm": "configured" if get_settings().llm_api_key else "not-configured",
                    "alias": "active",
                },
                "stats": {
                    "documents": conn.execute("SELECT COUNT(*) FROM doc_meta").fetchone()[0],
                    "clauses": conn.execute("SELECT COUNT(*) FROM clause_revision").fetchone()[0],
                    "vectors": _safe_count(conn, "clause_vec"),
                    "patches": conn.execute("SELECT COUNT(*) FROM clause_patch").fetchone()[0],
                    "aliases": conn.execute("SELECT COUNT(*) FROM alias_store").fetchone()[0],
                    "reviews": conn.execute(
                        "SELECT COUNT(*) FROM review_task").fetchone()[0],
                    "debug_dumps": conn.execute(
                        "SELECT COUNT(*) FROM debug_dump").fetchone()[0],
                },
            },
        }

    @app.get("/api/v1/diagnostics/debug-dumps")
    async def debug_dumps(limit: int = 20):
        conn = get_db_connection()
        rows = conn.execute(
            "SELECT dump_id, trigger_type, query, created_at, llm_output, logs"
            " FROM debug_dump ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        return {"code": 200, "data": [dict(r) for r in rows]}

    def _expand_title_clauses(evidences: list) -> list:
        """标题条款（如 8.1 作业分级）自动附带其子条款（8.1.1~8.1.3），
        保证分级/要求类回答拿到内容条款而非只有标题。"""
        import re as _re
        conn = get_db_connection()
        out: list = []
        seen: set[str] = set()
        for e in evidences:
            if e.clause_revision_id in seen:
                continue
            seen.add(e.clause_revision_id)
            out.append(e)
            no = e.clause_number or ""
            is_title = bool(_re.fullmatch(r'[0-9]+(?:[.][0-9]+)*', no)) and len(e.content_text or "") < 80
            if is_title:
                subs = conn.execute(
                    "SELECT clause_revision_id FROM clause_revision"
                    " WHERE doc_id=? AND clause_number LIKE ? ORDER BY rowid LIMIT 4",
                    (e.doc_id, no + ".%")).fetchall()
                for s in subs:
                    if s["clause_revision_id"] in seen:
                        continue
                    seen.add(s["clause_revision_id"])
                    sub = _fetch_clause(conn, s["clause_revision_id"])
                    if sub is not None:
                        out.append(sub)
        return out[:8]

    def _fetch_clause(conn, cid: str):
        from src.core.storage.clause_repo import fetch_full_clause
        return fetch_full_clause(conn, cid)

    def _answer_confidence(verification, ev_dicts: list) -> dict:
        """R24 答案层置信度分级（三档）。

        high: 核验通过 且 全部证据高可信（type_confidence>=0.85 且非存疑）
        mid : 核验通过，但存在中/低可信或存疑证据
        low : 核验未通过（存在被拦截项）
        """
        reasons = []
        if not verification.is_valid:
            reasons.append("核验拦截项未清零")
            return {"level": "low", "reasons": reasons}
        low_conf = [e["clause_number"] for e in ev_dicts
                    if e.get("is_suspicious") or (e.get("type_confidence") or 1) < 0.85]
        if low_conf:
            reasons.append(f"证据存疑/低可信: {'、'.join(low_conf[:4])}")
            return {"level": "mid", "reasons": reasons}
        reasons.append("核验通过且证据高可信")
        return {"level": "high", "reasons": reasons}

    def _html_to_text(html: str | None, limit: int = 400) -> str:
        """表格 html → 紧凑纯文本（证据 prompt / table_md 用）。解码 HTML 实体 + <eq> 公式转可读。"""
        if not html:
            return ""
        import re
        from src.core.text_utils import html_unescape, clean_eq_tags
        t = clean_eq_tags(html)
        t = re.sub(r"</t[dh]>", " | ", t)
        t = re.sub(r"</tr>", "\n", t)
        t = re.sub(r"<[^>]+>", "", t)
        t = html_unescape(t)
        t = re.sub(r"[ \t\u3000]+", " ", t)
        t = re.sub(r"(?m) \| +$", "", t)  # 去掉行尾多余分隔符（避免表格多出空列）
        return re.sub(r"\n{2,}", "\n", t).strip()[:limit]

    def _normalize_wraps(s: str | None) -> str:
        """OCR 折行拼接（统一走 src.core.text_utils.normalize_wraps）。
        修复 2026-08-23：_content_html 转 <p> 前必须先拼折行，否则卡片出现 OCR 多余回车。"""
        from src.core.text_utils import normalize_wraps
        return normalize_wraps(s)

    def _content_html(content_text: str | None, content_markdown: str | None) -> str:
        """条款展示用完整富文本 html：正文段落（保留编辑保存的 <sup>/<sub>/<b>/<i>）+ 表格 html。
        content_markdown 语义 = 富文本片段（编辑保存时含正文+表格；pipeline 只存表格 html）。
        - <eq>LaTeX</eq> 公式 → 可读 Unicode 文本（h_w/m 等）
        - 正文剔除与表格重复的文字块（MinerU 把表格文字也抽进正文 → 卡片重复显示的根因）"""
        import re as _re
        from src.core.text_utils import strip_embedded_table_text, clean_eq_tags
        md = clean_eq_tags((content_markdown or "").strip())
        if md and (_re.search(r"<p[ >]", md) or _re.search(r"<sup[ >]|<sub[ >]", md)):
            return md  # 已是完整富文本片段（编辑保存路径）
        # 旧数据/pipeline：content_markdown 只有表格 html → 正文转段落 + 表格
        # 先做 OCR 折行拼接 + 剔除与表格重复的文字（传原始表格 html 供 token 提取）
        body_text = strip_embedded_table_text(
            _normalize_wraps(content_text), clean_eq_tags(md))
        from src.core.text_utils import html_unescape as _unesc
        paras = []
        for line in body_text.splitlines():
            line = _unesc(line).strip()   # 还原库内已有实体（&lt;→<），下方统一重新转义
            if not line:
                continue
            line = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            paras.append(f"<p>{line}</p>")
        body = "".join(paras)
        if md and "<table" in md:
            body += md
        return body


    def _full_evidence(ev_dicts: list) -> list:
        """核验输入用全量条款文本（ev_dicts 的 content_text 被截断，
        数值可能落在截断外导致核验误判——v5 实测修复：核验器从 DB 拉全量）。"""
        try:
            conn = get_db_connection()
            ids = [e["clause_revision_id"] for e in ev_dicts]
            full = {}
            if ids:
                ph = ",".join("?" * len(ids))
                for r in conn.execute(
                        f"SELECT clause_revision_id, content_text, modality, exception,"
                        f" subject, knowledge_type, modality_strength FROM clause_revision"
                        f" WHERE clause_revision_id IN ({ph})", ids).fetchall():
                    full[r["clause_revision_id"]] = dict(r)
        except Exception:
            return ev_dicts
        out = []
        for e in ev_dicts:
            d = dict(e)
            f = full.get(e["clause_revision_id"])
            if f:
                d["content_text"] = f["content_text"]
                d["modality"] = f["modality"]
                d["exception"] = f["exception"]
                d["subject"] = f["subject"]
            out.append(d)
        return out


    def _ev_dict(c, bm_keys: set, ann_cache: dict):
        # 阶段4 富化：收藏/批注/置信度（R24/R25/R33）
        from src.core.query import understanding as _qu
        anns = ann_cache.get(c.clause_key) or []
        patch_records = [dict(r) for r in get_db_connection().execute(
            "SELECT field_name, patched_value, patch_reason, created_at, updated_at"
            " FROM clause_patch WHERE clause_revision_id=?"
            " ORDER BY updated_at DESC", (c.clause_revision_id,)).fetchall()]
        # 人工核对确认（R-核对）：用户按原文核对后标为可信 → 后台联动可信 + 置信度提升
        user_confirmed = any(
            p.get("field_name") == "user_confirmed"
            and str(p.get("patched_value", "")).lower() in ("true", "1")
            for p in patch_records)
        return {
            "clause_revision_id": c.clause_revision_id,
            "doc_id": c.doc_id,
            "clause_key": c.clause_key,
            "knowledge_type": c.knowledge_type,
            "hierarchy_label": _qu.hierarchy_label(c),
            "modality": c.modality,
            "modality_strength": c.modality_strength,
            "standard_no": c.standard_no,
            "clause_number": c.clause_number,
            "title": c.title,
            "page_start": c.page_start,
            "legal_status": c.legal_status,
            "source_spans": [
                {"page_number": s.page_number, "bbox": s.bbox} for s in c.source_spans],
            "content_text": c.content_text[:800],
            "content_html": _content_html(c.content_text, c.content_markdown),
            "table_summary": c.table_summary,
            "table_md": _html_to_text(c.content_markdown),
            "patched_fields": c.patched_fields,
            "patch_records": patch_records,
            "user_confirmed": user_confirmed,
            "type_confidence": max(c.type_confidence or 0, 0.9) if user_confirmed else c.type_confidence,
            "is_suspicious": False if user_confirmed else c.is_suspicious,
            "bookmarked": c.clause_key in bm_keys,
            "annotations": [{"annotation_id": a["annotation_id"],
                             "content": a["content"],
                             "annotation_type": a["annotation_type"]} for a in anns],
            "expanded_from": None,
        }

    def _placeholder_answer(query: str, evidences) -> str:
        if not evidences:
            return f"未在本地知识库中检索到与「{query}」相关的现行有效条款。请先导入文档。"
        lines = [f"根据本地知识库检索（第一阶段占位答案，未接入大模型）：", ""]
        for c in evidences:
            ref = f"[引用:{c.standard_no}-{c.clause_number}]"
            lines.append(f"- {c.standard_no} 第 {c.clause_number} 条：{c.content_text[:200]} {ref}")
            lines.append(f"  （第 {c.page_start} 页）")
        return "\n".join(lines)

    def _sse(event: str, data: dict) -> str:
        return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"

    # ===== 阶段六·批次5：更新模块 API 接线（pipeline/02 §3；鉴权/包裹格式与全站一致）=====

    # 运行中巡检批次的进程内登记（与 DB status='running' 构成双闸，防并发巡检）
    import threading
    _upd_runs_lock = threading.Lock()
    _upd_runs: set[str] = set()

    def _upd_error(e: Exception):
        """UpdateError/KnowledgeStationError → 业务错误响应：
        not_found 族（UPD-2003 批次 / UPD-2002 变更）→ 404，其余校验/冲突 → 422。"""
        from src.core.update.channels.base import (
            UPD_BATCH_NOT_FOUND, UPD_CHANGE_NOT_FOUND)
        code = getattr(e, "code", "internal_error")
        status = 404 if code in (UPD_BATCH_NOT_FOUND, UPD_CHANGE_NOT_FOUND) else 422
        return _json_error(status, code, str(e))

    @app.post("/api/v1/update/check")
    async def update_check(request: Request):
        """一键检查更新（F-01）：建 manual 巡检批次 → 后台线程执行，响应立即返回。

        - 已有运行中的巡检批次（DB running 或本进程在跑）→ 409/UPD-2001 拒绝，
          绝不并发巡检；
        - ``tier`` 可选：tier0（默认，特别关注 ∪ 未首检）/ tier1（全库滚动）；
        - 后台执行沿用 fire-and-forget daemon 线程模式（同 office_roundtrip /
          watcher 的轻量线程口径），前端经 GET /update/batch/{id} 1s 轮询进度。
        """
        import threading
        from src.core.update import inspector
        from src.core.update.channels.base import UPD_BATCH_ALREADY_RUNNING
        try:
            body = await request.json()
        except Exception:
            body = {}
        tier = body.get("tier") or "tier0"
        with _upd_runs_lock:
            conn = get_db_connection()
            row = conn.execute(
                "SELECT batch_id FROM bulk_import_batch"
                " WHERE batch_kind='inspect' AND status='running'"
                " ORDER BY created_at DESC LIMIT 1").fetchone()
            running_id = next(iter(_upd_runs), None) or \
                (row["batch_id"] if row else None)
            if running_id:
                return _json_error(409, UPD_BATCH_ALREADY_RUNNING,
                                   f"已有运行中的巡检批次: {running_id}")
            try:
                batch = inspector.create_inspect_batch(tier=tier, trigger="manual")
            except Exception as e:  # noqa: BLE001 — 非法 tier 等 → 校验层错误
                return _json_error(422, getattr(e, "code", "UPD-3005"), str(e))
            _upd_runs.add(batch["batch_id"])   # 先登记再起线程，闭合竞态窗口

        def _run():
            try:
                inspector.run_batch(batch["batch_id"])
            except Exception as exc:  # noqa: BLE001 — 后台线程必须吞异常存活
                logger.warning("update batch %s 执行失败: %s",
                               batch["batch_id"], exc)
            finally:
                with _upd_runs_lock:
                    _upd_runs.discard(batch["batch_id"])

        threading.Thread(target=_run, name=f"ks-update-run-{batch['batch_id']}",
                         daemon=True).start()
        return {"code": 200, "status": "success",
                "data": {"batch_id": batch["batch_id"],
                         "status": batch["status"], "total": batch["total"]}}

    @app.get("/api/v1/update/batch/{batch_id}")
    async def update_batch_progress(batch_id: str):
        """进度+统计（前端任务小卡片 1s 轮询，契约明确不走 SSE）。"""
        from src.core.update import inspector
        batch = inspector.get_inspect_batch(batch_id)
        if batch is None:
            return _json_error(404, "UPD-2003", f"批次不存在: {batch_id}")
        out = {k: v for k, v in batch.items() if k != "checkpoint_json"}
        try:
            ckpt = json.loads(batch.get("checkpoint_json") or "{}")
            if not isinstance(ckpt, dict):
                ckpt = {}
        except (TypeError, ValueError):
            ckpt = {}
        out["pause_reason"] = ckpt.get("pause_reason")
        out["pending"] = len(ckpt.get("queue") or [])
        return {"code": 200, "status": "success", "data": out}

    @app.post("/api/v1/update/batch/{batch_id}/pause")
    async def update_batch_pause(batch_id: str):
        """断点暂停：运行中在块边界落 checkpoint 后转 paused；幂等；不存在 → 404。"""
        from src.core.exceptions import KnowledgeStationError
        from src.core.update import inspector
        try:
            out = inspector.pause_batch(batch_id)
        except KnowledgeStationError as e:
            return _upd_error(e)
        return {"code": 200, "status": "success", "data": out}

    @app.post("/api/v1/update/batch/{batch_id}/resume")
    async def update_batch_resume(batch_id: str):
        """断点恢复：仅 paused 可续跑（后台线程执行，不阻塞响应）；
        不存在 → 404/UPD-2003；终态 → 422/UPD-3005；running/pending 原样返回。"""
        import threading
        from src.core.update import inspector
        batch = inspector.get_inspect_batch(batch_id)
        if batch is None:
            return _json_error(404, "UPD-2003", f"批次不存在: {batch_id}")
        if batch["status"] in ("done", "failed"):
            return _json_error(422, "UPD-3005",
                               f"批次已终态({batch['status']})，拒绝重启: {batch_id}")

        def _run():
            try:
                inspector.resume_batch(batch_id)
            except Exception as exc:  # noqa: BLE001 — 后台线程吞异常存活
                logger.warning("update batch %s 恢复失败: %s", batch_id, exc)

        if batch["status"] == "paused":
            threading.Thread(target=_run, name=f"ks-update-resume-{batch_id}",
                             daemon=True).start()
        return {"code": 200, "status": "success", "data": batch}

    @app.get("/api/v1/update/batches")
    async def update_batches(limit: int = 20):
        """历史批次（created_at 倒序）。"""
        from src.core.update import change_repo
        return {"code": 200, "status": "success",
                "data": change_repo.list_batches(limit)}

    @app.get("/api/v1/update/changes")
    async def update_changes(batch_id: str | None = None,
                             change_type: str | None = None, limit: int = 200):
        """变更明细（三色列表数据源）；可按批次 / change_type 过滤。"""
        conn = get_db_connection()
        where, args = [], []
        if batch_id:
            where.append("batch_id=?")
            args.append(batch_id)
        if change_type:
            where.append("change_type=?")
            args.append(change_type)
        sql = "SELECT * FROM update_change_event"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY detected_at DESC, change_id DESC LIMIT ?"
        args.append(int(limit))
        rows = conn.execute(sql, args).fetchall()
        return {"code": 200, "status": "success",
                "data": [dict(r) for r in rows], "total": len(rows)}

    @app.post("/api/v1/update/changes/{change_id}/ack")
    async def update_change_ack(change_id: str, request: Request):
        """用户确认变更事件（body 可选 {"ack": bool}，缺省确认）。"""
        from src.core.exceptions import KnowledgeStationError
        from src.core.update import change_repo
        try:
            body = await request.json()
        except Exception:
            body = {}
        try:
            out = change_repo.mark_ack(change_id, bool(body.get("ack", True)))
        except KnowledgeStationError as e:
            return _upd_error(e)
        return {"code": 200, "status": "success", "data": out}

    @app.post("/api/v1/update/changes/{change_id}/manual")
    async def update_change_manual(change_id: str, request: Request):
        """人工维护法律状态 ``{legal_status,note}``（manual 渠道语义）。

        非法枚举 → 422/UPD-3001（base.py 冻结错误码表：3001=illegal_legal_status；
        3003 为 batch_not_found，故此处按模块实现抛出的校验层码透传）。
        """
        from src.core.exceptions import KnowledgeStationError
        from src.core.update import change_repo
        try:
            body = await request.json()
        except Exception:
            body = {}
        legal_status = body.get("legal_status")
        if not legal_status:
            return _json_error(422, "UPD-3001", "缺少 legal_status")
        try:
            out = change_repo.manual_status(change_id, str(legal_status),
                                            body.get("note"))
        except KnowledgeStationError as e:
            return _upd_error(e)
        return {"code": 200, "status": "success", "data": out}

    @app.post("/api/v1/update/report/{batch_id}")
    async def update_report(batch_id: str):
        """生成《更新检查报告》docx 到 exports 目录，返回下载文件名
        （配合既有 GET /export/download 下载）；批次不存在 → 404/UPD-2003。"""
        from src.core.exceptions import KnowledgeStationError
        from src.core.update import report as upd_report
        try:
            path = upd_report.export_batch_report(batch_id)
        except KnowledgeStationError as e:
            return _upd_error(e)
        return {"code": 200, "status": "success",
                "data": {"path": str(path), "name": Path(path).name}}

    # ---- 找标（F-15~F-18）----

    @app.post("/api/v1/discover/classify")
    async def discover_classify(request: Request):
        """口语描述 → CCS 分类路径或一轮追问（协议对齐问答追问 v2）。"""
        from src.core.update import discover
        try:
            body = await request.json()
        except Exception:
            body = {}
        result = discover.classify(str(body.get("description") or ""))
        return {"code": 200, "status": "success", "data": result}

    @app.post("/api/v1/discover/search")
    async def discover_search(request: Request):
        """按分类路径查网络渠道出结果卡片；drill_level>3 → 422/UPD-3002。"""
        from src.core.exceptions import KnowledgeStationError
        from src.core.update import discover
        try:
            body = await request.json()
        except Exception:
            body = {}
        raw_path = body.get("category_path")
        if isinstance(raw_path, str):
            path = [p for p in raw_path.split("/") if p.strip()]
        elif isinstance(raw_path, list):
            path = [str(p).strip() for p in raw_path if str(p).strip()]
        else:
            return _json_error(422, "missing_category_path",
                               "缺少 category_path")
        try:
            cards = discover.search(path, body.get("drill_level", 1))
        except KnowledgeStationError as e:
            return _upd_error(e)
        return {"code": 200, "status": "success", "data": cards}

    @app.get("/api/v1/discover/watchlist")
    async def watchlist_get():
        """待下载清单（F-18 暂存批量处理）。"""
        from src.core.update import discover
        return {"code": 200, "status": "success",
                "data": discover.download_later_list()}

    @app.post("/api/v1/discover/watchlist")
    async def watchlist_post(request: Request):
        """加入/移除待下载清单：``{action:'add'|'remove', standard_no, name?}``。
        add 按 norm_no 幂等去重；remove 不存在项为无操作；均返回移除后的剩余清单。"""
        from src.core.exceptions import KnowledgeStationError
        from src.core.update import discover
        try:
            body = await request.json()
        except Exception:
            body = {}
        action = body.get("action")
        standard_no = str(body.get("standard_no") or "").strip()
        if action not in ("add", "remove"):
            return _json_error(422, "invalid_action",
                               "action 必须为 add|remove")
        if not standard_no:
            return _json_error(422, "missing_standard_no", "缺少 standard_no")
        try:
            if action == "add":
                items = discover.download_later_add(
                    standard_no, str(body.get("name") or ""))
            else:
                items = discover.download_later_remove(standard_no)
        except KnowledgeStationError as e:
            return _upd_error(e)
        return {"code": 200, "status": "success",
                "data": {"items": items, "total": len(items)}}

    # ---- 领域订阅（F-13/A15）----

    @app.get("/api/v1/update/subscriptions")
    async def subscriptions_get():
        """领域订阅列表：vocab 全量 + 每域 enabled 开关（缺省全开）。"""
        from src.core.update import subscriptions
        active = set(subscriptions.get_subscriptions())
        return {"code": 200, "status": "success",
                "data": {"vocab": list(subscriptions.DOMAIN_VOCAB),
                         "domains": [{"tag": t, "enabled": t in active}
                                     for t in subscriptions.DOMAIN_VOCAB]}}

    @app.put("/api/v1/update/subscriptions")
    async def subscriptions_put(request: Request):
        """全量替换式保存订阅：``{tags: ["消防","危化"]}``；非法 tag → 422/UPD-3001。"""
        from src.core.update import subscriptions
        try:
            body = await request.json()
        except Exception:
            body = {}
        tags = body.get("tags")
        if not isinstance(tags, list) or not all(isinstance(t, str) for t in tags):
            return _json_error(422, "invalid_tags", "tags 必须为字符串数组")
        try:
            saved = subscriptions.set_subscriptions(tags)
        except ValueError as e:
            return _json_error(422, "UPD-3001", str(e))
        return {"code": 200, "status": "success",
                "data": {"domains": [{"tag": t, "enabled": t in saved}
                                     for t in subscriptions.DOMAIN_VOCAB]}}

    # ---- 万级批量导入（pipeline/11：快扫→异步解析→首检入列）----

    @app.post("/api/v1/ingest/bulk")
    async def bulk_ingest_start(request: Request):
        """启动批量导入：``{src_dir, batch_size?=200}`` → 后台线程快扫建目录，返回 {batch_id}。"""
        from src.core.exceptions import KnowledgeStationError
        from src.core.ingestion import bulk as bulk_ingest
        try:
            body = await request.json()
        except Exception:
            body = {}
        src_dir = str(body.get("src_dir") or "").strip()
        if not src_dir:
            return _json_error(422, "missing_src_dir", "缺少 src_dir")
        try:
            batch = bulk_ingest.create_bulk_batch(
                src_dir, int(body.get("batch_size") or bulk_ingest.DEFAULT_BATCH_SIZE))
        except KnowledgeStationError as e:
            return _upd_error(e)
        bid = batch["batch_id"]

        def _run():
            try:
                bulk_ingest.fast_scan(bid)
            except Exception:  # 快扫失败落批次 failed（daemon 线程不吞异常）
                b = bulk_ingest.load_batch(bid)
                if b and b["status"] == "running":
                    bulk_ingest.pause_batch(bid)

        import threading as _th
        _th.Thread(target=_run, daemon=True).start()
        return {"code": 200, "status": "success",
                "data": {"batch_id": bid, "total": batch.get("total", 0)}}

    @app.get("/api/v1/ingest/bulk/{batch_id}")
    async def bulk_ingest_status(batch_id: str):
        """批量导入进度：快扫 checked/total + 解析队列统计 + 隔离/重复错误数。"""
        from src.core.ingestion import bulk as bulk_ingest
        b = bulk_ingest.load_batch(batch_id)
        if b is None:
            return _json_error(404, "bulk_batch_not_found", "批次不存在")
        ckpt = b.get("checkpoint") or {}
        queue = ckpt.get("queue", [])
        errors = ckpt.get("errors", [])
        parsed = sum(1 for q in queue if q.get("status") == "parsed")
        return {"code": 200, "status": "success",
                "data": {
                    "batch_id": batch_id, "status": b.get("status"),
                    "total": b.get("total", 0),
                    "scanned": ckpt.get("scanned", 0),
                    "parsed": parsed,
                    "pending": sum(1 for q in queue if q.get("status") != "parsed"),
                    "errors": len(errors),
                    "pause_reason": ckpt.get("pause_reason"),
                }}

    @app.post("/api/v1/ingest/bulk/{batch_id}/resume")
    async def bulk_ingest_resume(batch_id: str, request: Request):
        """恢复解析（快扫完成后调用）：后台线程逐件解析，日预算耗尽转 paused。"""
        from src.core.exceptions import KnowledgeStationError
        from src.core.ingestion import bulk as bulk_ingest
        try:
            body = await request.json()
        except Exception:
            body = {}
        try:
            bulk_ingest.pause_batch(batch_id)  # 幂等：把 pending/running 统一为可控点
            b = bulk_ingest.load_batch(batch_id)
            if b is None:
                return _json_error(404, "bulk_batch_not_found", "批次不存在")
        except KnowledgeStationError as e:
            return _upd_error(e)
        bid = batch_id

        def _run():
            budget_raw = body.get("daily_budget")
            budget = (int(budget_raw) if budget_raw is not None
                      else bulk_ingest.DEFAULT_PARSE_DAILY_BUDGET)
            bulk_ingest.resume_batch(bid, budget)

        import threading as _th
        _th.Thread(target=_run, daemon=True).start()
        return {"code": 200, "status": "success", "data": {"batch_id": bid}}

    @app.post("/api/v1/ingest/bulk/{batch_id}/abort")
    async def bulk_ingest_abort(batch_id: str):
        """终止批次（人工清场）：pending/running/paused → failed；终止后同目录可立即新建批次。"""
        from src.core.ingestion import bulk as bulk_ingest
        b = bulk_ingest.abort_batch(batch_id)
        if b is None:
            return _json_error(404, "bulk_batch_not_found", "批次不存在")
        return {"code": 200, "status": "success",
                "data": {"batch_id": batch_id, "status": b.get("status")}}

    # ---- 数据打包 / 还原（F-26）----

    @app.post("/api/v1/data/package/export")
    async def data_package_export(request: Request):
        """全量数据包导出：``{dest_dir?}`` 缺省落 exports 目录；
        返回包目录 + manifest（含七项简报计数与 SHA-256 校验和）。"""
        from src.core.config import get_settings
        from src.core.update import data_package
        try:
            body = await request.json()
        except Exception:
            body = {}
        dest = body.get("dest_dir") or (get_settings().data_dir / "exports")
        try:
            pkg, manifest = data_package.export_package(dest)
        except Exception as e:  # noqa: BLE001 — 打包失败归一 422
            return _json_error(422, getattr(e, "code", "package_export_failed"),
                               str(e))
        return {"code": 200, "status": "success",
                "data": {"path": str(pkg), "name": pkg.name, "manifest": manifest}}

    @app.post("/api/v1/data/package/import")
    async def data_package_import(request: Request):
        """数据包导入（strict：目标库非空 → 422/UPD-3003 拒绝）：
        ``{src_path, mode?}``；成功返回含导入简报的 manifest（prepared 语义）。"""
        from src.core.exceptions import KnowledgeStationError
        from src.core.update import data_package
        try:
            body = await request.json()
        except Exception:
            body = {}
        src = body.get("src_path")
        if not src:
            return _json_error(422, "missing_src_path", "缺少 src_path")
        try:
            manifest = data_package.import_package(
                src, mode=str(body.get("mode") or "strict"))
        except KnowledgeStationError as e:
            return _upd_error(e)
        return {"code": 200, "status": "success", "data": manifest}

    # ===== 官方法规来源（LAW_SOURCE_PLAN P2）：搜索候选 / 入库 =====

    @app.get("/api/v1/laws/sources")
    async def law_sources():
        """官方来源白名单元信息（前端法规抓取面板数据源）。"""
        return {"code": 200, "status": "success", "data": [
            {"source": "flk", "name": "国家法律法规数据库",
             "home": "https://flk.npc.gov.cn/",
             "detail": "法律/行政法规/监察法规/司法解释/地方性法规（全国人大主办）"},
            {"source": "govcn", "name": "国务院政策文件库",
             "home": "https://www.gov.cn/zhengce/xxgk/gjgzk/index.htm",
             "detail": "国务院文件/部门文件（国令/国发/国办发等，按文号/机关/年份检索）"},
        ]}

    @app.post("/api/v1/laws/search")
    async def law_search(request: Request):
        """官方源搜索候选（dry-run，不落库）。
        flk:  {source:'flk', query, effective?}
        govcn: {source:'govcn', query, childtype?, year?, department?}"""
        from src.core.knowledge.law_source import flk_client as flk
        from src.core.knowledge.law_source import govcn_client as govcn
        try:
            body = await request.json()
        except Exception:
            return _json_error(422, "bad_json", "请求体非 JSON")
        source = str(body.get("source") or "flk")
        query = str(body.get("query") or "").strip()
        if not query:
            return _json_error(422, "missing_query", "缺少 query")
        try:
            if source == "flk":
                data = await asyncio.to_thread(
                    flk.search, query,
                    search_range=int(body.get("field", 1)),
                    sxx=[3] if body.get("effective") else None,
                    page=int(body.get("page", 1)),
                    page_size=min(int(body.get("size", 20)), 100))
                return {"code": 200, "status": "success",
                        "data": flk.parse_rows(data), "total": data.get("total", 0)}
            if source == "govcn":
                data = await asyncio.to_thread(
                    govcn.search, query,
                    field=str(body.get("field", "title")),
                    page=int(body.get("page", 0)),
                    size=min(int(body.get("size", 20)), 100),
                    childtype=str(body.get("childtype") or ""),
                    year=str(body.get("year") or ""),
                    department=str(body.get("department") or ""))
                rows = govcn.parse_rows(data)
                return {"code": 200, "status": "success",
                        "data": rows, "total": len(rows)}
        except ValueError as e:
            return _json_error(403, "source_not_allowed", str(e))
        except Exception as e:  # noqa: BLE001 网络/接口异常统一上报
            return _json_error(502, "source_fetch_failed", f"官方源请求失败: {e}")
        return _json_error(400, "bad_source", "source 仅支持 flk / govcn")

    @app.post("/api/v1/laws/ingest")
    async def law_ingest(request: Request):
        """官方源下载 docx → 转 PDF → 现有管线入库（同步，长任务）。
        flk:  {source:'flk', bbbs, standard_name?, domain_tags?, reingest?}
        govcn: {source:'govcn', url, standard_name?, domain_tags?, reingest?}"""
        from src.core.knowledge.law_source.ingest import (
            ingest_law_from_flk, ingest_law_from_govcn,
        )
        try:
            body = await request.json()
        except Exception:
            return _json_error(422, "bad_json", "请求体非 JSON")
        source = str(body.get("source") or "")
        tags = [str(t).strip() for t in (body.get("domain_tags") or []) if str(t).strip()]
        reingest = bool(body.get("reingest"))
        try:
            if source == "flk":
                bbbs = str(body.get("bbbs") or "")
                if not bbbs:
                    return _json_error(422, "missing_bbbs", "缺少 bbbs")
                out = await asyncio.to_thread(
                    ingest_law_from_flk, bbbs,
                    standard_name=body.get("standard_name") or None,
                    domain_tags=tags, reingest=reingest)
            elif source == "govcn":
                url = str(body.get("url") or "")
                if not url:
                    return _json_error(422, "missing_url", "缺少 url")
                out = await asyncio.to_thread(
                    ingest_law_from_govcn, url,
                    standard_name=body.get("standard_name") or None,
                    domain_tags=tags, reingest=reingest)
            else:
                return _json_error(400, "bad_source", "source 仅支持 flk / govcn")
        except ValueError as e:
            return _json_error(403, "source_not_allowed", str(e))
        except Exception as e:  # noqa: BLE001
            return _json_error(502, "ingest_failed", f"法规入库失败: {e}")
        code = 200 if out.get("status") == "ok" else 422
        return {"code": code,
                "status": "success" if code == 200 else "error",
                "data": out}

    @app.post("/api/v1/laws/check-updates")
    async def law_check_updates():
        """法规更新检查（只读）：库内官方来源文档 vs 官方源现状 → 时效变更/新版本。"""
        from src.core.knowledge.law_source.update import check_law_updates
        return {"code": 200, "status": "success",
                "data": await asyncio.to_thread(check_law_updates)}

    # ===== 法规总目录 + 点开即核验（docs/LAW_CATALOG_ONDEMAND_PLAN.md 任务 1/2）=====

    @app.get("/api/v1/laws/catalog")
    async def law_catalog(request: Request):
        """法规总目录查询（本地 law_catalog 表；flk 全量清单，任务 1）。
        ?q=标题子串 & category=分类 & sxx=时效(1废止/2已修改/3现行/4未生效)
        & page= & page_size=（上限 200；缺省 50）。"""
        from src.core.knowledge.law_source.catalog import query_catalog
        try:
            qp = request.query_params
            page_size = min(int(str(qp.get("page_size", 50) or "50")), 200)
            data = query_catalog(
                q=str(qp.get("q") or ""),
                category=str(qp.get("category") or ""),
                sxx=str(qp.get("sxx") or ""),
                page=int(str(qp.get("page", 1) or "1")),
                page_size=page_size)
        except (TypeError, ValueError) as e:
            return _json_error(422, "bad_params", f"查询参数非法: {e}")
        return {"code": 200, "status": "success", "data": data}

    @app.post("/api/v1/laws/catalog/refresh")
    async def law_catalog_refresh():
        """全量遍历 flk 官方清单入本地目录（同步长任务；分类级账本断点续传，可重复执行）。
        返回 {total, by_category, warnings, fetched, skipped, elapsed_sec, ...}。"""
        from src.core.knowledge.law_source.catalog import refresh_catalog
        try:
            data = await asyncio.to_thread(refresh_catalog)
        except Exception as e:  # noqa: BLE001 枚举/网络整体失败 → 明确报错
            return _json_error(502, "catalog_refresh_failed", f"法规目录刷新失败: {e}")
        return {"code": 200, "status": "success", "data": data}

    @app.get("/api/v1/laws/verify")
    async def law_verify(request: Request):
        """点开即核验（任务 2）：查单个 bbbs 官方效力状态，完全透传 verify_law dict。
        status=effective/superseded/withdrawn/upcoming/unmarked/not_found/unverified；
        unverified 时 retryable=true；evidence_url=官方证据页供打开。绝不抛错。"""
        from src.core.knowledge.law_source.verify import verify_law
        bbbs = str(request.query_params.get("bbbs") or "").strip()
        if not bbbs:
            return _json_error(422, "missing_bbbs", "缺少 bbbs")
        return {"code": 200, "status": "success",
                "data": await asyncio.to_thread(verify_law, bbbs)}

    return app


def bind_random() -> tuple[int, str]:
    """随机空闲端口 + 一次性 token（红线 6）。"""
    import socket
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port, secrets.token_urlsafe(32)


def run() -> None:
    import os
    import uvicorn
    port, token = bind_random()
    app = create_app(token)
    # token 通过 stdout 交给 Electron 主进程注入（P8：同时写 session 文件供启动器/前端读取）
    print(f"KNOWLEDGE_STATION_PORT={port}", flush=True)
    print(f"KNOWLEDGE_STATION_TOKEN={token}", flush=True)
    try:
        from src.core.config import get_settings
        session = get_settings().data_dir / "engine.session.json"
        session.write_text(
            json.dumps({"port": port, "token": token, "pid": os.getpid(),
                        "started_at": datetime.now().isoformat(timespec="seconds")}),
            encoding="utf-8")
    except Exception:
        pass
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")
