"""配置中心。敏感值仅经环境变量读取，禁止落明文。

Phase 9.1：llm_api_key 支持 Windows 用户注册表回退——引擎由任意进程（bash/资源管理器/
一键启动器）拉起时，环境变量可能没有 DEEPSEEK_API_KEY（setx 只写入注册表），
此处自动从 HKCU/Environment 读取，保证任何启动方式都能用上 Key（不打印、不落库）。
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _default_data_dir() -> Path:
    appdata = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
    # 支持测试/开发重定向
    override = os.environ.get("KS_DATA_DIR")
    return Path(override) if override else Path(appdata) / "KnowledgeStation"


def _read_api_key() -> str:
    env_key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if env_key:
        return env_key
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as k:
            val, _ = winreg.QueryValueEx(k, "DEEPSEEK_API_KEY")
            return str(val).strip()
    except Exception:
        return ""


@dataclass
class Settings:
    data_dir: Path = field(default_factory=_default_data_dir)
    # DeepSeek 官方 API；本地 LM Studio 时改 base_url
    llm_base_url: str = field(
        default_factory=lambda: os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com"))
    llm_model: str = field(default_factory=lambda: os.environ.get("DEEPSEEK_MODEL", "deepseek-chat"))
    # 环境变量优先；回退读 Windows 用户注册表（setx 写入位置）
    llm_api_key: str = field(default_factory=_read_api_key)

    @property
    def db_path(self) -> Path:
        return self.data_dir / "database" / "knowledge.db"

    @property
    def models_dir(self) -> Path:
        return self.data_dir / "models"

    def ensure_dirs(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.models_dir.mkdir(parents=True, exist_ok=True)


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
        _settings.ensure_dirs()
    return _settings


def reset_settings() -> None:
    """测试用：清理缓存使环境变量生效。"""
    global _settings
    _settings = None
