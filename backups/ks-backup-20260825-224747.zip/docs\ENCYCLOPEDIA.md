# KnowledgeStation 百科全书（ENCYCLOPEDIA）

> **项目全称**：通用国标与法律法规本地 AI 知识工作站（KnowledgeStation）
> **平台**：Windows 11 ｜ **文档日期**：2026-08-23（融合版，替代分散的 30 份交接/契约/框架文档的速查入口）
> **本文件定位**：本项目所有知识的**单入口百科全书**——概览、技术栈、架构、数据模型、检索链路、核验、前端、API、运维、测试、阶段史、已知坑、规则与红线，全部在此。信息不压缩，只剔除已确认过期的内容；过期项的删除理由见各节"过期待办"标注，台账见 PHASE-INDEX「增删记录」。

---

## 目录

1. [项目概览](#1-项目概览)
2. [技术栈与环境](#2-技术栈与环境)
3. [架构总览与进程模型](#3-架构总览与进程模型)
4. [数据模型与存储契约](#4-数据模型与存储契约)
5. [检索链路（六通道 + RRF + Rerank）](#5-检索链路)
6. [LLM 层与追问机制](#6-llm-层与追问机制)
7. [核验层](#7-核验层)
8. [入库管线与 bbox 契约](#8-入库管线与-bbox-契约)
9. [前端（双栏 UI / PDF 穿透 / 引用链接 / 纠错）](#9-前端)
10. [合规引擎与导出](#10-合规引擎与导出)
11. [API 与 SSE 契约](#11-api-与-sse-契约)
12. [运维（启动 / 引擎发现 / 备份 / 外发审计）](#12-运维)
13. [测试体系与 Golden Set 门禁](#13-测试体系)
14. [阶段史（phase1~14 脉络与产出）](#14-阶段史)
15. [已知坑与历史事故](#15-已知坑与历史事故)
16. [规则、红线与优先级宪法](#16-规则红线与优先级宪法)
17. [未实现 / 挂起 / 条件触发清单](#17-未实现挂起条件触发清单)
18. [文档索引与接手指南](#18-文档索引与接手指南)

---

# 1. 项目概览

## 1.1 一句话定位

把国标/法规 PDF 变成**可检索、可溯源、可纠错、可落检查表**的本地知识库：回答每条结论都带"标准号-条款号"引用，点引用即可跳到 PDF 原文对应位置黄框高亮核对；LLM 只接收"问题 + 本地检索的证据片段"；每次外发 payload 落库可审计。

## 1.2 目标用户与典型场景

- **用户**：企业安全/环保/合规/工程人员（危化、消防、施工、工贸等行业）。
- **典型问题**："动火作业怎么分级""气体探头装多高""消防疏散宽度多少""我要搞个高处作业，咋看多少级"。

## 1.3 现状痛点（产品要解决的问题）

1. 国标/法规 PDF 动辄几十上百页，条文分散，人工翻阅慢且容易漏。
2. 同一主题存在多个版本（强标/推标、已废止/未生效/替代关系），用错版本是合规事故。
3. 网上搜到的"答案"无法确认出处，通用 AI 常编造条款——**合规场景不允许不可溯源的回答**。
4. （已修订）涉密/内部场景不允许把标准内容发到云端大模型——该"零外发"红线 2026-08-23 由业主决策 **D1 废止**，改为"外发可审计"（见 §16.2）。
5. 光回答"应该做什么"不够，还要能落地：生成义务清单、检查表、制度差距分析。

## 1.4 产品形态：双栏交互

- **左栏**：对话问答（微信式气泡）+ 追问卡 + 纠错编辑（Word 式，表格可操作）。
- **右栏**：PDF 原件穿透区 + 证据卡片（置信度徽章/修订记录/收藏/批注/操作）+ 条款操作。
- **为什么双栏**：合规核对需要"一边看 AI 结论、一边看原文"同时进行；只给文字无法建立信任。

## 1.5 产品承诺（验收红线，v2 版，替代 v4.3 §1.3）

1. **可溯源**（不变）：每条结论带标准号-条款号引用，可点回原文核对。
2. **数据可信**（加强）：OCR 可纠、可体检、可集中修；修订留痕可撤销；快照不可变且 **SHA-256 可验证**；补丁作用域绑定 `(standard_id, version_id, clause_key, revision_hash)`，**解析不出的补丁拒绝落库**。
3. **版本正确**（不变）：引用自动指向现行有效版本，已废止/未生效有提示。
4. **外发可审计**（新，替代"零外发"）：每次 LLM/rerank/云解析调用的完整 payload 落库（Debug Trace 通道），用户可在 UI 查看"我的哪些内容发往了哪个服务"，可导出。红线语义从"不发"变为"**发的每一条都可见、可追责**"。
5. **额度克制**（不变）：云调用预算控制（历史截断、追问单轮封顶、月度额度看板）。
6. **引用准确率门禁**（新）：Golden Set 的引用精确率/条款召回率设阈值进 CI，检索/提示词任何改动掉指标即卡住。

## 1.6 需求编号体系（SSOT：主计划 v4.3）

- 功能需求 **R1~R79** + 法理/合规需求 **R-L1~L14** + 工程任务 **T00~T13**。
- 主计划原件：`C:/Users/Zegel/Downloads/1-v4.3 (1).md`（仓库根有工作副本 `1-v4.3 (1).md`）。
- 需求状态全量对照：`docs/onboarding/coverage-matrix.md`（94 项）；实现审计：`docs/onboarding/requirements-audit.md`。
- ⚠ 注意层次：**主计划 v4.3 是需求源头 SSOT；现行最高指导是 `docs/FRAMEWORK-v5-priority-realignment.md` + `docs/ROADMAP-v5-execution-plan.md`**（v5 框架决策已修订 v4.3 的部分红线，见 §16）。

---

# 2. 技术栈与环境

## 2.1 技术栈总表

| 层 | 技术 | 版本/说明 |
|---|---|---|
| 后端 | Python（**3.12.14**，uv 安装） | ⚠ 勿用系统 3.14（pydantic-core/fasttext 无 wheel） |
| Web 框架 | FastAPI + uvicorn | 本地引擎，随机端口 + 一次性 Bearer token |
| 数据 | SQLite 单文件（WAL） | `%APPDATA%\KnowledgeStation\database\knowledge.db`；`journal_mode=WAL`、`foreign_keys=ON`、`busy_timeout=5000` |
| 向量 | sqlite-vec（vec0，512 维） | bge-small-zh-v1.5；查询前必须 `load_vec_extension(conn)` |
| 全文 | FTS5 + jieba 预分词 | tokenize='ascii'，中文分词写入；`_fts_query()` 对分词加引号过滤 |
| Embedding | fastembed（bge-small-zh-v1.5） | 本地缓存 `%APPDATA%\KnowledgeStation\models\`，离线可用 |
| Rerank | fastembed（BAAI/bge-reranker-base） | CPU/ONNX，~400MB；离线自动降级 |
| LLM | DeepSeek（OpenAI 兼容） | 流式；Key 存环境变量 `DEEPSEEK_API_KEY`（setx 已设）或注册表回退 |
| OCR | MinerU 2.x（`mineru` 包，magic-pdf 继任） | 深度版面分析；可降级到 PyMuPDF 文本层 |
| 前端 | React 18 + Vite 5 + TypeScript | 双栏 SPA |
| PDF 渲染 | pdfjs-dist 3.11 | 连续纵向渲染 + 黄标高亮 + 方向自动补偿 |
| 编辑器 | TipTap v3（ProseMirror） | 表格增删行列/合并拆分；另走 Word/WPS 往返（D3） |
| Electron | 28（壳） | 不 spawn 引擎（Mimosa 钩子拦截），经 env 注入连接信息 |
| 代理 | Clash Verge `http://127.0.0.1:7897` | pip/uv 走环境变量；npm 已单独配置 proxy |

## 2.2 环境事实（换机器/重置环境前必读）

| 项 | 值/位置 | 说明 |
|---|---|---|
| 工作目录 | `D:\AI\work space\zcode` | 非 git 仓库（业主未要求初始化；删除即真删，文档规则见 §16.1） |
| venv | `.venv/`（3.12） | 重建：`uv venv --python 3.12 .venv` + `uv pip install --python .venv/Scripts/python.exe <依赖>`（依赖清单见 `pyproject.toml`） |
| MinerU 模型 | `C:\Users\Zegel\.cache\modelscope\models\OpenDataLab--PDF-Extract-Kit-1.0\snapshots\master`（~2GB） | 下载：`.venv/Scripts/mineru-models-download -s modelscope -m pipeline` |
| MinerU 配置 | `~/mineru.json`（新版）+ `~/magic-pdf.json`（兼容版） | 两份都在，别删 |
| 数据目录 | `%APPDATA%\KnowledgeStation\` | 可用 `KS_DATA_DIR` 环境变量重定向（测试隔离用） |
| 会话文件 | `%APPDATA%\KnowledgeStation\engine.session.json` | `{port, token, pid, started_at}`；引擎重启必变 |
| 引擎日志 | `var/engine.log` | dev_launcher 启动时写入 PORT/TOKEN 两行 |
| Node | v26.7.0 / npm 11.19.0 | 前端依赖已装（`node_modules/`） |

## 2.3 常用命令（Windows，仓库根）

```text
一键启动       .venv/Scripts/python scripts/dev_launcher.py
只起引擎       .venv/Scripts/python -m src.core.main
全量测试       .venv/Scripts/python -m pytest -q
类型检查       npx tsc --noEmit -p tsconfig.json
前端构建       npm run build（tsc + vite build）
数据库查看     %APPDATA%\KnowledgeStation\database\knowledge.db（DB Browser / sqlite3）
引擎重启       .venv/Scripts/python scripts/restart_dev.py
高亮回归验证   .venv/Scripts/python scripts/verify_highlight.py
引用链接回归   node scripts/verify_linkify.js
```

---

# 3. 架构总览与进程模型

## 3.1 分层架构

```mermaid
flowchart LR
  FE[前端 React 18 双栏 SPA<br/>App.tsx 状态机] -->|SSE/REST Bearer| ENG[引擎 FastAPI 本地进程<br/>随机端口 + 一次性 token]
  ENG --> DB[(SQLite 28 表 WAL<br/>clause_revision 快照 + clause_patch 补丁)]
  ENG --> LLM[DeepSeek 云端<br/>仅问题 + 证据片段<br/>payload 落库可审计]
  ING[入库管线<br/>MinerU 2.x / PyMuPDF] --> DB
  RET[六通道检索 + RRF + rerank] --> ENG
  VER[核验三通道<br/>数值/模态/法理] --> ENG
```

- **前端**：App.tsx 状态机（对话/引用/卡片/纠错/体检/运维）；PdfViewer（pdfjs 穿透+黄标+方向纠正）；TipTapEditor（Word 式表格纠错）；tableText.ts（三处表格统一层）。
- **引擎**：FastAPI 本地进程；query/understanding（主题/意图/槽位/追问 v2）；hybrid_engine（六通道+RRF+rerank+历史+证据链）；typed_verifier（数值/模态/法理→置信度）；deepseek_client（SYSTEM_PROMPT 规则 1~9）；compliance（义务/审查/差距/释义）；exports（Word/引用块）。
- **存储**：SQLite 单文件 WAL；clause_revision 不可变快照 + clause_patch 补丁叠加层；clause_fts FTS5 + clause_vec vec0；user/审计/版本链/运维表。
- **入库**：MinerU 2.x 版面分析（可降级）；pypdf 数字回填；三型分型/章节还原/证据边。

## 3.2 进程模型与引擎发现链

- **引擎** = 独立 Python 进程（FastAPI/uvicorn），启动绑定随机空闲端口 + 生成一次性 token，写入 `engine.session.json`。
- **前端探测链（顺序）**：Electron preload → `localStorage('engine.port'/'engine.token')` → vite env（`VITE_ENGINE_PORT`/`VITE_ENGINE_TOKEN`）→ 逐个 `/health` 探测，第一个健康者写入 localStorage 并接管。
- **坑**：
  - localStorage 键名是 `engine.port`/`engine.token`（曾误用 VITE_ENGINE_PORT 导致连不上）。
  - 重启引擎后端口/token 必变：要么重启 vite 注入新 env，要么刷新浏览器靠 localStorage 更新。
  - Windows 上 vite 默认只绑 IPv6 `[::1]`，浏览器访问 `127.0.0.1` 拒连——**dev 启动必须 `--host 127.0.0.1`**（踩过）。
  - Electron 主进程 spawn Python 被本机 Mimosa 安全钩子拦截 → 第一阶段改为 `KS_ENGINE_PORT/KS_ENGINE_TOKEN` 环境变量注入；T09 自愈拉起待安全评审。

## 3.3 目录与模块地图（文件 → 职责）

```
src/core/
  main.py                        # 引擎入口：python -m src.core.main
  api/server.py                  # FastAPI 全部 API + SSE；随机端口+token+session；认证/CORS
  config.py                      # %APPDATA%\KnowledgeStation（KS_DATA_DIR 可重定向）；Key 环境变量/注册表回退
  domain/models.py               # Pydantic 域模型（冻结契约）+ MODALITY_STRENGTH + SSE 事件枚举
  storage/
    sqlite_db.py                 # 连接管理（WAL/外键/busy_timeout）+ 单写者队列 + schema 权威 DDL
    schema.sql                   # 28 张表 + 索引（冻结，改动=契约变更）
    clause_repo.py               # 条款读写 + 补丁机制（upsert_patch/fetch_full_clause/PATCHABLE_FIELDS/migrate_patches/resolve_clause）
    user_data.py                 # 收藏/批注/项目清单/义务清单 CRUD
    versioning.py                # 版本链（R29/R42）
    impact.py                    # 影响面分析（R49）
    backup.py                    # 快照备份/恢复（VACUUM INTO + 校验和验证）
  retrieval/
    hybrid_engine.py             # 六通道混合检索+RRF+rerank+证据链扩展+历史扩展+收藏加权
    embedder.py                  # fastembed bge-small-zh-v1.5（本地缓存，离线可用）
    reranker.py                  # bge-reranker-base 重排（例外条款保护 + 离线降级）
  query/understanding.py         # 主题/意图/槽位；追问策略 v2（LLM 自判问还是答）
  knowledge/
    classifier.py                # 三型分型 + 模态抽取 + 法理要素 + 引用抽取
    alias_extract.py             # 术语别名抽取（R10/R48）
    auto_tag.py                  # 入库自动标签（规则层：standard_no/年代/代替/领域词表）
  llm/
    deepseek_client.py           # SYSTEM_PROMPT 规则 1~9 + 证据 prompt + 流式
    egress_audit.py              # record_egress/query_egress/export_egress（D2 审计）
    fewshot.py                   # R17 轻量版：feedback_log 聚类 → ≤5 条 Few-shot 注入
  verification/typed_verifier.py # 数值/模态/法理三通道核验 → 答案置信度
  ingestion/
    pipeline.py                  # 主入库管线（run_full_ingest/analyze_preview/load_middle_items/split_items_into_clauses/build_clause_models）
    mineru_adapter.py            # MinerU 2.x 深度版面分析（可降级）
    pypdf_backfill.py            # OCR 数字回填（自动打补丁）
    law_text.py                  # 章节式条款还原
    parser_worker.py             # spawn 子进程隔离解析
    docx_adapter.py / docx_ingest.py  # docx 一等公民入库（COM 转 PDF 优先 / 降级直解）
    watcher.py                   # 监听文件夹（2s 轮询，防重入队）
  compliance/
    engine.py                    # 合规审查执行（三色判定）
    obligation.py                # 义务清单/检查表
    gap_analysis.py              # 制度差距分析
    interpretation.py            # 条款释义（五要素）
    batch_qa.py                  # 批量问答（≤50 护栏）
  exports/
    report_export.py             # Word 报告/引用块导出（python-docx）
    office_roundtrip.py          # Word/WPS 往返编辑会话（start/poll/commit/cancel）
    backlinks.py                 # 双向溯源（条款 → 被谁引用）
  vision/local_vision.py         # 图片 OCR → 检索定位（MinerU 本地，零外发）
  supervisor.py                  # 引擎看门狗（崩溃重启 + 熔断）
src/renderer/
  App.tsx                        # 前端状态机（对话/引用/卡片/纠错/体检/运维）
  api.ts                         # 引擎发现链 + apiFetch/fetchPdf（Bearer 头）
  pdf/PdfViewer.tsx              # PDF 穿透：跳页 + 黄标高亮 + 方向自动纠正
  TipTapEditor.tsx               # Word 式纠错编辑器（表格增删行列/合并拆分）
  tableText.ts                   # 表格统一层（normalizeWraps/stripEmbeddedTable/mdTablesToHtml/pipeTableToHtml）
  styles.css                     # design-token 体系（:root 变量：颜色/圆角/阴影/字体）
scripts/
  dev_launcher.py                # 一键启动（起引擎→读 session→带 env 起 vite→开浏览器）
  restart_dev.py                 # kill+start+verify 原子重启
  verify_highlight.py            # 离屏 bbox 验证（框内文本==条款文本）
  verify_linkify.js              # 引用链接化防回归（9 用例）
  eval_contract.py               # 合同 ground truth 复评测
  make_handoff_zip.py            # 交接打包
  .build-electron.mjs            # Electron 构建
eval/
  golden/                        # Golden Set 冻结数据集（96 条 + knowledge-snapshot.db）
  run_benchmark.py               # 评测器（支持 --disable-channel / --with-rerank）
  baseline.json                  # 基线快照（门禁比对用）
  ablation-report.md             # 通道消融报告
tests/                           # 33 个测试文件（契约/检索/入库/API/多轮/运维/门禁）
```

---

# 4. 数据模型与存储契约

## 4.1 存储全局约定

- **单文件库**：`%APPDATA%\KnowledgeStation\database\knowledge.db`。
- **PRAGMA**：`journal_mode=WAL`、`foreign_keys=ON`、`busy_timeout=5000`。
- **28 张表 DDL 冻结于 `src/core/storage/schema.sql`**（改动 = 契约变更，必须先改 `contract.md` + `tests/test_contract.py`）。
- **主键**：ULID 字符串，前缀 `doc_`/`clrev_`/`span_`/`patch_`/`bm_`/`ann_`/`proj_`/`task_`/`pt_`/`obl_`/`edge_`/`list_`/`gap_`。
- **JSON 字段**一律存 TEXT（JSON 数组/对象）；时间统一 `datetime('now')` UTC 文本。
- **虚拟表（FTS5/vec0）不受外键级联约束**：删文档必须走 `clause_repo.delete_document()`（显式清 clause_vec/clause_fts）。
- **单写者队列**：所有写操作经 `write_queue` 表 + 后台串行消费者；启动时 processing→pending 恢复。

## 4.2 核心知识表（完整字段）

### doc_meta（文档元数据）
- `doc_id` TEXT PK(ULID)；`standard_no` TEXT UNIQUE（标准全称，如 GB 30871-2022 / 个人信息保护法）；`standard_name` TEXT（中文名称）；`short_code` TEXT（归一化检索代码）；`current_revision_id` TEXT（当前激活修订快照 ID）。
- `legal_status` CHECK（effective / upcoming / superseded / withdrawn）；`legal_hierarchy` TEXT（宪法/法律/行政法规/地方性法规/部门规章/规范性文件/GB/JGJ/DB/T/企标）；`standard_type` TEXT（mandatory / recommended）；`doc_type` TEXT（standard / 条文说明 / 立法释义 / 用户自定义 / 法律法规）；`quality_grade` TEXT（A/B/C）；`domain_tags` TEXT(JSON)（["建筑","消防"]）。
- `effective_from` / `superseded_by` / `normative_refs` TEXT（实施日期 / 替代文档ID / 引用标准号(JSON)）；`file_path` / `file_hash` TEXT（原始文件路径 + SHA-256 防重）。

### clause_revision（条款不可变快照，三型知识单元）
- `clause_revision_id` PK(ULID)；`doc_revision_id` / `doc_id`（修订归属）；`clause_key`（**稳定条款 Key = sha256(doc_id+normalized_no)[:24]，跨版本平移凭它**）；`clause_number`（条款号：5.2.3 / 第四百九十六条 / 前言N / 表N）。
- `title` / `content_text` / `content_markdown` / `table_summary`（正文；**table_md 由 content_markdown 派生，非独立字段**）；`formula_number` / `formula_desc` / `image_text`（公式/图，低频）；`hierarchy_path`（编-章-节-条路径，如 "5 > 5.2"）。
- **三型字段**：`knowledge_type`(data/rule/legal)、`type_confidence`、`modality`(严禁…鼓励)、`modality_strength`(0-5)、`modality_confidence`、`behavior_scope`、`subject`、`object`、`behavior`、`applicability_condition`、`restriction`、`exception`、`legal_refs`(JSON)。
- `is_mandatory` / `is_suspicious` / `ocr_confidence`（★强条 / 待复核 / OCR 置信度）；`content_type`（normal / 前置说明 / 附则 / 附录）；`page_start` / `page_end`；`cross_refs`(JSON) / `explanation_ref`；`content_hash`（sha256(content_text)，Phase 10.4 迁移新增，幂等回填）。
- 版本 2.1+ 新增可选字段 `patched_fields: List[str]`（读路径补丁来源标记）。

### clause_patch（纠错补丁叠加层，快照零侵入）
- `patch_id` PK ｜ `clause_revision_id` FK ｜ `field_name`（**PATCHABLE_FIELDS**：content_text / title / table_summary / content_markdown / is_suspicious / user_confirmed）｜ `patched_value` ｜ `patch_reason` ｜ `created_by` ｜ UNIQUE(clause_revision_id, field_name)。
- 读取时 `fetch_full_clause` 透明覆写；写 FTS/向量同事务重算；删除补丁按原文回算。
- **user_confirmed**（Phase 9.1 新增）：「已核对，标为可信」写 is_suspicious=false + user_confirmed=true，type_confidence 提升到 ≥0.9。

### source_span（条款物理原页坐标，bbox 契约见 §8.3）
- `span_id` PK ｜ `clause_revision_id` FK ｜ `page_number` ｜ `bbox_json` `[x0,y0,x1,y1]` ｜ `span_type`(text/table/formula/title) ｜ `sort_order`。

### clause_fts（FTS5 虚拟表）
- `clause_revision_id` / `clause_number` / `standard_no` / `title` / `content_segmented`(jieba 分词) / `modality` / `subject` / `behavior_scope_segmented`——tokenize='ascii'，中文预分词写入。

### clause_vec（vec0 虚拟表）
- `clause_revision_id` PK + `embedding` FLOAT[512]（bge-small-zh-v1.5；**查询前必须 `load_vec_extension(conn)`**）。

### evidence_edge（证据依赖图）
- `edge_id` PK ｜ `edge_type`（clause_relation/exception_relation/definition_relation/reference_relation/correction_relation）｜ `source`/`target_clause_id` FK ｜ `confidence` ｜ `status`(active/pending/rejected)。

## 4.3 用户资产表

- **user_bookmark**：bookmark_id, clause_key(绑定稳定 key), fixed_revision_id, remark, tags——收藏（检索加权 +0.15）。
- **user_annotation**：annotation_id, clause_key, content, annotation_type(personal/expert/dispute)——批注（跨版本平移不丢）。
- **project_list**：project_id, project_name, project_type(engineering/legal_compliance), clause_revision_ids(JSON)。
- **watch_list**：watch_id, doc_id FK。**feedback_log**：feedback_id, clause_revision_ids(JSON), feedback_type, feedback_content, rating。

## 4.4 合规审查表

- **review_task**：task_id, project_id FK, review_type(contract/behavior/gap_analysis), object_name/content/file_path, status(pending/analyzing/completed/failed), total/red/yellow/green_count, report_data(JSON), report_path。
- **review_point**：point_id, task_id FK, point_type, point_content, matched_clause_ids(JSON), match_scores, verdict(red/yellow/green), verdict_reason, modality_comparison, suggestion。
- **obligation_list**：list_id, business_description, mode(list/checklist), items(JSON: [{clause_revision_id, obligation_text, group, checked, question?}])。
- **gap_analysis**：gap_id, task_id FK, legal_obligation_id/text, internal_policy_section, verdict, gap_description, remediation_suggestion。
- **legal_obligation**：obligation_id, clause_revision_id FK, obligation_text, domain_tag。**internal_policy**：policy_id, policy_name, file_path, sections(JSON)。

## 4.5 运维与治理表

- **write_queue**：queue_id AUTOINC, operation_type(ingest/feedback/bookmark/annotation/version_update/review), payload(JSON), status(pending/processing/done/failed), result——单写者队列。
- **event_log**：event_id, event_type, actor(user/system/agent), target_type/id, before/after_state(JSON), metadata——统一事件模型。
- **debug_dump**：dump_id, trigger_type, query, retrieval_result, prompt, llm_output, claim_parsed, verification_result, logs——每次提问落库（默认开启，容量上限 1000 条自动清理）；**同时是 D2 外发审计的数据源**。
- **operation_log / audit_log**：log_id, operation/event_type, target_type/id, detail(JSON 已脱敏)。
- **app_config**：config_key PK, config_value, is_encrypted(DPAPI 预留)。
- **snapshot_meta**：snapshot_id, snapshot_type(auto/manual), db_checksum, file_count, clause_count。
- **remapping_queue**：queue_id, old/new_clause_key, old/new_doc_id, status(pending/confirmed/rejected)——跨版本条款映射人工确认。
- **alias_store**：alias_id, term, alias, source_type, source_doc_id, confidence, status。
- **doc_page_geometry**：doc_id+page_number PK, width/height/rotation, crop_box/media_box(JSON)。

## 4.6 补丁跨修订平移（Phase 10.4）

- **根因**：clause_key 掺 doc_id，跨版本天然不同 → 平移匹配改用 **(short_code, clause_number)**（`migrate_patches`）。
- 三分支：(a) 新条款原始值 == 补丁原始基准值 → 平移为新补丁（绑新 clause_revision_id，event_log 记录）；(b) 原始值已变化 → 进 `remapping_queue` status=pending（前端审查页提示人工确认）；(c) clause_key 在新版不存在 → remapping_queue 标记孤儿。
- content_text 补丁联动 is_suspicious 补丁（人工纠错 = 复核），平移一并处理。
- `migrate_patches` 幂等（rowcount 判重 + remapping_queue 先查后插——该表无 UNIQUE 约束）。

---

# 5. 检索链路

## 5.1 六通道混合检索（契约 §4 冻结）

通道枚举（**冻结**）：`exact | fts | vec | modality | legal_element | behavior_scope`。

| 通道 | 说明 |
|---|---|
| exact | 精确标准号-条款号查询 |
| fts | FTS5 + jieba 分词（容忍 OCR 错别字） |
| vec | fastembed 向量语义（bge-small-zh-v1.5，512 维） |
| modality | 义务模态词（应/宜/严禁…） |
| legal_element | 法理要素 |
| behavior_scope | 行为域 |

**RRF 融合**：`score = Σ w_i / (60 + rank_i)`；**exact 通道权重 2.0，modality/legal_element 0.8，behavior_scope 1.2，其余 1.0**。
默认过滤 `legal_status='superseded'`（除非 `include_superseded=true`）。

**关键实现点**：
- `expand_query_with_history`：补充式回答（以 是/对/在/属于/设备/生产/密度 等开头）并入原始问题——第二轮"是硫化氢，生产装置区域"不再脱靶（真实踩坑）。
- `expand_evidence_chain`：主证据不足时沿 evidence_edge 补引用链条款（如 4.3 引用"表2"）。
- `_expand_title_clauses`：命中纯数字标题条款（内容 <80 字）自动附带子条款（8.1 → 8.1.1~8.1.3），证据上限 8 条。
- `refine_search_query`：口语前缀清洗（我要搞个/咋看/请问），分级问法追加"分级 作业高度"，特殊作业主题追加主题词。
- `apply_condition_filter`：声明条件（甲类/高层）过滤不适用条款；`rank_with_hierarchy`：效力层级高的排前面（强标优先）。
- 收藏加权 +0.15；别名反查（alias_store）。
- 向量引擎离线时自动降级（R30）。

## 5.2 Rerank 标准阶段（Phase 10.2）

- **流程**：六通道 RRF → top-N（**N=24**）→ reranker 对 (query, content_text **截断 512 字**) 打分 → top-K（**K=6，合规审查场景 K=8**）。
- **模型**：BAAI/bge-reranker-base（fastembed/ONNX/CPU，~400MB；**bge-reranker-v2-m3 不被 fastembed 0.8 支持**，用同族 base——已记录）。
- **例外条款保护**：`_rerank_results` 中例外/引用边扩入的证据强制保留，不参与 rerank 淘汰（但书不可被挤掉，P1）。
- **降级**：模型未下载/加载失败 → 跳过 rerank 不阻塞（响应标记 `rerank_offline: true`）。
- **调试**：`search_with_details` 增加 `rerank_score` 字段。
- **性能**：rerank 打分 ~100-300ms（CPU），按 ≤350ms 总预算判断达标。
- ⚠ 门禁默认 `rerank=False`（锁基础检索质量），rerank 增量用 `--with-rerank` 专项评测。

## 5.3 通道消融结论（Phase 10.3，`eval/ablation-report.md`）

- **exact 主力**：禁用后 -38pp。
- **fts 弱**（-1.1pp）但保留。
- **vec / modality / legal_element / behavior_scope** 当前问答场景贡献 ≈0，但**不删**：vec 未来必要、behavior_scope 审查场景主力、三者按框架转型 pre-filter。
- 消融必须分"问答场景/审查场景"两组数据分别判定（behavior_scope 在审查场景是主力）。

## 5.4 Golden Set 门禁（Phase 10.1，红线 6）

- **数据集**：`eval/golden/`（96 条冻结 + 快照库 `knowledge-snapshot.db`，测试用副本非真实库）。
- **评测器**：`eval/run_benchmark.py`（输出 JSON，支持 --disable-channel / --with-rerank）。
- **基线**：`eval/baseline.json`——**exact_hit@1 0.889 / recall@5 0.978 / 核验拦截 1.0 / 合规 1.0**。
- **门禁断言**：`tests/test_golden_gate.py`——任何指标回退 >2pp 即失败（含硬底线）。
- 指标：exact_hit@1、recall@5、recall@10、citation_precision（回答引用条款号 ⊆ 证据集）、modality_intercept_rate、三色判定准确率、red_precision。

---

# 6. LLM 层与追问机制

## 6.1 调用链与额度控制

- **文件**：`src/core/llm/deepseek_client.py`（SYSTEM_PROMPT / build_evidence_prompt / build_messages / stream_chat_completion）。
- **证据 prompt 截断**：800 字符/条；**历史**：最多 4 条、每条 300 字（防膨胀省额度）。
- **Key 读取**：环境变量 `DEEPSEEK_API_KEY` 优先，回退读 HKCU\Environment 注册表（setx 写入位置）；任何启动方式都能拿到；不打印、不落库、不进代码库。
- **未配 Key 自动降级占位**（离线可用，health-board llm 显示状态）。
- **外发审计**：每次云调用完整 payload 落库（见 §12.4）。

## 6.2 SYSTEM_PROMPT 规则 1~9（用户实测调优产物，改动只能增强不能回退）

| 规则 | 内容 | 业务原因 |
|---|---|---|
| 1 | 必须依据证据作答，常识/假设可补充并标注 | 防编造；常识不浪费一轮追问 |
| 2 | 严禁提及证据外条款号；保留应/宜/严禁强度 | 合规核心：条款与义务强度不可篡改 |
| 3 | 例外（但书/除外）必述 | 只看主文会误导用户 |
| 4 | 依据不足明说"依据不足" | 不硬编 |
| 5 | 罗马数字=阿拉伯数字等价 | 中文标准混用 Ⅰ/Ⅱ/Ⅲ 与 1/2/3 |
| 6 | 末尾一句话追问（句号结尾） | 缺条件时引导补充，不用列表轰炸 |
| 7 | 常识可用（气体密度等），标注（常识） | 用户明确不满"硫化氢密度还要问" |
| 8 | 追问节制：已补充关键信息不再问次要细节 | 用户明确不满"连环次要追问" |
| 9 | 问还是答一次定夺：JSON {"ask":[≤3]} 或直接答 | v2 追问机制：一次问完、单轮封顶 |

## 6.3 追问机制演进史（v1 → v2）

- **v1（规则槽位表）**：每类意图手维护"该问哪些参数"（THEME_SLOT_KEYS/CORE_SLOTS）。问题：通用性差、追问没写进历史→每轮判首轮→连环追问、追问含次要参数。用户吐槽"越问越多"。
- **v2（LLM 单次自判，现行）**：不再有槽位表。规则 9 约定：缺关键信息且无法推断 → 只输出一行 `{"ask":["问题1","问题2","问题3"]}`（≤3 个一次问完）；否则直接作答（常识标注）。
  - 后端流式缓冲解析 ask JSON → clarify 事件；前端把追问写入 history（**关键：否则下轮仍判首轮**）；硬上限 `user_turns < 2`。
  - 实测："我要安装一个气体探头，怎么确定高度" → LLM 直接作答+一句话追问；"是硫化氢，生产装置区域" → 检索自动并入原始意图 → 命中 GB/T 50493-2019-6.1.2。
- ⚠ v1 槽位表代码（THEME_SLOT_KEYS/CORE_SLOTS/missing_core_slots/build_clarify）Phase 13.1 已删除；`extract_slots` 保留（主题作用域槽位，追问 v2 仍用）。

## 6.4 查询理解层（understanding.py）

- 意图分类（7 类）；工程/法律双 Schema 槽位识别；四档追问（**正本清源** thorough / **打破沙锅** default / **差不多就行** quick / **纯靠猜** guess）；免追问前置声明语法（`[丙类/高层民用/耐火二级] 问题`）。
- R52 互斥条件过滤（民用↔工业等）；R40 强标/层级置顶+标签；R53 依据充分度提示；R60 否定维度纠错检测。
- 协议：首轮缺核心参数 → SSE `clarify` 事件（questions/detected_slots/hint）→ done（不检索不调 LLM，零成本追问）；回答尾部追加 `[已识别参数/要素：…]` 标注。
- 主题感知（detect_theme：special_work/building/privacy/general）：特殊作业主题（高处/动火/受限空间/吊装）追问槽位为空直接检索；建筑主题追问建筑参数；隐私主题追问法律要素；分级问法（分几级/多少级）归 rule_query。

## 6.5 Few-shot 注入（R17 轻量版，Phase 13.4）

- `src/core/llm/fewshot.py`：`collect_feedback_patterns(limit=50)`（feedback_log 负向聚类）→ `inject_fewshot(system_prompt)` 追加 ≤5 条 Few-shot 示例（每条 ≤100 字，R77 预算约束）。
- **已接入**：deepseek_client.build_messages 组装 system 时调 inject_fewshot。
- **不做模型微调**；Golden Set 门禁不得回退。

---

# 7. 核验层

## 7.1 三通道核验（typed_verifier.py）

基于"证据 vs 回答"规则比对，**不改写回答**；聚合为答案置信度 high/mid/low。

| 通道 | 检查 | 违规示例 |
|---|---|---|
| 数值一致性 | 回答数值 vs 证据数值 | "25.0%→4.0%" 闭包误报（语境不同，见坑） |
| 模态强度 | 义务词强度（严禁5>禁止5>不得4>应3>宜2>可以1>鼓励0） | 应→宜（modality_weakened） |
| 法理要素 | 条款要素 vs 回答要素 | 缺失/篡改 |

**模态强度字典（权威，MODALITY_STRENGTH）**：严禁5 禁止5｜不得4 不应4 不能4｜应当3 应3 必须3｜宜2 一般应2 原则上2｜可以1 有权1 可1｜鼓励0 提倡0 支持0。

## 7.2 核验报告与置信度

- SSE `verification` 事件：`{is_valid, answer_confidence(high|mid|low), confidence_reasons[], unsupported_clauses, unverified_numbers, modality_violations, legal_element_violations}`。
- 不合格标红并列出违规项；核验通过前复制按钮禁用（防幻觉红线）。
- **核验用全量条款文本**（`_full_evidence`，不截断 300/800 字）——修复"25.0%→4.0%"误报的关键（见 §15.3）。

## 7.3 核验哲学（评审定调）

- 规则式为主，**偶发误报可接受（宁误报不漏报）**——漏报对合规的伤害 > 误报对体验的伤害。
- LLM advisory judge（10.7）：已判定**砍**（指标达标，省额度）——不实施，仅记录。

---

# 8. 入库管线与 bbox 契约

## 8.1 分层降级入库

- **识别版（有文本层）**：PyMuPDF 文本层快速路径。
- **扫描版（无文本层）**：MinerU 2.x 深度版面分析（OCR 自动判定）；`KS_MINERU_DEEP=0` 可跳过。
- **分层降级**：PyMuPDF 几何/文本 → MinerU 深度 → 失败自动降级，不阻塞入库。
- **章节式条款还原**（law_text.py）："41 xxx"→"4.1 xxx"、断行归一；条款号从正文行首提取（**5.2.1 是正文段首而非 markdown 标题，别按标题切**）。
- **三型分型**（classifier.py）：rule/data/legal + 模态抽取 + 法理要素 + 引用抽取。
- **pypdf 数字回填**（pypdf_backfill.py）：MinerU 丢数字时用 pypdf 文本层补，自动打补丁 is_suspicious=false（如 6.1.2 的"0.3m～0.6m"）。
- **OCR 换行清理**（normalizeWraps）：单换行拼接（CJK 直连、字母数字补空格）；仅当"句末标点 + 下一行是编号/表/注/第X条/图"才保留段落断行。
- **入库原子性**：先解析后单事务入库（R1）；跨 worker 崩溃的完全回滚（两阶段事务）为更高要求。
- **parser_worker**：spawn 子进程隔离解析；**必须先 result_queue.get(timeout) 再 proc.join**（大结果集先 join 死锁）。

## 8.2 docx 一等公民（Phase 11.1）

- 两档：① 本机装有 Word/WPS 时 **COM 转 PDF**（`Documents.Open → SaveAs2(FileFormat=17)`）→ 走 run_full_ingest（原生保真 + 有 bbox，优先）；② 无 Word 时 python-docx 直解（无 bbox，前端显示"原文为 Word 文档"并禁用跳页高亮）。
- COM ProgID 探测：Word.Application → Kwps.Application → wps.Application；失败静默走降级。
- 表格 → 管道 Markdown（与 table_md 同源）；R43 防重（file_hash）对 docx 同样生效。
- CLI：`python -m src.core.ingestion.docx_ingest`。

## 8.3 bbox 契约（本仓库最隐蔽的跨端约定，已两次踩坑）

- **MinerU middle.json 的 bbox 是 PDF 底部原点（左下、y 向上，页顶文本 y≈页高）**——v5 实测修正（2026-08-23），替代早期"顶部原点"的误判。
- **pipeline 原样直存 source_span**（不做翻转）；**前端 PdfViewer 用 `convertToViewportPoint(x, y)` 直接映射，禁止 H−y 翻转**。
- **历史事故（两次）**：早期误判为左上原点 → pipeline 加 `_flip_bbox` 翻转 → 前端又 H−y → **双重翻转导致黄标垂直镜像**（正文页顶、黄标页底）。`_flip_bbox` 已删除。
- 验证方法：`scripts/verify_highlight.py`（离屏把 bbox 画到 PDF，框内文本必须 = 条款文本）。
- 回归：`tests/test_pipeline.py` 断言底部原点直存语义。

## 8.4 入库自动标签（Phase 11.3）

- 规则层（必做）：standard_no / 年代号 / "代替 GB XXXX-XXXX" / 施行日期 正则（复用 R29 逻辑）；依据文件名与文首信息补 standard_name；领域词表多选（建筑/消防/合同/数据安全/劳动…）。
- **红线**：标签只写 `doc_meta` 元数据字段，**永不改写条款原文/不进入引用路径**（有断言测试）。
- LLM 层增强（云端，走 egress_audit）留待接线；置信度 <0.8 的标签进审查页待确认。

## 8.5 监听文件夹（Phase 11.2）

- `watcher.py`：2s 轮询（P4 少依赖，不用 watchdog 库）；file_hash 防重（doc_meta + 已入队清单双查）；入 write_queue；`ingest_queue_status()` 队列状态。
- ⚠ watcher 的队列 handler 需接线 run_full_ingest/run_docx_ingest（当前只入队；"入库即标签即体检"闭环待接线）[待核实当前接线状态]。

## 8.6 Dry-Run 预览（Phase 11.5）

- `pipeline.analyze_preview()`：快速文本层路径（force_deep=False）秒级预览——条款数/分型分布/可疑数/样本；**不落库断言**。
- 修复 fitz `china-s` 字体逐字 span（"5 . 2 . 1"→"5.2.1"，仅预览/降级路径用 `re.sub(r"\s*([.\d])\s*", r"\1", line)` 归一）。

## 8.7 数据体检（5 类质量问题，GET /api/v1/data/quality-issues）

1. 正文换行残留；2. 英文粘连；3. 页脚下节标题泄漏（"2 GB 3608—2025"、"4 高处作业分级"）；4. 表格列数不一致（阶梯）；5. 表格脏单元格。
- 扫描只读零副作用；判定规则放后端，前端只渲染+跳转；每条可一键 ✏️ 纠错进编辑器。

## 8.8 官方法规来源管线（2026-08-24，docs/LAW_SOURCE_PLAN.md）

法规**只从两个官方源**获取，下载带格式官方 Word → 转 PDF → 走 §8.1 标准管线（预览/高亮/目录与国标同构），替代 `law-text://inline` 纯文本直灌。

- **来源白名单**（`law_source/http.py` 强制，非白名单域抛 ValueError 拒绝）：`flk.npc.gov.cn`（含签名下载域 `flkoss.obs-bj2.cucloud.cn`）、`sousuo.www.gov.cn`、`www.gov.cn`、`gov.cn`。
- **flk 国家法律法规数据库**（公开 API，无需认证）：`POST /law-search/search/list` 搜索（searchRange 1=标题 2=正文、searchType 1=精确 2=模糊、sxx=[3] 仅有效、flfgCodeId 分类/zdjgCodeId 机关/日期区间）、`GET /law-search/search/flfgDetails?bbbs=` 详情（title/flxz 分类/zdjgName/gbrq 公布/sxrq 施行/sxx 时效 3=有效/content.children 章条结构）、`GET /law-search/download/pc?format=docx&bbbs=` 拿签名 OSS URL 下载（**勿拼 ossFile 路径**，实测返回 SPA 首页；format=pdf 部分法规空 data 回退 docx）。
- **gov.cn 政策文件库**：`GET sousuo.www.gov.cn/search-gov/data`（t=zhengcelibrary、q、searchfield、childtype=gongwen/bumenfile/otherfile、pcodeJiguan/pcodeYear/pcodeNum 文号、pubtimeyear、bmfl 部门）；结果链接字段实测是 `url`（`piclinksurl` 常空）；详情页解析标题（`<title>` 兜底去 "__…中国政府网" 后缀）/正文/官方下载链接（.docx/.doc/.ofd，白名单过滤）；公报页无下载链接 → 正文 HTML 生成 docx 兜底（`content_origin:"web"` 标记）。
- **转换链**（`law_source/convert.py`）：LibreOffice headless 主选（本机已装）→ WPS/Word COM 回退（复用 docx_adapter）。转换源头只能是官方 docx，无"网页文字版重排版"路径。
- **入库**（`law_source/ingest.py`）：`ingest_law_from_flk(bbbs)` / `ingest_law_from_govcn(url)` → docx 落 `<data_dir>/law_source/<source>/<source_id>/`（meta.json 溯源）→ `run_full_ingest(doc_type="法律法规")`；doc_meta 溯源列（幂等迁移 `ensure_law_source_columns`）：source/source_id/source_url/downloaded_at/source_status；`find_by_source` 幂等查重。
- **更新检查**（`law_source/update.py`）：detail.sxx 与入库 source_status 比对报时效变更；非有效版时同标题搜有效版报新版本（只读）。
- **CLI/API/UI**：`scripts/fetch_law.py`（flk search/match/ingest、govcn search/ingest、updates）、`scripts/reingest_laws.py`（存量重建，--dry-run）；`/api/v1/laws/sources|search|ingest|check-updates`；运维面板「📗 法规抓取」（LawFetchPanel.tsx）。
- **限速与校验**：≥0.6s/请求（http.py `_pace`）、3 次退避重试（ValueError 策略拒绝不重试透传）、下载魔数校验（docx=PK、pdf=%PDF）。

---

# 9. 前端

## 9.1 总体结构与状态机

- **App.tsx**（~1300 行）：React 18 单页状态机；chatItems（展示）/ messages（历史）分离；SSE 消费（evidence→status→delta→verification→done + clarify）；引用 linkify + 事件委托；卡片 popover；编辑模式左栏切换 TipTap；引擎发现链。
- **双栏布局**：左栏对话（.left overflow:hidden；.chat flex:1 overflow-y:auto；.input-row flex-shrink:0 固定底部）；右栏 PDF 穿透区 + 证据卡片。
- **样式**：styles.css 为 design-token 体系（`:root` 变量：--brand/--ok/--warn/--danger/--line/--sh-*/--r-*）；新增样式先查令牌，禁止散落硬编码色值；动效统一 var(--ease)；遵守 prefers-reduced-motion；数字用 font-variant-numeric: tabular-nums。
- **组件类约定**：按钮 .mini/.send-btn/.tool-btn；徽章 .badge.ok|mid|warn|patched|modality；模态 .modal-head + .modal-x（统一头部 + Esc 关闭）；开关 .switch-toggle；状态芯片 .engine-chip。
- **聊天滚动锚点**（2026-08-23 修）：`.chat` 容器挂 chatRef；编辑态（editingEv/officeSession）从有值变 null 时 `scrollTop=scrollHeight` 滚到底部——修复"编辑完证据卡回聊天默认回顶部"的用户反馈。

## 9.2 引用链接化（linkify → .cite-link → 卡片）

- **业务目标**：回答里每个"标准号-条款号"都能点：命中证据的绑 data-cid 直接定位；未命中的走 resolve 兜底（年份宽容+表回退），悬停出卡片（表格/徽章/修订记录/操作），点击跳原文。
- **技术**：`linkify(text)` 正则把编号转 `.cite-link` span；`renderMsgHtml` 顺序：先转义原始回答文本 → mdTablesToHtml → linkify（linkify 生成的 span 不能被转义）→ 换行转 br。
- **事件委托**：onAnswerHover（悬停出卡片，0.5s 渐隐 + 视口钳制）/ onAnswerClick（点击跳预览窗）。
- **data-cid**（命中证据列表）直接找 evidences；**data-resolve**（`std|num` 兜底）懒调 `resolveEv` → `GET /api/v1/clauses/resolve`（resolveCache 缓存）。
- **resolve_clause 表格回退**：clause_number 形如「表2」时，解析到正文引用该表的条款（content_text LIKE %表N%），实测 `GB 3608-2025 表2 → 4.3`。
- **坑（引用粘连，2026-08-23 修）**：条款号主分支必须保持 `(?:[0-9]+(?:\.[0-9]+)*)` 纯数字点分 + 前瞻 `(?![0-9.])`，绝不能放宽成 `[0-9A-Za-z.]+`——LLM 输出相邻引用 `[引用:A-6.6][引用:A-6.9]`，剥括号后粘连成 `A-6.6A-6.9`，贪婪字符类把 `6.6A` 整段当条款号 → data-resolve 查无此条款 → 蓝色下划线但点击/悬停全失效。回归校验：`node scripts/verify_linkify.js`（9 用例）。

## 9.3 PDF 穿透（PdfViewer）

- pdfjs-dist 3.11 连续纵向渲染；**bbox（PDF 底部原点）→ `convertToViewportPoint(x, y)` 直接画黄色覆盖层（.pdf-highlight）**（勿翻转，见 §8.3）。
- 跳转：高亮页优先渲染 + 轮询等 .pdf-highlight + scrollIntoView(center) + 已在视口内不滚动（防乱跳）；同文档点击不重载 PDF（按 doc_id 记忆 bytes）。
- 方向自动补偿：每页渲染前用文本基线矩阵检测 90/180/270° 倒置自动纠正（≥10 项且 ≥90% 一致才补偿）；换文档必须清空方向缓存 + 旧画布（防错位/残留）。
- 纯扫描页无文本层无法自动检测方向（库内抽检全部正立）；如需覆盖"文件本身倒置的扫描页"可用本地 MinerU 图片 OCR（src/core/vision/local_vision.py）。
- 目录树抽屉（140 节点）；缩放组；页码胶囊。

## 9.4 编辑器（TipTap）与表格统一层

- **TipTap v3（ProseMirror）**：工具栏（撤销/重做、B/I/S、H1-H3、列表、引用、对齐、上标/下标、表格插入/加行/删行/加列/删列/删表、合并/拆分/表头）；插入表格自动聚焦。
- **表格选中态判定**：弃用渲染期 `editor.isActive('table')`（v3 时机问题），用选区祖先链 `inTable` + selectionUpdate/transaction 强制重渲染。
- **tableText.ts 三处同源**：卡片/编辑框/回答气泡表格展示必须统一走它（normalizeWraps / stripEmbeddedTable / mdTablesToHtml / pipeTableToHtml / htmlToPlain / textToHtml），否则格式分裂。
- 保存：HTML→纯文本、表格转管道行（与卡片 table_md 同源）。
- 历史评估：Univer（0.25 在 vite 下画布空白不渲染，弃用，已删）；OnlyOffice（效果最好但镜像 2.5GB+ 需 Docker，路线移除，D3）。

## 9.5 编辑双轨（D3 落地，Phase 12.1）

- **快速小改**：TipTap 卡片内直接改（typo、单句、单元格微调），补丁闭环。
- **完整编辑（Word/WPS 往返）**：证据卡"📝 在 Word/WPS 中编辑"按钮 → 条款导出临时 docx（`%APPDATA%\KnowledgeStation\edit_sessions\{id}.docx`）→ `os.startfile()` 拉起本机 Office/WPS → 前端 1.5s 轮询 poll → mtime + 内容哈希（兼容 WPS 保存差异）→ python-docx 解析 → **白名单 schema**（段落文本/表格行列增删/单元格合并）映射为结构化补丁 → 前端 diff 预览确认落库。**越界内容（图片/样式/公式对象/文本框）→ 拒绝落库并明示**（P1 裁决：宁可拒绝不写脏补丁）。
- ⚠ 表格编辑保存：TipTap 快速修改保存时用 `getParts()` 拆分正文与表格——**正文落 content_text、表格落 content_markdown 两个补丁**（旧实现只打 content_text，表格修改不生效，2026-08-23 修）。回归：`tests/test_patches.py::test_content_markdown_patch_drives_table_md`。
- 编辑会话期间该条款前端锁定（防并发改）；会话文件定期清理。
- API：`POST /api/v1/clauses/{id}/office-edit`（start）/ `GET .../office-edit/poll` / `POST .../office-edit/commit` / `DELETE .../office-edit`（cancel）。

## 9.6 命令面板与信任验证（Phase 12.4/12.5）

- **命令面板**：Ctrl/Cmd+K palette（提问/切换审查/外发审计/导出引用/信任验证/运维/日志，输入过滤）。
- **信任验证**："✓ 信任验证"引导（3 步：提问→点引用→纠错撤销）+ 示例问题预填，替代 R50 向导。

## 9.7 外发审计面板（Phase 12.7）

- "📤 外发审计"模态：拉取 `/egress/audit` 列表（服务/时间/问题/摘要）+ 导出 JSON；兑现 phase9.2 状态栏"云增强模式 · 外发内容全程留痕"。

---

# 10. 合规引擎与导出

## 10.1 合规审查（compliance/engine.py）

- **流程**：审查点逐句抽取 → 六路匹配（风险锚点增强）→ 三色判定（🔴 违法/🟡 风险/🟢 合规）。
- 规则版为主（LLM 精判 use_llm 开关预留）；审查 SSE：point_verdict → report_ready → done。
- ground truth：16 条植入条款召回 16/16、标红精确 10/10。

## 10.2 义务清单与检查表（obligation.py）

- 输入业务描述 → 生成分组义务列表（应/必须型条款，含来源条款号）→ 转检查表（每条变"是否已落实:…?"问句）→ 勾选持久化 → 导出 Word。

## 10.3 制度差距分析（gap_analysis.py）

- 粘贴内部制度 → 与法定义务三色差距 + 整改建议（R-L12/13）。

## 10.4 条款释义（interpretation.py）

- 五要素 JSON 化：法理要素/适用情形（落入+不落入）/实务要点/关联条款/立法本意。
- 规则版为主；`use_llm=true` 增强（约 1 分钱/次，需点击才消耗）；**max_tokens=800 + 括号配对提取**（早期 250 导致 JSON 截断——保持）。

## 10.5 批量问答（batch_qa.py，Phase 12.3）

- `POST /api/v1/batch/qa`：预算护栏 ≤50 问硬截断；无 Key 走占位答案（离线零云端消耗）；每问核验标记 confidence/verified；未通过核验的在报告中**标黄而非隐藏**（P1：不粉饰）。

## 10.6 双向溯源（backlinks.py，Phase 12.2）

- `GET /api/v1/clauses/{id}/backlinks`：聚合 debug_dump（提问证据）/ user_bookmark（clause_key）/ project_list / obligation_list.items / review_point.matched_clause_ids。

## 10.7 导出（exports/report_export.py）

- 引用块（R19 标准格式，一键复制，Markdown 格式）；问答依据 Word；合规审查报告 Word；义务清单/检查表 Word。
- **导出模板自定义**（12.6）：`%APPDATA%\KnowledgeStation\templates\` 下 review-report.docx / qa-citations.docx 存在时作基础 Document；缺模板回退默认。
- 下载接口严格限定 exports 目录（路径穿越 403，有测试）。

---

# 11. API 与 SSE 契约

## 11.1 通用

- 随机端口 + 一次性 Bearer token；所有请求带 `Authorization: Bearer <token>`；**仅 `/api/v1/health` 免 token**；CORS 预检 OPTIONS 放行。
- 响应包裹 `{"code":200,"status":"success","data":...}`；错误 `{"code":<http>,"status":"error","error":"<code>","message":"..."}`。
- 未携带/错误 token 的非 health 请求一律 401。

## 11.2 端点全表

| 分组 | 端点 |
|---|---|
| 健康 | `GET /api/v1/health` → status/uptime/db_status/vector_engine/parser_worker |
| 入库 | `POST /api/v1/documents/ingest` (multipart) → doc_id/total_clauses/pages_parsed/quality_grade；`GET /api/v1/ingest/queue`（队列状态） |
| 检索问答 | `POST /api/v1/chat/completions`（SSE；可选 history/query_mode/answer_scope/免追问语法） |
| 文档 | `GET /api/v1/documents` ｜ `GET /documents/{id}/file` ｜ `GET /documents/{id}/tree` ｜ `GET /documents/{id}/versions` ｜ `POST /documents/{id}/impact`（R49 影响面） ｜ `POST /documents/{old}/migrate-patches`（补丁平移） |
| 对比 | `POST /api/v1/compare`（两文档条款对照 + 模态变化清单） |
| 补丁 | `POST/GET /api/v1/clauses/patches` ｜ `DELETE /patches/{id}`（422/404 语义） |
| 引用解析 | `GET /api/v1/clauses/resolve?standard_no&clause_number`（年份宽容 + 表回退） |
| 释义 | `GET /api/v1/clauses/{id}/interpretation`（五要素，use_llm 可选） |
| 回溯 | `GET /api/v1/clauses/{id}/backlinks`（双向溯源） |
| 编辑会话 | `POST/GET/POST/DELETE /api/v1/clauses/{id}/office-edit`（start/poll/commit/cancel） |
| 收藏/批注/项目 | `/api/v1/bookmarks` ｜ `/api/v1/annotations` ｜ `/api/v1/projects(+clauses)` CRUD |
| 合规 | `POST /api/v1/compliance/review` ｜ `POST /review/{task_id}/execute`(SSE) ｜ `/compliance/obligations(+checklist/check/build)` ｜ `/compliance/policies` ｜ `/compliance/gap-analysis` ｜ `POST /api/v1/batch/qa` |
| 导出 | `POST /api/v1/export/review/{task_id}` ｜ `/export/citations` ｜ `/export/obligations/{list_id}` ｜ `GET /export/download?name=` |
| 别名 | `POST /api/v1/aliases/extract`（R48） |
| 视觉 | `POST /api/v1/vision/locate`（贴图→条款定位，本地 MinerU OCR） |
| 外发审计 | `GET /api/v1/egress/audit?limit&offset` ｜ `GET /api/v1/egress/audit/export` |
| 快照 | `POST/GET /api/v1/snapshots`（创建/列表）｜ `POST /api/v1/snapshots/{id}/restore` |
| 日志/运维 | `GET /api/v1/operation-log` ｜ `/health-board` ｜ `/debug-dumps` ｜ `/api/v1/data/quality-issues` |

## 11.3 SSE 事件顺序（chat/completions，**冻结不得增删 reorder**）

1. `evidence` — `{evidences[], expanded_evidences[], time_warnings[]}`；证据对象含 clause_revision_id / doc_id / clause_key / knowledge_type / type_confidence / is_suspicious / bookmarked / annotations / hierarchy_label / patched_fields。
2. `status` — `{phase:"streaming_with_verification_pending"}`。
3. `delta` — `{content}` 流式片段（0..n 次）。
4. `verification` — `{is_valid, answer_confidence(high|mid|low), confidence_reasons[], unsupported_clauses, unverified_numbers, modality_violations, legal_element_violations}`。
5. `done` — `{}`。

另有 `clarify` 事件（首轮缺核心参数时替代检索+LLM）：`{intent, questions[], detected_slots, hint}` → done。

请求体扩展（向后兼容）：`history`（R60 多轮；最近 4 条、每条 300 字）；`query_mode: thorough|default|quick|guess`（R9 四档）；`answer_scope: concise|full`（R59）。

## 11.4 契约变更流程（红线）

凡动 `schema.sql` / 通道枚举与 RRF 权重 / SSE 事件顺序 / 安全条款 → **必须先改 `docs/onboarding/contract.md` + `tests/test_contract.py`，再改实现**，评审通过后方可合入。

---

# 12. 运维

## 12.1 一键启动与重启

- 一键启动：`scripts/dev_launcher.py`（删旧 session → 起引擎 → 读 session → 带 env 起 vite → 开浏览器）。
- 原子重启：`scripts/restart_dev.py`（kill+start+verify）。
- 引擎：`python -m src.core.main`（stdout 打印 PORT/TOKEN 两行；session 写 `engine.session.json`）。
- 前端单独起：`VITE_ENGINE_PORT=<port> VITE_ENGINE_TOKEN=<token> npm run dev:vite -- --host 127.0.0.1`。

## 12.2 引擎发现与连接坑

- 前端探测链：Electron preload → localStorage(engine.port/token) → vite env；任一健康即接管并写回 localStorage。
- 重启引擎后端口/token 必变：重启 vite 注入新 env 或刷新浏览器。
- Windows vite 默认只绑 [::1]：dev 必须 `--host 127.0.0.1`。

## 12.3 supervisor 与健康看板

- `supervisor.py`：引擎看门狗（崩溃重启 + 熔断）。
- `GET /api/v1/health-board`：六引擎状态（llm/vector/parser/…）+ 知识库统计。
- Debug Trace：每次提问全量落库 debug_dump（默认开启，容量 1000 条自动清理）；运维面板可展开查看 trace（理解层→检索→过滤→LLM→核验）。

## 12.4 外发审计（D2 红线落地）

- 数据源：debug_dump（每次 LLM 问答已全量落库，trigger_type='user_export'）；非 chat 云调用经 `record_egress()`（trigger_type='egress'），返回 dump_id 即 Trace ID。
- API：`GET /api/v1/egress/audit?limit&offset`（token 保护，聚合两类 trigger；默认脱敏摘要）、`GET /api/v1/egress/audit/export`（导出 JSON 至 exports 目录；完整 payload 仅用户主动导出时提供）。
- UI：顶栏"📤 外发审计"面板（Phase 12.7）。

## 12.5 快照备份与恢复（Phase 13.5）

- `src/core/storage/backup.py`：**VACUUM INTO** 在线备份到 `%APPDATA%\KnowledgeStation\backups\`；自动快照滚动保留 7 份、手动永不清理。
- 批量导入/换版前自动快照 + 每日定时滚动。
- **恢复前校验和验证**（db_checksum 不匹配拒绝——红线 2 损坏拒绝）；实际 db 替换由 supervisor/上层执行（restore 返回路径+说明）。

## 12.6 日志与调试

- 引擎日志 `var/engine.log`；vite 日志 `var/vite.log`。
- API 调试带 Bearer token：`-H "Authorization: Bearer <token>"`；`/api/v1/health` 免 token。
- **中文 JSON 走 httpx/requests，禁止 Git Bash curl 带中文**（GBK 编码写坏数据）。

---

# 13. 测试体系

## 13.1 测试基线（2026-08-23 当前）

- **pytest 351 passed + 3 skipped**（44 个测试文件）；`npx tsc --noEmit` 0 错误；`vite build` 通过。
- 演进：24→28→42→54→64→72→79→89→97→101→104→112→117→118(+1)→123(+1)→138(+2)→148(+2)→152(+2)→160(+2)→162(+2)→165(+2)→166(+2)→189(+2 更新模块契约先行)→214(+2)→247(+2)→258(+2)→269(+2)→292(+2)→293(+3)→312(+3 更新模块全量交付)→322(+3 laws_db 真机+订阅+高亮修复)→331(+3 万级批量导入)→343(+3 span 校准模块+严格防重+终止批次)→351(+3 扫描上限取消+最近行校准重构)。
- ⚠ 各旧文档中的"118 passed + 1 skipped"等数字均为历史快照，以本节为准。

## 13.2 测试文件清单（tests/ 33 个）

test_api / test_auto_tag / test_backup / test_compliance / test_contract / test_contract_eval / test_docx_ingest / test_dryrun / test_egress / test_fewshot / test_golden_gate / test_golden_set / test_patches / test_patch_migration / test_phase10_blindspots / test_phase12 / test_phase13_blindspots / test_phase4 / test_phase5 / test_phase6 / test_phase7 / test_phase8 / test_pipeline / test_r5a / test_reranker / test_retrieval / test_selfcheck_fixes / test_storage / test_supervisor / test_t06 / test_understanding / test_vision / test_watcher。

## 13.3 测试隔离约定（三次踩坑总结）

1. **共享会话级库**：conftest 用会话级 KS_DATA_DIR 临时目录（ignore_cleanup_errors=True——Windows 文件锁）。
2. **测试 id 必须完整 ULID**：前 6/8 hex 是时间戳，同毫秒碰撞（phase10/12 再现，勿再截断）。
3. **禁止绝对计数断言**：共享库下"收藏总数==1"必被其他测试污染 → 用相对断言（any(...) / 限定 doc_id）。
4. **清库禁用 `DELETE FROM sqlite_master`**（残留数据页 + 连接缓存失效）→ 用逐表 DROP + load_vec_extension。
5. 连接没关干净时 TemporaryDirectory 清理报 PermissionError → 写测试注意 `close_thread_connection()`。

## 13.4 Golden Set 门禁测试

- `tests/test_golden_gate.py`：对 `eval/golden/knowledge-snapshot.db`（真实库副本）跑指标，与 `eval/baseline.json` 比对，任何指标回退 >2pp 即失败。
- **任何检索/提示词改动必须过此门禁**（红线 6）。

## 13.5 GB30871 功能测试集（docs/onboarding/test-suite-30871.md）

- 12 组 Manual + E2E 用例（浏览器 http://localhost:5173/ 逐条执行）：R4 精确引用、R4a 模态核验、R5 六路检索、R9 理解层、R24 置信度+R53 自检、R25 收藏+R33 批注、R37 目录树+R7 穿透、R60 多轮、R79 纠错补丁、R-L6 合规审查、R-L9 义务清单、R-L14 释义。
- 消耗标注：💸 = 真实 LLM 调用（约 1~2 分钱/次）；🆓 = 零消耗。
- 判定：🟢 PASS ｜ 🔴 FAIL ｜ ⏭ SKIP（纯 UI 操作）。

---

# 14. 阶段史（phase1~14 脉络与产出）

> 完整施工日志在 `docs/onboarding/phase{N}-handover.md`。此处为脉络速览——每个阶段做了什么、测试基线、关键决策。

| 阶段 | 主题 | 测试 | 关键产出 / 决策 |
|---|---|---|---|
| **1** | 契约/脚手架/存储/六路检索 | 24 | T00 契约冻结、T01 域模型、T02 存储层、T04 六路检索；mineru 2.x 环境；Electron 骨架（Mimosa 拦截→env 注入）；两版 PDF OCR 精度对比（扫描版条款号覆盖 96.6%） |
| **2** | 入库管线/分型/核验/LLM 流式 | 42 | pipeline 完整 E1-E7 切分取代 smoke_ingest；三型分型；DeepSeek 流式接入；分型核验器 |
| **2.1** | 外部评审响应 | 54 | 纠错补丁（clause_patch）、数值核验、supervisor 看门狗 |
| **3** | 合规引擎/法律双通道/穿透高亮 | 64 | 合规审查引擎 + ground truth 16/16；证据边（evidence_edge）修复；PDF 黄标高亮 |
| **4** | "能用"档 | 72 | 收藏/批注/导出/义务清单/目录树；服务常驻可测 |
| **5** | 多轮对话/追问增强 | 79 | 多轮历史（后端 4×300 字）；核验器修复；置信度分级 |
| **6** | 版本链/对照/日志/别名 | 89 | version_chain、/compare、operation-log、alias_extract |
| **7** | 差距分析/释义/义务导出 | 97 | gap_analysis、五要素释义（max_tokens 800）、义务清单 Word |
| **8** | 运维 | 101 | session/一键启动/心跳/Debug Dump/健康看板 |
| **9** | 收尾 | 104(+1) | 影响面 R49、对话历史 localStorage、Golden Set 5/5、用户手册；补记 9.1~9.4（Key 注册表回退、理解层、追问合理性、Debug Trace 默认开） |
| **9.1** | 纠错体验升级 | 118(+1) | 编辑器工具栏全量；表2 引用回退；bbox 坐标根修+核对可信联动（user_confirmed）；OCR 换行清理；追问机制 v2（LLM 自判替代槽位表） |
| **9.2** | 前端视觉重写 | 118(+1) | styles.css 设计系统化（design tokens）+ App.tsx 8 处微调；行为零变更 |
| **10.0** | 外发审计 | 123(+1) | contract.md §5 零外发→外发可审计；egress_audit.py；审计 API |
| **10** | 准确性冲刺 | 138(+2) | Golden Set 96 条+CI 门禁（recall@5 0.978）；rerank（bge-reranker-base）；通道消融（exact 主力）；补丁跨修订平移+content_hash；P1 盲区 6 项；10.5 不触发/10.7 砍 |
| **11** | 入库便利 | 148(+2) | docx 一等公民（COM 转 PDF）；监听文件夹；自动标签（红线不碰原文）；云多模态→本地 MinerU OCR（零外发）；Dry-Run 预览 |
| **12** | 体验顺滑 | 152(+2) | Office 往返编辑（白名单 schema）；双向溯源；批量问答（≤50）；命令面板 Ctrl+K；信任验证；导出模板；外发审计面板 |
| **13** | 代码收敛 | 160(+2) | 死代码清除（UniverEditor/v1 槽位表）；编辑器双轨收敛；盲区 4 项；R17 轻量版 Few-shot；快照备份（VACUUM INTO+校验和+滚动 7） |
| **14** | 性能与交付 | 162(+2) | 性能基线（rerank ≤350ms 达标）；Electron 打包挂起（待 Mimosa 评审）；模型分发预算 |

**阶段史中的关键决策链**：
- 追问机制：v1 规则槽位表 → v2 LLM 单次自判（一次问完 ≤3、单轮封顶）。
- bbox 契约：早期"顶部原点"误判 → 双重翻转事故 → v5 实测修正为"PDF 底部原点直接映射"（两次踩坑）。
- 外发策略：零外发红线 → D1 废止 → 外发可审计（Task 10.0）。
- 编辑器：Univer 弃用 → TipTap → OnlyOffice 移除 → TipTap 小改 + Word/WPS 往返双轨（D3）。
- 打包：Electron 打包挂起（Mimosa 评审前置）；Tauri 评估撤回；维持 dev 常驻分发。

---

# 15. 已知坑与历史事故

> 全部"坑"集中于此——按重要度排序。改动相关代码前先看对应条目。

## 15.1 检索与 LLM

1. **补充式回答不并入原问题 → 检索脱靶**：`expand_query_with_history` 必须把以 是/对/在/属于/设备/生产/密度 开头的补充并入原始问题（"是硫化氢，生产装置区域"查不到 6.1.2，真实踩过）。
2. **fastembed 返回 numpy float32**：json.dumps 直接炸 TypeError → embedder 统一 `float(x)`。
3. **FTS5 语法**：分词结果含 `.` `-` 会 syntax error → `_fts_query()` 过滤+引号包裹，新增通道复用。
4. **fastembed 首次联网**：正式数据目录第一次用要联网下模型（~100MB），无代理卡死 worker → 缓存在 `%APPDATA%/KnowledgeStation/models`。
5. **证据截断 800 字/条、历史 4×300 字**：省额度防膨胀；核验用全量文本（见 §15.3）。
6. **rerank 例外条款保护**：例外/引用边扩入的证据强制保留，不参与 rerank 淘汰（但书不可被挤掉，P1）。

## 15.2 存储与并发

1. **multiprocessing.Queue 死锁**（最重要）：大结果集先 join 后取队列 = 死锁超时（300s）；parser_worker 已修——先 result_queue.get(timeout) 再 proc.join，别改回。
2. **write_queue handler 必须提交事务**：裸 db.execute 不 commit → 主线程持锁 → `database is locked`；handler 内用 `write_transaction()`。
3. **vec0 扩展按连接加载**：新连接查 clause_vec 前必须 `load_vec_extension(conn)`，否则 `no such module: vec0`。
4. **begin transaction 嵌套**：连接上有未提交隐式事务时 BEGIN IMMEDIATE 报错 → write_transaction 开头自动 commit 兜底。
5. **测试共享会话级库**：固定 ID 撞唯一约束 → 用完整 ULID + 相对断言（见 §13.3）。
6. **清库禁用 DELETE FROM sqlite_master**：残留数据页 + 连接缓存失效 → 逐表 DROP + load_vec_extension。

## 15.3 核验误报（用户实测暴露）

- **"25.0%→4.0%" 判数值篡改**：4% 是 LEL 阈值规则（AQ 3028 4.3.3），25% 是别处数值，语境不同却触发闭包比对 → **修复：核验用全量条款文本（`_full_evidence`），不截断 300/800 字**。
- **模态波动**：偶发 LLM 模态波动导致核验不过（测试套件已知 2 例弱项，良性——宁误报不漏报）。

## 15.4 bbox 坐标系（两次踩坑，见 §8.3）

- 早期误判左上原点 → pipeline `_flip_bbox` → 前端 H−y → 双重翻转黄标镜像 → 已修（底部原点直接映射，`_flip_bbox` 已删）。验证：`scripts/verify_highlight.py`。

## 15.5 前端

1. **引用粘连**（§9.2）：linkify 条款号贪婪吞相邻引用前缀 → 蓝色下划线不可点。已修（纯数字点分 + 前瞻 `(?![0-9.])`）；回归：`scripts/verify_linkify.js`。
2. **表格三处分裂**：卡片/编辑框/回答气泡必须统一走 tableText.ts。
3. **换文档竞态**：fetchPdf 异步重建期间渲染用旧 docRef → 显示错误文档内容 → 修复：立即销毁旧 doc + 清空旧画布。
4. **方向缓存跨文档污染**：orientRef 按页号存、换文档未清 → 偶发 180° → 修复：换文档重置 + 阈值收紧（≥10 项且 ≥90% 一致）。
5. **localStorage 键名**：engine.port/engine.token（曾误用 VITE_ENGINE_PORT 连不上）。
6. **TipTap `isActive('table')` 渲染期不可靠**：用选区祖先链 inTable + 强制重渲染。

## 15.6 运维与进程

1. **vite 绑 [::1] 而非 127.0.0.1**：Windows 默认 → 访问 127.0.0.1 拒连 → dev 必须 `--host 127.0.0.1`。
2. **全局 taskkill 误杀**：`taskkill /IM python.exe` 会误杀并行 mineru OCR 子进程 → 用 psutil 按 cmdline 精确匹配。
3. **setx 不注入已存在进程环境**：bash 拉起的引擎拿不到 Key → config.py 注册表回退。
4. **Windows 测试临时目录清理 PermissionError**：连接没关干净 → conftest ignore_cleanup_errors=True；测试注意 close_thread_connection()。
5. **非 git 仓库**：删除即真删——文档规则"拿不准的压缩而非删除"。
6. **PowerShell 管道读写含中文文件必坏编码**（2026-08-25，多次踩坑）：PS 5.1 的 `>` / `Set-Content` 默认写 **UTF-16LE**；`Get-Content` 不带 `-Encoding UTF8` 按 **GBK** 解码 UTF-8 → `Get-Content | Set-Content` 一轮即确定性损坏（产生 U+E21C 类非法字符）。**规则：文件内容读写一律用 write/edit 工具或 Python `open(encoding='utf-8')`，PowerShell 只执行命令**；必须用时读加 `-Raw -Encoding UTF8`、写加 `-Encoding UTF8`，Python 侧设 `$env:PYTHONUTF8='1'`。检测：文件头 `FF FE`=UTF-16、`EF BB BF`=UTF-8 BOM。

---

# 16. 规则、红线与优先级宪法

## 16.1 文档规则（2026-08-23 起，替代"只增不删"）

1. 事实源文档（MAINTAINER-GUIDE / contract.md / coverage-matrix.md / user-manual.md / PHASE-INDEX.md / 框架与路线图）**直接修订**保持最新，不搞无限追加附录。
2. 施工日志照常逐阶段写；**失去参考价值的旧日志可压缩合并**（要点并入 PHASE-INDEX 或归档单文件）。
3. 删除前置条件：内容已失效或已被更高层文档吸收；每次删除/合并在 PHASE-INDEX 末尾「增删记录」留一行。
4. 本仓库无 git 兜底，删除即真删——拿不准的内容压缩而非删除。
5. 历史 phase 日志中残留的旧规则表述，以本节为准。

## 16.2 框架决策（v5，FRAMEWORK-v5-priority-realignment.md）

| # | 决策 | 废止/变更对象 |
|---|---|---|
| D1 | **删除"零外发"验收红线**，产品效果优先；目标客群无内网隔离硬性场景 | v4.3 红线 2；R17/R45 解禁 |
| D2 | **外发可审计**成为替代性信任承诺：所有外发 payload 落库、用户可见、可导出 | 新增红线 4 |
| D3 | 复杂编辑走 **MS Word / WPS 往返通道**；TipTap 降级为"快速小改"入口 | OnlyOffice 移除；TipTap 深度魔改停止 |
| D4 | 保留 LLM/embedding/reranker 的 **backend 抽象 seam**（OpenAI 兼容）；当前全部走云端 | 保险，不为假想需求写实现 |

**v5.1 现状修订要点（2026-08-23，附录优先于正文）**：
1. LLM backend seam：formalize 现有回退链（config.py 已有），R44 离线模式降级为可选。
2. **Tauri 评估撤回**：Electron 壳已建；Mimosa 拦截是安全评审问题；维持 dev 常驻分发；打包挂起待评审。
3. bge-m3 拆序：先 Golden Set 门禁 → reranker → 消融 → 仅当数据证明 dense 弱才触发迁移（512→1024 维是契约变更）。
4. 高亮策略撤回：bbox 底部原点契约已稳定，高亮层不动。
5. 补丁作用域漏洞 → 已由 Phase 10.4 修复（平移用 short_code+clause_number）。
6. 外发可审计成本近零（debug_dump 已有数据源）。
7. OnlyOffice 未落地；死代码已由 Phase 13.1 清除。
8. 18 项测试盲区：Phase 10.6（6 项）+ Phase 13.3（4 项）已补，剩余见 coverage-matrix。

## 16.3 优先级宪法（冲突裁决）

**P1 准确性 > P2 入库便利性 > P3 体验顺滑 > P4 代码简洁 > P5 性能需求**。

裁决规则：任何两层冲突时高优先级无条件胜出。示例：
- reranker +200ms 延迟（P5 vs P1）→ 上 reranker，P5 让步。
- 通道代码绕但消融证明有贡献（P4 vs P1）→ 保留，P4 让步。
- 自动标签偶发误标（P2 副作用）→ 可接受——标签永不进入引用与原文路径。
- Word 往返解析不出干净补丁（P3 vs P1）→ 宁可拒绝落库，不写脏补丁。
- 为优雅重做存储抽象（P4）→ 否决——不服务 P1~P3 的重构一律不做。

## 16.4 工程铁律

1. 测试基线只涨不跌（当前 166+2；`tsc` 0 错误）。
2. 契约变更流程：schema / 通道枚举与 RRF / SSE 顺序 / 安全条款 → 先改 contract.md + test_contract.py。
3. 写操作走单写者队列（write_queue），不得绕过。
4. bbox 底部原点契约不要碰。
5. SYSTEM_PROMPT 规则 1~9 只能增强不能回退成纯证据主义。
6. API Key 只从环境变量/注册表读取；代码库严禁明文密钥与本机绝对路径。
7. 中文 JSON 用 httpx/requests，禁止 Git Bash curl 带中文。
8. 云调用必走 egress_audit；标签永不改写条款原文。

---

# 17. 未实现 / 挂起 / 条件触发清单

> 完整需求状态见 `docs/onboarding/coverage-matrix.md`（94 项）与 `requirements-audit.md`。以下是接手者最可能想补的项与卡点。

| 项 | 状态 | 卡点 / 建议路径 |
|---|---|---|
| 云端视觉（11.4） | 挂起（条件触发） | 已落地**本地版**（MinerU 图片 OCR，零外发）；云端视觉 API 仅在需要更强能力时选型 |
| Electron 打包 + T09 heartbeat | 挂起 | 前置 = Mimosa 安全评审放行 spawn；不做 Tauri（已撤回） |
| watcher → 入库 handler 接线 | 挂起 | 当前只入队；"入库即标签即体检"闭环待接线 |
| 纯扫描页方向自动检测 | 未实现 | 需 OCR OSD（tesseract/PaddleOCR）；库内文档抽检全部正立 |
| R15/R70 公式可检索 | 未实现 | 公式以 MinerU `<eq>` 保存；先做"公式编号→条款"索引 |
| R45 截图/图纸识别 | 已落地本地版 | src/core/vision/local_vision.py（MinerU OCR → 混合检索） |
| R46 快照回滚 / R51 滚动备份 | ✅ 已实现（13.5） | backup.py + 校验和验证 + 滚动保留 7 |
| R38 使用统计看板 | 未实现 | 用户未明确要，排期靠后 |
| R50 首次启动向导 | 已替代 | 信任验证流程（12.5） |
| 剩余测试盲区 | 部分 | R61/R72/R73/R76/R-L3 等（coverage-matrix 🔴 剩余项） |
| bge-m3 升维（10.5） | 不触发 | recall@5 97.8% >> 85% 验收线，数据不支持 |
| LLM advisory judge（10.7） | 判定砍 | 指标已达标，省额度 |
| install_service.py（开机自启） | 未做（记录） | 14.2 可选低成本增强 |
| 知识库多用户/权限 | 未实现 | Non-goal（v5 §6） |

---

# 18. 文档索引与接手指南

## 18.1 文档体系

| 文档 | 定位 |
|---|---|
| **本文件（ENCYCLOPEDIA.md）** | **单入口百科全书**（你正在读的）——现行唯一文档 |
| 仓库根 `README.md` | 快速开始（指向本文件） |
| 仓库根 `1-v4.3 (1).md` | 主计划 v4.3——需求/目标 SSOT（R1~R79 + R-L1~L14 + T00~T13） |
| `docs/_deprecated/` | **旧文档归档（已废弃，仅溯源）**：框架 v5、路线图、契约、维护手册、需求审计、覆盖矩阵、用户手册、阶段索引、phase1~14 交接、测试套件等 30 份原件 |

> ⚠ 原 `docs/onboarding/`、`docs/FRAMEWORK-v5-*.md`、`docs/ROADMAP-v5-*.md` 等路径已于 2026-08-23
> 归档到 `docs/_deprecated/`（融合进本文件）。所有历史细节在 `docs/_deprecated/` 可查，但以本文件为准。

## 18.2 接手阅读顺序（建议）

1. **本文件（百科全书）**——先建立全局认知。
2. `README.md`——快速开始。
3. 需要历史细节时 → `docs/_deprecated/onboarding/`（仅溯源，以本文件为准）。
4. 改任何 schema/API/SSE 前 → 本文件 §4/§11（原 contract.md 已归档于 _deprecated）。

## 18.3 增删记录（本文件融合过程的台账，同步记入 PHASE-INDEX）

- 2026-08-23：创建 `docs/ENCYCLOPEDIA.md`——融合 30 份现有文档为单入口百科全书；过期信息删除（含：旧测试基线 118+1 等历史快照数字、已废止的"零外发"表述、已撤回的 Tauri 评估、已删除代码的引用（UniverEditor）、旧 bbox"顶部原点"契约描述（以 §8.3 底部原点为准）、PHASE-INDEX 重复行、phase1 的 24 测试/127 条款等阶段快照），有效信息不压缩保留。
- 2026-08-23：归档旧文档——全部 30 份原件（docs/onboarding/ + FRAMEWORK-v5 + ROADMAP-v5 + docs/README）移入 `docs/_deprecated/` 并标记废弃（仅溯源）；根 README.md 重写为新版（指向 ENCYCLOPEDIA 为唯一现行文档）；ENCYCLOPEDIA §18.1 文档索引同步更新。
- 2026-08-23：修复证据卡表格编辑保存不上（saveEdit 只打 content_text 补丁，表格改不生效——卡片/检索读 content_markdown→table_md；改为 getParts 拆分正文+表格，分别落 content_text 与 content_markdown 两处补丁，回归测试 test_content_markdown_patch_drives_table_md）；前端接线 Office/WPS 往返编辑入口（证据卡"📝 在 Word/WPS 中编辑"按钮 + 1.5s 轮询 + diff 预览确认 + 越界拒绝提示）；修复编辑后回聊天记录默认滚到底部（chatRef + editingEv/officeSession 置空时 scrollTop=scrollHeight）。测试基线 165→166 passed + 2 skipped。
- 2026-08-23（用户实测三轮反馈）：① Office 往返"点了没反应"根因 = `create_edit_session` 只生成 docx 未调 `os.startfile` 拉起本机 Office/WPS——已补 `_launch_office()`（模块级函数便于测试 mock），回归断言启动一次；② "在 Word/WPS 中编辑"按钮从证据卡移到纠错编辑栏顶部（简单编辑用 TipTap 快速修改，复杂编辑再升级 Office）；③ 证据卡片定位改为：默认出现在鼠标正上方，鼠标在窗口上半区则放鼠标下方（旧实现固定鼠标右下+边缘钳制，按钮可能落在屏幕外点不到）。测试基线保持 166 passed + 2 skipped。
- 2026-08-24：新增「更新」模块（13 阶段流水线交付，详见 `pipeline/`）——① 变更巡检：三通道（官方国标网/网络补漏/gov.cn 公告）+ 验证码半自动 + 断点续扫 + 分层调度（tier0 高频/tier1 日预算 500）+ 三色报告 Word 导出 + 公告 PDF 存档；② 找标：CCS 分类本体 + 追问 v2（≤3 问、深度 2~3 级）+ 待下载清单 + 结果卡片；③ 数据包导出/导入（VACUUM INTO + 简报计数）；④ 万级库（35000 PDF）三阶段导入设计（目录先行→内容异步→分层巡检）。契约：schema 新增表 29/30/31，API +15 端点，SSE 冻结不动（问答警示走 time_warnings）。修复三 ANOM：假绿终态→诚实 failed；gov 站点 TLS 指纹拦截→curl_cffi 默认传输；openstd 真机 HTML 解析。测试基线 166→312 passed + 3 skipped。
- 2026-08-24（主功能修复）：PDF 黄框高亮错位——地面真值实验证明存储 bbox 正确（底部原点契约成立），根因是黄框盲信 OCR 近似坐标；修复为 PdfViewer 高亮**文本层吸附**（取邻域真实文字并集，无文本层回退原框），永不亮错位置。
- 2026-08-24（更新模块完善三件套）：① laws_db 法规渠道真机版——flk.npc.gov.cn `/law-search/search/list`（POST 载荷公开文档化，sxx 状态码 3有效/2被修改/4未生效/1废止 映射），传输层扩展 POST 支持；② 领域订阅 `GET/PUT /api/v1/update/subscriptions`（app_config 存储、缺省全开、显式空=全关），已订阅领域标准并入 tier0 高频巡检，前端真实开关组；③ PdfViewer 黄框消失修复（boxes 合并语义，旧引用黄框保留）。基线 312→322。
- 2026-08-24（万级批量导入，35000 PDF 场景）：`src/core/ingestion/bulk.py` 三阶段（快扫建目录→异步解析→首检入列），API `/ingest/bulk` 三端点 + 前端「批量导入」卡片；日预算 2000、每 5 件自动快照、断点续跑、隔离区、file_hash 防重；冒烟验证预算暂停门禁（daily_budget=0 陷阱已修）。基线 322→331。
- 2026-08-24：官方法规来源管线（docs/LAW_SOURCE_PLAN.md 方案落地 P1-P4）——法规只从两个官方源获取（flk.npc.gov.cn 国家法律法规数据库 + gov.cn 国务院政策文件库），下载**带格式官方 Word → LibreOffice/WPS 转 PDF → 现有 run_full_ingest 管线**（预览/高亮/目录与国标完全同构），替代"law-text://inline 纯文本直灌"。新增 `src/core/knowledge/law_source/`（http.py 域白名单强制 + flk_client/govcn_client + convert 转换链 + ingest 编排 + update 更新检查）；doc_meta 幂等迁移加 source/source_id/source_url/downloaded_at/source_status 溯源列；API `/api/v1/laws/sources|search|ingest|check-updates`；运维面板「📗 法规抓取」UI（LawFetchPanel）；CLI `scripts/fetch_law.py` + `scripts/reingest_laws.py`。存量重建：消防法/安全生产法/危化品条例/建设工程条例/工贸有限空间（gov.cn 公报兜底 web 版）/民法典（节选 11 条→官方全文 1061 条解析入库）6 部从官方源重建；GB/T 3608-2008 纯文本 law-text 删除（库内已有 GB 3608-2025 新版标准 PDF）。LibreOffice 已装（winget，`C:\Program Files\LibreOffice\program\soffice.exe`）；pywin32 已装（WPS COM 回退）。
- 2026-08-24（法规管线实测修复）：① **LibreOffice 对部分 flk 官方 docx 确定性截断**（建设工程条例 71 条只渲染前 24 条/7 页，docx/XML 结构均正常）——convert.py 加 `pdf_completeness` 完整性检测（docx 文本量 vs PDF 提取量 <55% 判截断），截断产物弃用自动切 **WPS COM**（实测 22 页全条款）；PDF 缓存复用也过完整性校验；② **gov.cn 公报页 web 兜底 docx 只生成 2 段**（公报正文无空行，按"块"切分失效）——`_build_docx_from_html` 改**按行切分**（第X章/第X条 行独立成段）+ 面包屑/字号/打印导航行清洗；web 兜底转换 prefer="com"（LibreOffice 对无样式纯文本 docx 的 PDF 文本层乱序，MinerU 切不出条款）；③ govcn 搜索结果的稳定链接字段是 `url`（`piclinksurl` 常空）；④ 公报页 `<title>` 兜底取标题（去 "__…中国政府网" 后缀）；⑤ govcn 效力等级默认"部门规章"（详情页 source 常空勿依赖）；⑥ 装了 pywin32 后 test_docx_ingest 的 COM 路径不再自动走——测试显式 mock `docx_to_pdf_via_com=False` 锁定降级直解路径。测试基线 312→322 passed + 3 skipped（+10：test_law_source 13 + test_law_source_api 6，其中 3 项为既有同名计数差异）。
- 2026-08-24（巡检查号误伤法规修复）：用户反馈"巡检都说查无此号"——根因 = `_TIER0_SQL/_TIER1_SQL` 无条件圈全部 doc_meta（含法规），法规无国标号被丢进国标网三通道（official_gb/web/govcn）查询 → 全 miss 判灰。修复：巡检清单 `WHERE doc_type='standard'`（tier0 领域订阅补入同样过滤法规），法规时效检查走 `law_source/update.py::check_law_updates`（按 flk bbbs 查 sxx + 新版本，P4 已实现）。新增回归测试 `test_inspect_lists_exclude_laws`。基线 322→323 passed + 3 skipped。
- 2026-08-24（巡检渠道升级 + mee 逆向 + DSH UI·四队实测并行）：① **官方渠道全天实网评测**（docs/LAW_SOURCE_PLAN.md 附 B）——确认 openstd 仅国标；"全门类"是 std.samr.gov.cn（门户导到 openstd/hbba/dbba/ttbz/qybz）；**AQ 3028-2008 已于 2024-07-01 废止**（应急部 2024 第3号公告，ndls 详情验证）；② **8 个渠道适配器接入 inspector**（`channels/{std_samr_hb,hbba,dbba,ndls,ttbz,mee,mem_gov,mohurd}.py` + `routing.py`）：ndls（跨门类状态权威，`/api/standard/list` 按号搜id + `/api/standard/detail/<id>` 给 废止日期/代替链，状态词表白名单，Jiasule WAF UA+限速放行）、std_samr_hb（`/hb/search/hbPage?searchText=` 必须传 **归一号**否则全库 match-all，STATE 现行/废止）、hbba/dbba（`POST /stdQueryList` 同构基类 _SacinfoQueryAdapter，fzDate 废止日期/有更新版→superseded，epoch 毫秒 CST）、ttbz（`POST /cms-proxy/ms/portal/standardInfo/getPortalStandardList` 探明 cms-proxy 反代，JSON-LD TechArticle 状态/日期）、**mee 逆向**（HJ 报告页 `#GridView1` colid=7 隐藏列**内嵌完整 PDF URL**，无 token/接口，HJ 819-2017 全文 351KB 下载成功；无状态列→legal_status=None 交聚合层）、mem_gov/mohurd（CMS/JS 结构，作公告+全文辅助，不占状态首选）；③ **inspector 动态路由** `routing.select_chain`（AQ/GB→ndls 状态权威、T/→ttbz、HJ→mee、DB→dbba、行标→hbba，其余兜底 official_gb→web→govcn），`_build_adapters` 全渠道注册（容错 _safe_import）；④ **DSH web UI 子代理侧边栏「收紧空闲/仅显示运行中」按钮**（ui-subagent SubagentHeaderLineage CatalogDropdown 加过滤 toggle：showRunningOnly 只渲染 activity==='running' 行，locales 中英 + module.css，build:web 成功）；⑤ 新测试 test_update_channels + test_update_routing（9 用例）。
- 2026-08-25（高亮错位根因终修·存量数据迁移）：用户实测高亮"完全位置错误"——浏览器+DOM 几何+fitz 真值对比定位：**GB 30871-2022 等翻转时代入库的文档，存量 span 是顶部原点坐标**（v5 修复只改了代码未迁移数据），前端按底部原点渲染 → 整体镜像偏移 300+pt。修复：`scripts/repair_span_origin.py`（逐文档采样投票判定坐标系 → 顶部原点文档全部翻转 y'=H-y + event_log 审计；幂等可重跑）。实库结果：11 文档翻转（含 GB 30871/民法典/消防法 等）、2 文档本就正确、5 文档无法定位保持原样；翻转后 dry-run 0 需翻转，浏览器实测黄框精确落在 5.1.1 条款文字上（fitz 带内文字验证）。**教训：契约修复必须同步迁移存量数据。**
- 2026-08-25（文件目录三级体系 + 交互增强）：① 法律法规目录按《法律法规分类编码体系》（用户上传 docx）重构为三级——效力层级(12 类：宪法及宪法相关法/法律（狭义）/行政法规/监察法规/军事法规/地方性法规/部门规章/地方政府规章/规范性文件/司法解释/国际条约与协定/特别行政区法律)→法律部门(7 个 A 宪法与行政法~G 环境保护与资源法，标题+领域标签关键词映射)→业务/行业领域→文档；法规文档叶节点只显示一个名称（其标准号字段即法规名，消除重复两行）。② 右栏内部分栏可拖动：文件目录/PDF目录/PDF预览之间新增 .v-divider（fileW/tocW 状态 150~460px）。③ 目录紧凑化：行高 29→22px、缩进 34→18px、删除空占位 span、叶节点改块状流式布局（标准号+名称 inline 自然折行，杜绝 flex+break-all 单字竖列）；国标叶节点显示 标准号+名称；右侧标题「目录」→「标题目录」，排版与文件目录统一（11.5px/行高 1.4）。基线 331→343（含并行会话增量）。



