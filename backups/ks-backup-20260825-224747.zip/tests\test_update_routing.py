"""渠道路由测试（2026-08 巡检渠道升级）：select_chain 按标准号特征正确路由。

官方实测结论：AQ→mem_gov、GB 50/55→mohurd、T/→ttbz、HJ→mee、DB→dbba、
其他国标→ndls、行标→hbba；无特征→泛查兜底 official_gb→web→govcn。
"""
from src.core.update.channels.routing import select_chain

TRAIL = ("official_gb", "web", "govcn")


def test_route_aq_to_ndls():
    # 状态权威优先 ndls（跨门类，AQ 3028 作废已验证；mem_gov 作公告/全文辅助不占首选）
    chain = select_chain("AQ 3028-2008")
    assert chain[0] == "ndls"
    assert set(chain[1:]) == set(TRAIL)
    assert select_chain("AQ/T 3016-2008")[0] == "ndls"


def test_route_engineering_to_ndls():
    for no in ("GB 55037-2022", "GB 50140-2005", "GB 50444-2008"):
        assert select_chain(no)[0] == "ndls", no


def test_route_group_to_ttbz():
    assert select_chain("T/ZSA 328-2026")[0] == "ttbz"


def test_route_hj_to_mee():
    assert select_chain("HJ 819-2017")[0] == "mee"


def test_route_local_to_dbba():
    assert select_chain("DB11/T 3031-2022")[0] == "dbba"


def test_route_other_gb_to_ndls():
    assert select_chain("GB 18218-2018")[0] == "ndls"
    # 推荐性国标带斜杠走官方兜底（official_gb）
    assert select_chain("GB/T 50493-2019")[0] == "official_gb"


def test_route_industry_to_hbba():
    for no in ("MT/T 1000-2019", "YB/T 4000-2019", "JB/T 5000-2020"):
        assert select_chain(no)[0] == "hbba", no


def test_route_no_feature_falls_back():
    chain = select_chain("XYZ 9999-2099")
    assert chain == TRAIL


def test_route_foreign_prefix_no_match():
    # 无任何已知前导 → 泛查
    assert select_chain("ISO 9001:2015") == TRAIL
