"""MinerU (magic-pdf) 版面解析适配器 + PyMuPDF 几何提取（T03'）。

分层降级策略：
1. 几何提取 (rotation/crop_box/media_box) — 纯 PyMuPDF，始终可用；
2. 文本块提取 — PyMuPDF 文本层（识别版 PDF 秒级完成）；
3. MinerU 深度版面分析 — 需 magic-pdf[full] + 模型 + ~/magic-pdf.json 配置；
   不可用或超时则记录日志继续，不阻塞冒烟入库（完整管线在 T05）。
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List

from src.core.exceptions import ParserError

logger = logging.getLogger(__name__)


def extract_page_geometries(pdf_path: Path) -> Dict[int, Dict[str, Any]]:
    """提取每页 PDF 的 Point 宽高、旋转角、CropBox、MediaBox（PyMuPDF）。"""
    import fitz  # PyMuPDF

    doc = fitz.open(str(pdf_path))
    geometries: Dict[int, Dict[str, Any]] = {}
    try:
        for page_idx in range(len(doc)):
            page = doc[page_idx]
            rect = page.rect
            cropbox = page.cropbox
            mediabox = page.mediabox
            geometries[page_idx + 1] = {
                "width": float(rect.width),
                "height": float(rect.height),
                "rotation": int(page.rotation),
                "crop_box": [float(cropbox.x0), float(cropbox.y0),
                             float(cropbox.x1), float(cropbox.y1)],
                "media_box": [float(mediabox.x0), float(mediabox.y0),
                              float(mediabox.x1), float(mediabox.y1)],
            }
    finally:
        doc.close()
    return geometries


def _extract_text_blocks(pdf_path: Path) -> List[Dict[str, Any]]:
    """PyMuPDF 文本块（含 bbox，已转 PDF 左下原点坐标系）。"""
    import fitz

    blocks: List[Dict[str, Any]] = []
    with fitz.open(str(pdf_path)) as doc:
        for pno in range(len(doc)):
            page = doc[pno]
            page_h = page.rect.height
            for b in page.get_text("dict")["blocks"]:
                if b.get("type") != 0:  # 0 = 文本块
                    continue
                lines_text = []
                for line in b.get("lines", []):
                    span_text = "".join(sp.get("text", "") for sp in line.get("spans", []))
                    lines_text.append(span_text)
                x0, y0, x1, y1 = b["bbox"]
                text = "\n".join(t for t in lines_text if t.strip())
                if not text:
                    continue
                blocks.append({
                    "page_number": pno + 1,
                    "text": text,
                    "bbox": [float(x0), float(page_h - y1), float(x1), float(page_h - y0)],
                    "source": "pymupdf",
                })
    return blocks


def mineru_available() -> bool:
    try:
        import mineru  # noqa: F401 — MinerU 2.x (magic-pdf 继任包)
        return True
    except ImportError:
        try:
            import magic_pdf  # noqa: F401 — 旧名兼容
            return True
        except ImportError:
            return False


def _mineru_deep_analyze(pdf_path: Path, output_dir: Path) -> Dict[str, Any] | None:
    """MinerU 2.x (magic-pdf 继任包) 深度版面分析。返回分析结果；失败/禁用返回 None 降级。

    环境开关 KS_MINERU_DEEP=0 可跳过（冒烟/测试用）。
    """
    import os
    if os.environ.get("KS_MINERU_DEEP", "1") == "0":
        return None
    if not mineru_available():
        logger.info("mineru/magic-pdf 未安装，跳过深度版面分析")
        return None
    try:
        from mineru.cli.common import do_parse

        out_dir = output_dir / "mineru"
        out_dir.mkdir(parents=True, exist_ok=True)
        do_parse(str(out_dir), [pdf_path.stem], [pdf_path.read_bytes()], ["ch"],
                 backend="pipeline", parse_method="auto",
                 f_draw_layout_bbox=False, f_draw_span_bbox=False,
                 f_dump_orig_pdf=False, f_dump_model_output=False)
        return {"output_dir": str(out_dir)}
    except Exception as e:  # noqa: BLE001 - 深度分析失败不阻塞冒烟管线
        logger.warning("MinerU 深度分析降级: %s", e)
        return None


def parse_pdf_with_mineru(pdf_path: Path, output_dir: Path,
                          force_deep: bool = False) -> Dict[str, Any]:
    """标准化解析入口（Parser Worker 子进程中执行）。

    force_deep=True 时强制 MinerU 深度版面分析（T05 完整管线用），
    返回值含 deep_output（middle.json/content_list 所在目录）。
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    geometries = extract_page_geometries(pdf_path)
    blocks = _extract_text_blocks(pdf_path)

    is_ocr = False
    deep_output: str | None = None
    if not blocks or force_deep:
        deep = _mineru_deep_analyze(pdf_path, output_dir)
        if deep is None:
            if not blocks:
                raise ParserError(
                    f"PDF 无文本层且 MinerU OCR 不可用: {pdf_path.name}")
        else:
            deep_output = deep["output_dir"]

    (output_dir / "blocks.json").write_text(
        json.dumps(blocks, ensure_ascii=False), encoding="utf-8")
    return {"blocks": blocks, "geometries": geometries, "is_ocr": is_ocr,
            "deep_output": deep_output}
