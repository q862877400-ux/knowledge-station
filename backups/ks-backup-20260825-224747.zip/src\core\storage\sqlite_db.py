"""SQLite 连接管理与初始化（WAL + 外键 + busy_timeout + sqlite-vec 扩展）。"""
from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from src.core.config import get_settings
from src.core.exceptions import StorageError

_SCHEMA_PATH = Path(__file__).parent / "schema.sql"

_local = threading.local()


def load_vec_extension(conn: sqlite3.Connection) -> bool:
    """加载 sqlite-vec 扩展；失败时返回 False（检索自动降级，见 R30）。"""
    try:
        import sqlite_vec  # type: ignore[import-untyped]
        conn.enable_load_extension(True)
        sqlite_vec.load(conn)
        conn.enable_load_extension(False)
        return True
    except Exception:
        return False


def _configure(conn: sqlite3.Connection) -> None:
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=5000")


def get_db_connection(db_path: Path | None = None) -> sqlite3.Connection:
    """线程局部连接。默认使用配置中心的库路径。"""
    path = db_path or get_settings().db_path
    key = "conn_default" if db_path is None else f"conn_{path}"
    conn = getattr(_local, key, None)
    if conn is None:
        path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(path), check_same_thread=False)
        _configure(conn)
        setattr(_local, key, conn)
    return conn


@contextmanager
def write_transaction(db_path: Path | None = None) -> Iterator[sqlite3.Connection]:
    """短事务上下文：由单写者队列调用，普通代码不应直接绕过队列写库。"""
    conn = get_db_connection(db_path)
    if conn.in_transaction:  # 清理遗留的隐式事务，保证 BEGIN IMMEDIATE 可执行
        conn.commit()
    try:
        conn.execute("BEGIN IMMEDIATE")
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def init_schema(db_path: Path | None = None) -> None:
    conn = get_db_connection(db_path)
    load_vec_extension(conn)
    try:
        conn.executescript(_SCHEMA_PATH.read_text(encoding="utf-8"))
        conn.commit()
    except sqlite3.Error as e:
        raise StorageError(f"初始化 schema 失败: {e}") from e


def list_tables(db_path: Path | None = None) -> list[str]:
    conn = get_db_connection(db_path)
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ).fetchall()
    return [r[0] for r in rows]


def close_thread_connection() -> None:
    for key in list(vars(_local)):
        conn = getattr(_local, key, None)
        if isinstance(conn, sqlite3.Connection):
            conn.close()
            delattr(_local, key)
