"""span 坐标系通用自动校准（R-B，pipeline/13-round3.md）。

通解：对每页用 fitz words 按 y 聚类构建**文字行中心表**（顶部原点），对每个 span 的 bbox
中心取两种解释——「直读（顶部原点）」与「H−y 换算（底部原点）」——各找与最近文字行的距离，
**近者胜**（最近行匹配，解决 50140 碎片投票分裂的根因：旧法拿碎片中心比条款块首行，
碎片越靠后偏差越大）。文档级投票多数决，判为顶部原点则全量翻转 y'=H−y 归一为底部原点。

两个入口：
- ``calibrate``：存量校准（读库全部 span → 投票 → UPDATE by rowid + event_log 审计）；
  scripts/repair_span_origin.py 复用本函数。
- ``calibrate_new``：纯函数版（内存 span 列表投票归一为底部原点，不落库）；
  pipeline.run_full_ingest 写库前调用。已底部原点的文档投票全 bottom、零改动（幂等）。

坐标契约：归一目标 = **PDF 底部原点**（左下原点，y 向上），前端 pdfjs convertToViewport*
直接消费，见 PdfViewer.tsx bbox 契约注释。
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any
from ulid import ULID

import fitz


def page_line_centers(page: fitz.Page) -> list[float]:
    """fitz words 按 y 聚类成行，返回每行中心 y（顶部原点，升序）。

    聚类容差 = max(2pt, 中位词高一半)：正文行距 ~1.2 倍字高不会误并，标题/表格小间隙不误拆。
    """
    words = page.get_text("words") or []
    if not words:
        return []
    heights = sorted(w[3] - w[1] for w in words)
    tol = max(2.0, 0.5 * heights[len(heights) // 2])
    centers = sorted((w[1] + w[3]) / 2.0 for w in words)
    lines: list[float] = []
    group: list[float] = [centers[0]]
    for cy in centers[1:]:
        if cy - group[-1] <= tol:
            group.append(cy)
        else:
            lines.append(sum(group) / len(group))
            group = [cy]
    lines.append(sum(group) / len(group))
    return lines


def _vote_from_centers(lines: list[float], page_h: float, bbox: Any) -> str | None:
    """给定行中心表的投票内核：bbox 中心直读 vs H−y 换算，距最近文字行近者胜。

    平票判 bottom（保守：翻转只在证据明确时发生）。无文字行返回 None。
    """
    if not lines:
        return None
    cy = (float(bbox[1]) + float(bbox[3])) / 2.0
    d_top = min(abs(cy - c) for c in lines)          # 直读解释（顶部原点）
    d_bot = min(abs((page_h - cy) - c) for c in lines)  # 换算解释（底部原点）
    return "bottom" if d_bot <= d_top else "top"


def vote_origin(page: fitz.Page, bbox: Any) -> str | None:
    """bbox 中心两种解释（直读 / H−y）各找最近文字行距离，近者胜；无行返回 None。"""
    return _vote_from_centers(page_line_centers(page), page.rect.height, bbox)


def band_text_hit(page: fitz.Page, bbox_raw: Any, content_text: str) -> bool:
    """带内文字真值最终裁决 v3（2026-08-25）：

    raw bbox 按「顶部原点」解释取带，带内文字取首/中 8 字窗口，命中条款正文即算命中
    （mid-block 片段的带内是条款中段文字，不含开头——v2 严格版在此大量误判"无法定位"）。
    带内无文字或窗口不命中 → False（错误解释的带会落在无关内容上，不会命中）。
    """
    frag = (content_text or "").replace(" ", "").replace("\n", "")
    if len(frag) < 8:
        return False
    r = fitz.Rect(*[float(v) for v in bbox_raw])
    txt = page.get_text("text", clip=r).replace(" ", "").replace("\n", "")
    if len(txt) < 6:
        return False
    windows = {txt[:8], txt[max(0, len(txt) // 2 - 4):][:8]}
    return any(len(w) >= 6 and w in frag for w in windows)


def _flip_bbox(bbox: Any, page_h: float) -> list[float]:
    """顶部原点 → 底部原点：y'=H−y（端点交换）。保留 x 与 2 位小数。"""
    b = [float(v) for v in bbox]
    return [b[0], round(page_h - b[3], 2), b[2], round(page_h - b[1], 2)]


def _span_get(span: Any, key: str, default: Any = None) -> Any:
    if isinstance(span, dict):
        return span.get(key, default)
    return getattr(span, key, default)


def _span_set(span: Any, key: str, value: Any) -> None:
    if isinstance(span, dict):
        span[key] = value
    else:
        setattr(span, key, value)


def _vote_spans(doc: "fitz.Document", spans: list[Any]) -> tuple[dict[int, list[float]], dict[int, float], int, int]:
    """全量 span 逐条投票（页级缓存行中心表/页高），返回 (行中心表, 页高, top 票, bottom 票)。"""
    centers_cache: dict[int, list[float]] = {}
    heights: dict[int, float] = {}
    votes_top = votes_bottom = 0
    for s in spans:
        pno = int(_span_get(s, "page_number", 0))
        if pno < 1 or pno > doc.page_count:
            continue
        if pno not in centers_cache:
            page = doc[pno - 1]
            centers_cache[pno] = page_line_centers(page)
            heights[pno] = page.rect.height
        v = _vote_from_centers(centers_cache[pno], heights[pno], _span_get(s, "bbox"))
        if v == "top":
            votes_top += 1
        elif v == "bottom":
            votes_bottom += 1
    return centers_cache, heights, votes_top, votes_bottom


def calibrate_new(pdf_path: str | Path, spans: list[Any]) -> list[Any]:
    """纯函数版校准（不落库）：入库前对内存中 span 列表文档级投票并归一为底部原点。

    支持 dict 或带 page_number/bbox 属性的对象（如 SourceSpanModel）；原地修改 bbox 并返回
    入参列表。幂等：已是底部原点则投票全 bottom、零改动。PDF 打不开时向上抛错由调用方降级。
    """
    items = list(spans or [])
    if not items:
        return items
    doc = fitz.open(str(pdf_path))
    try:
        _, heights, votes_top, votes_bottom = _vote_spans(doc, items)
        if votes_top > votes_bottom:  # 文档级多数决：顶部原点 → 全量翻转归一
            for s in items:
                pno = int(_span_get(s, "page_number", 0))
                if pno in heights:
                    _span_set(s, "bbox", _flip_bbox(_span_get(s, "bbox"), heights[pno]))
        return items
    finally:
        doc.close()


def calibrate(doc_id: str, pdf_path: str | Path, db_conn: sqlite3.Connection | None = None,
              *, apply: bool = True) -> dict:
    """存量校准：读该 doc 全部 span → 逐条 vote 文档级多数决 → 顶部原点则全量翻转。

    翻转按 source_span.rowid 精确 UPDATE，并写 event_log 审计（repair/span_origin_flipped）。
    apply=False 为 dry-run：只投票报告、零写库。db_conn 缺省连应用主库。

    返回 {"flipped": bool, "votes": {"top": int, "bottom": int}}。
    """
    if db_conn is None:
        from src.core.config import get_settings
        db_conn = sqlite3.connect(str(get_settings().db_path))
    rows = db_conn.execute(
        "SELECT s.rowid, s.page_number, s.bbox_json, cr.content_text"
        " FROM source_span s JOIN clause_revision cr"
        " ON cr.clause_revision_id = s.clause_revision_id"
        " WHERE cr.doc_id=? ORDER BY s.page_number, s.sort_order, s.rowid",
        (doc_id,)).fetchall()
    votes = {"top": 0, "bottom": 0}
    if not rows:
        return {"flipped": False, "votes": votes}
    doc = fitz.open(str(pdf_path))
    try:
        spans = [{"rowid": r[0], "page_number": r[1], "bbox": json.loads(r[2]),
                  "head": r[3] or ""} for r in rows]
        # 最终裁决 = 带内文字真值（2026-08-25 通解，取代不可靠的最近行投票——
        # 密集页上镜像中心常巧合靠近别的行，投票 149:135 这类分裂即其产物）：
        # 取前 2 个样本 span——
        #   raw bbox（顶部原点解释）带内命中条款原文 → 该文档是顶部原点 → 全量翻转；
        #   否则 H−y 带（底部原点解释）命中 → 已是底部原点 → 保持；
        #   两者都不中 → 无法判定，保持并标记待人工（宁可不翻）。
        sampled = [s for s in spans if 1 <= int(s["page_number"]) <= doc.page_count][:2]
        top_hits = bottom_hits = 0
        for s in sampled:
            page = doc[int(s["page_number"]) - 1]
            H = page.rect.height
            bbox = s["bbox"]
            if band_text_hit(page, bbox, s["head"]):
                top_hits += 1
            bb = [float(bbox[0]), H - float(bbox[3]), float(bbox[2]), H - float(bbox[1])]
            if band_text_hit(page, bb, s["head"]):
                bottom_hits += 1
        n = len(sampled)
        flipped = False
        verdict = "unknown"
        if n and top_hits == n:
            verdict = "top_flip"
        elif n and bottom_hits == n:
            verdict = "bottom_keep"
        if verdict == "top_flip" and apply:
            for s in spans:
                pno = int(s["page_number"])
                H = (doc[pno - 1].rect.height if 1 <= pno <= doc.page_count else 841.9)
                db_conn.execute(
                    "UPDATE source_span SET bbox_json=? WHERE rowid=?",
                    (json.dumps(_flip_bbox(s["bbox"], H)), s["rowid"]))
            db_conn.execute(
                "INSERT INTO event_log (event_id, event_type, actor, target_type,"
                " target_id, after_state) VALUES (?,?,?,?,?,?)",
                (str(ULID()), "repair/span_origin_flipped", "system", "doc_meta",
                 doc_id,
                 json.dumps({"verdict": verdict, "samples": n,
                             "spans": len(spans),
                             "script": "src/core/ingestion/span_calibration.py"},
                            ensure_ascii=False)))
            db_conn.commit()
            flipped = True
        return {"flipped": flipped, "verdict": verdict,
                "samples": {"top_hits": top_hits, "bottom_hits": bottom_hits, "n": n}}
    finally:
        doc.close()
