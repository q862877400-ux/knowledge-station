"""入口：python -m src.core.main"""
from src.core.api.server import run

if __name__ == "__main__":
    run()
