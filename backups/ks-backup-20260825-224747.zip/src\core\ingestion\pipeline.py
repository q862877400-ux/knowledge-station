"""T05 完整入库管线：MinerU 深度解析 → middle.json 结构化 → E1-E7 切分
→ 三型分型 → 证据图抽取 → 单事务原子入库（R1）。

用法:
    python -m src.core.ingestion.pipeline <pdf> --standard-no "GB 30871-2022" \
        --name "..." [--doc-type standard|法律法规] [--domain-tags 安全,消防]

坐标契约: middle.json bbox 为 PDF 点、左上原点（y 向下）；source_span 直接存左上原点坐标，
前端 PdfViewer 按「顶部原点→视口」映射高亮（勿用 convertToViewportRectangle 的底部原点翻转）。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ulid import ULID

from src.core.config import get_settings
from src.core.domain.models import ClauseRevisionModel, SourceSpanModel
from src.core.ingestion.parser_worker import run_parser_isolated
from src.core.knowledge.classifier import (
    build_hierarchy_path, classify_clause, normalize_clause_number, strip_revision_marks,
)
from src.core.storage import clause_repo
from src.core.storage.sqlite_db import get_db_connection, init_schema, write_transaction

logger = logging.getLogger(__name__)

# 条款号开头（E3）：GB 风格 5.2.1 / 法律风格 第四百九十六条
_CLAUSE_GB = re.compile(r"^(\d+(?:\.\d+){1,4})\s*(.*)$", re.S)
_CLAUSE_LAW = re.compile(r"^(第[一二三四五六七八九十百千]+条)\s*(.*)$", re.S)
_TABLE_CAPTION = re.compile(r"^表\s*([A-Za-z]?\d+(?:\.\d+)*)\s*(.*)$")
_APPENDIX_HEAD = re.compile(r"^(附\s*录\s*[A-Z]?|附\s*则)")
_CHAPTER_HEAD = re.compile(r"^(\d+)\s+[\u4e00-\u9fff]")
_TOC_HEAD = re.compile(r"^目\s*次")


@dataclass
class MidItem:
    """middle.json 归一化条目（阅读顺序）。"""
    kind: str                 # text | table | title
    text: str = ""
    html: str | None = None   # table_body html
    caption: str | None = None
    page_idx: int = 0         # 0-based
    bbox: list[float] = field(default_factory=list)  # PDF 点，左上原点


def _spans_text(node: dict) -> str:
    """提取文本块内容。**必须包含 inline_equation span**（行内公式）：
    MinerU 把 "按表4.2规定的A类法分级" 里的数字/字母抽成 LaTeX 公式 span，
    若丢弃 → 正文变成 "按表 规定的 类法分级"（缺内容），卡片/PDF高亮/WPS 三块错位。
    公式 LaTeX 转可读 Unicode 文本后原位拼回。"""
    from src.core.text_utils import latex_to_text
    out = []
    for line in node.get("lines") or []:
        for span in line.get("spans") or []:
            st = span.get("type")
            content = span.get("content") or ""
            if not content:
                continue
            if st == "text":
                out.append(content)
            elif st == "inline_equation":
                out.append(latex_to_text(content))
    return "\n".join(x for x in out if x.strip())


def load_middle_items(middle_path: Path) -> tuple[list[MidItem], dict[int, tuple[float, float]]]:
    """解析 middle.json → 阅读顺序条目 + 每页尺寸。

    discarded_blocks（页眉/页脚/页码）直接跳过 —— R65 边角过滤 + E4 跨页杂音消除。
    """
    mj = json.loads(middle_path.read_text(encoding="utf-8"))
    items: list[MidItem] = []
    page_sizes: dict[int, tuple[float, float]] = {}
    for page in mj.get("pdf_info", []):
        pidx = page.get("page_idx", len(page_sizes))
        w, h = page.get("page_size", [595.0, 841.0])
        page_sizes[pidx] = (float(w), float(h))
        for block in page.get("para_blocks") or []:
            btype = block.get("type")
            if btype == "table":
                caption, html = None, None
                for sub in block.get("blocks") or []:
                    st = sub.get("type")
                    if st == "table_caption":
                        caption = _spans_text(sub)
                    elif st == "table_body":
                        for line in sub.get("lines") or []:
                            for span in line.get("spans") or []:
                                if span.get("type") == "table" and span.get("html"):
                                    html = span["html"]
                # 表格 html 里的 <eq> LaTeX 同样入库即转可读（卡片/WPS/编辑器全一致）
                if html:
                    from src.core.text_utils import clean_eq_tags
                    html = clean_eq_tags(html)
                items.append(MidItem(kind="table", text=caption or "", html=html,
                                     caption=caption, page_idx=pidx,
                                     bbox=list(block.get("bbox", []))))
            else:
                text = _spans_text(block)
                if text:
                    items.append(MidItem(kind="title" if btype == "title" else "text",
                                         text=text, page_idx=pidx,
                                         bbox=list(block.get("bbox", []))))
    return items, page_sizes


# 废弃说明（v5 实测修复 2026-08-23）：MinerU middle.json 的 bbox 为 PDF 底部原点（左下 y 向上），
# pipeline 原样直存 source_span，前端 convertToViewportPoint 直接消费。
# 曾误判为"左上原点"并加 _flip_bbox 翻转 → 前端再 H−y 翻转 → 双重翻转黄标镜像。
# 此函数已删除；改坐标契约必须先读 MAINTAINER-GUIDE §4.2 更新版。


@dataclass
class SplitClause:
    number: str
    texts: list[str]
    items: list[MidItem]
    content_type: str = "normal"      # normal | 前置说明 | 附录
    table_html: str | None = None
    table_summary: str | None = None
    bind_table_number: str | None = None


def split_items_into_clauses(items: list[MidItem]) -> list[SplitClause]:
    """E1-E7 切分主逻辑。

    E1 结构恢复: 依赖 MinerU 阅读顺序块（已做多栏正确排序）
    E2 附录隔离: 附录头之后 → content_type=附录
    E3 变长层级: 编号归一 + hierarchy_path（classify 阶段）
    E4 跨页拼接: 非条款开头的条目并入当前条款（页眉页脚已被 MinerU 丢弃）
    E5 表格绑定: 表 x 关联母条款，html 入 content_markdown
    E6 编号归一 / E7 修订剥离: normalize_clause_number / strip_revision_marks
    """
    clauses: list[SplitClause] = []
    in_toc = False
    in_appendix = False
    current: SplitClause | None = None
    chapter: str | None = None   # 最近章号（还原 MinerU 吞点的条款号 "41"→"4.1"）

    for it in items:
        text = strip_revision_marks(it.text or "").strip()
        if not text:
            continue
        # MinerU 常把条款号拆成 "4.\n1"（数字点换行数字）→ 合并为 4.1
        text = re.sub(r"(\d)\.\s*\n\s*(?=\d)", r"\1.", text)

        if _TOC_HEAD.match(text):
            in_toc = True
            continue
        if in_toc:
            # 目次结束判定：出现第一个正文章节头或条款号
            if _CHAPTER_HEAD.match(text) or _CLAUSE_GB.match(text):
                in_toc = False
            else:
                continue

        if _APPENDIX_HEAD.match(text):
            in_appendix = True
            current = SplitClause(number=normalize_clause_number(text[:24]),
                                  texts=[text], items=[it], content_type="附录")
            clauses.append(current)
            continue

        if it.kind == "table":
            cap = it.caption or ""
            m = _TABLE_CAPTION.match(cap.strip())
            bind_no = normalize_clause_number(m.group(1)) if m else None
            summary = (m.group(2).strip() if m and m.group(2) else cap)[:120]
            if bind_no:
                target = next((c for c in clauses if c.number == bind_no), None)
                if target is not None:
                    target.table_html = it.html
                    target.table_summary = summary or None
                    target.items.append(it)
                    continue
            if current is not None:
                current.table_html = current.table_html or it.html
                current.table_summary = current.table_summary or summary or None
                current.items.append(it)
                continue
            clauses.append(SplitClause(number=f"表{bind_no or ULID().hex[:4]}",
                                       texts=[cap], items=[it],
                                       table_html=it.html, table_summary=summary or None))
            continue

        # 还原 MinerU 吞点条款号：章号紧跟的 "41 xxx" → "4.1 xxx"
        if not _CLAUSE_GB.match(text) and chapter:
            m41 = re.match(r"^(\d)(\d{1,2})\s", text)
            if m41 and m41.group(1) == chapter:
                text = m41.group(1) + "." + m41.group(2) + text[len(m41.group(0)) - 1:]
        # 章号跟踪（"4 高处作业分级" 样式）
        mch = _CHAPTER_HEAD.match(text)
        if mch:
            chapter = mch.group(1)

        m_gb = _CLAUSE_GB.match(text)
        m_law = _CLAUSE_LAW.match(text)
        if m_gb and (in_appendix or len(m_gb.group(1)) >= 3 or m_gb.group(1).count(".") >= 1):
            number = normalize_clause_number(m_gb.group(1))
            current = SplitClause(number=number, texts=[text], items=[it],
                                  content_type="附录" if in_appendix else "normal")
            clauses.append(current)
        elif m_law:
            current = SplitClause(number=m_law.group(1), texts=[text], items=[it])
            clauses.append(current)
        else:
            # 块内可能含多个条款（章标题+条款同块）：按行拆分
            lines = text.split("\n")
            if len(lines) > 1:
                i = 0
                while i < len(lines):
                    ln = lines[i].strip()
                    if not ln:
                        i += 1
                        continue
                    mm = _CLAUSE_GB.match(ln)
                    num = mm.group(1) if mm else ""
                    is_head = bool(mm) and (len(num) >= 3 or num.count(".") >= 1)
                    if is_head:
                        cur = SplitClause(number=normalize_clause_number(num),
                                          texts=[ln], items=[it], content_type="normal")
                        clauses.append(cur)
                        i += 1
                        while i < len(lines):
                            nxt = lines[i].strip()
                            m2 = _CLAUSE_GB.match(nxt)
                            n2 = m2.group(1) if m2 else ""
                            if m2 and (len(n2) >= 3 or n2.count(".") >= 1):
                                break
                            cur.texts.append(nxt)
                            i += 1
                        continue
                    if current is not None:
                        current.texts.append(ln)
                        current.items.append(it)
                    i += 1
            elif current is not None:
                current.texts.append(text)
                current.items.append(it)
            else:
                # 正文前内容（封面/前言/引言）→ 前置说明（R65）
                current = SplitClause(number=f"前置{len(clauses) + 1}", texts=[text],
                                      items=[it], content_type="前置说明")
                clauses.append(current)
    return clauses


def build_clause_models(doc_id: str, standard_no: str, doc_type: str,
                        clauses: list[SplitClause],
                        page_sizes: dict[int, tuple[float, float]],
                        ) -> tuple[list[ClauseRevisionModel], list[dict[str, Any]]]:
    """切分结果 → Pydantic 模型 + 证据图边（raw，source/target 用条款号表示）。"""
    models: list[ClauseRevisionModel] = []
    raw_edges: list[dict[str, Any]] = []
    number_to_id: dict[str, str] = {}

    for cl in clauses:
        content = "\n".join(cl.texts)[:4000]
        if len(content.strip()) < 4:
            continue
        # 入库即清洗 OCR 折行（公共规则）：库里存规范文本，编辑器/WPS/卡片/导出全一致
        from src.core.text_utils import normalize_wraps
        content = normalize_wraps(content)
        tc = classify_clause(content, doc_type=doc_type)
        cid = f"clrev_{ULID()}"
        number_to_id[cl.number] = cid
        pages = [it.page_idx + 1 for it in cl.items]
        spans = [SourceSpanModel(
            span_id=f"span_{ULID()}",
            page_number=it.page_idx + 1,
            bbox=list(it.bbox),  # 左上原点（顶部原点），前端按此映射
            span_type="table" if it.kind == "table" else "text",
        ) for it in cl.items[:8]]
        models.append(ClauseRevisionModel(
            clause_revision_id=cid,
            doc_id=doc_id,
            clause_key=clause_repo.make_clause_key(doc_id, cl.number),
            standard_no=standard_no,
            clause_number=cl.number,
            content_text=content,
            content_markdown=cl.table_html,
            table_summary=cl.table_summary,
            hierarchy_path=build_hierarchy_path(cl.number) or None,
            knowledge_type=tc.knowledge_type,
            type_confidence=tc.type_confidence,
            modality=tc.modality,
            modality_strength=tc.modality_strength,
            modality_confidence=tc.modality_confidence,
            subject=tc.subject,
            exception=tc.exception,
            legal_refs=tc.external_refs,
            cross_refs=tc.cross_refs,
            is_mandatory=tc.is_mandatory,
            is_suspicious=tc.is_suspicious,
            page_start=min(pages), page_end=max(pages),
            source_spans=spans,
        ))

    # 证据图：reference_relation（内部引用）+ clause_relation（表绑定）
    for m in models:
        for ref in m.cross_refs:
            raw_edges.append({"edge_type": "reference_relation",
                              "src": m.clause_number, "dst": ref,
                              "conf": 0.9, "status": "active"})
        if m.table_summary:
            raw_edges.append({"edge_type": "clause_relation",
                              "src": m.clause_number, "dst": m.clause_number,
                              "conf": 1.0, "status": "active"})
    # exception_relation: 含但书条款 → 同号"注"条款（若存在）
    for m in models:
        if m.exception:
            note_no = f"{m.clause_number}注"
            if note_no in number_to_id:
                raw_edges.append({"edge_type": "exception_relation",
                                  "src": m.clause_number, "dst": note_no,
                                  "conf": 0.85, "status": "active"})
    return models, raw_edges


def resolve_edges(raw_edges: list[dict[str, Any]],
                  number_to_id: dict[str, str]) -> list[tuple[str, str, str, float, str]]:
    out = []
    for e in raw_edges:
        if e["edge_type"] == "clause_relation":
            continue  # 表绑定已落在同一条款内部，不建自环边
        src, dst = number_to_id.get(e["src"]), number_to_id.get(e["dst"])
        if src and dst and src != dst:
            out.append((e["edge_type"], src, dst, e["conf"], e["status"]))
    return out


def analyze_preview(pdf_path: Path) -> dict:
    """R27 入库预览 Dry-Run（Task 11.5）：解析但不落库，输出切分/分型/质量预览。

    走快速文本层路径（force_deep=False，不调 MinerU 深度模型），秒级返回；
    供入库前人工确认（拦截乱码/严重倾斜文档）。
    """
    from src.core.ingestion.parser_worker import run_parser_isolated
    from src.core.knowledge.classifier import classify_clause
    if not pdf_path.exists():
        return {"status": "error", "message": f"文件不存在: {pdf_path}"}
    result = run_parser_isolated(pdf_path, get_settings().data_dir / "preview_tmp",
                                 force_deep=False)
    items, _ = load_middle_items_from_blocks(result["blocks"])
    clauses = split_items_into_clauses(items)
    previews = []
    for cl in clauses:
        content = "\n".join(cl.texts)
        if len(content.strip()) < 4:
            continue
        tc = classify_clause(content)
        previews.append({"number": cl.number, "text_len": len(content),
                         "knowledge_type": tc.knowledge_type,
                         "modality": tc.modality, "suspicious": tc.is_suspicious})
    type_dist: dict[str, int] = {}
    for p in previews:
        type_dist[p["knowledge_type"]] = type_dist.get(p["knowledge_type"], 0) + 1
    n_susp = sum(1 for p in previews if p["suspicious"])
    return {"status": "ok", "total_clauses": len(previews),
            "knowledge_type_distribution": type_dist,
            "suspicious_count": n_susp,
            "sample": previews[:10],
            "pages": len(result["geometries"])}


def load_middle_items_from_blocks(blocks: list[dict]) -> tuple[list[MidItem], dict]:
    """blocks（PyMuPDF 文本块）→ MidItem（供 split_items_into_clauses）。

    文本块按行拆为独立条目（一条条款可能占块内多行，行首条款号需单独识别）。
    """
    items = []
    _span_norm = re.compile(r"\s*([.\d])\s*")
    for b in blocks:
        page_idx = int(b.get("page_number", 1)) - 1
        for line in (b.get("text", "") or "").splitlines():
            line = _span_norm.sub(r"\1", line.strip())  # fitz 逐字 span：'5 . 2 . 1'→'5.2.1'
            if line:
                items.append(MidItem(kind="text", text=line, page_idx=page_idx,
                                     bbox=list(b.get("bbox", []))))
    return items, {}


def run_full_ingest(pdf_path: Path, standard_no: str, standard_name: str,
                    short_code: str | None = None, doc_type: str = "standard",
                    domain_tags: list[str] | None = None,
                    legal_hierarchy: str = "GB",
                    reingest: bool = False) -> dict:
    settings = get_settings()
    if not pdf_path.exists():
        return {"status": "error", "message": f"文件不存在: {pdf_path}"}
    init_schema()
    file_hash = hashlib.sha256(pdf_path.read_bytes()).hexdigest()
    conn = get_db_connection()

    dup = conn.execute("SELECT doc_id FROM doc_meta WHERE file_hash=?", (file_hash,)).fetchone()
    if dup and not reingest:
        return {"status": "duplicate", "doc_id": dup[0]}
    same_no = conn.execute(
        "SELECT doc_id, file_hash FROM doc_meta WHERE standard_no=?", (standard_no,)).fetchone()
    if same_no and same_no["file_hash"] != file_hash and not reingest:
        return {"status": "standard_exists", "existing_doc_id": same_no["doc_id"],
                "message": f"标准号 {standard_no} 已存在（hash 不同），如需覆盖请先废弃旧文档"}
    # reingest 模式：解析成功后删除同 standard_no 的旧文档（用户资产按 clause_key 迁移）

    doc_id = f"doc_{ULID()}"
    result = run_parser_isolated(pdf_path, settings.data_dir / "parse_out" / doc_id,
                                 force_deep=True)
    deep_output = result.get("deep_output")
    if not deep_output:
        return {"status": "error", "message": "MinerU 深度解析不可用（检查模型/配置）"}

    middle_files = list(Path(deep_output).rglob("*_middle.json"))
    if not middle_files:
        return {"status": "error", "message": f"未找到 middle.json: {deep_output}"}
    items, page_sizes = load_middle_items(middle_files[0])
    clauses = split_items_into_clauses(items)
    models, raw_edges = build_clause_models(doc_id, standard_no, doc_type, clauses, page_sizes)

    # R-B span 坐标系自动校准（pipeline/13-round3.md）：MinerU middle 同源页高，
    # 写库前对全部 span 文档级投票并归一为底部原点（已正确则全 bottom 零改动，幂等）。
    # 仅 MinerU 深度路径接入（blocks/预览路径不落库）；失败降级保留原始坐标不阻塞入库。
    try:
        from src.core.ingestion.span_calibration import calibrate_new
        calibrate_new(pdf_path, [s for m in models for s in m.source_spans])
    except Exception:
        logger.warning("span 坐标校准失败，保留原始坐标入库", exc_info=True)

    number_to_id = {m.clause_number: m.clause_revision_id for m in models}
    edges = resolve_edges(raw_edges, number_to_id)

    type_dist: dict[str, int] = {}
    for m in models:
        type_dist[m.knowledge_type] = type_dist.get(m.knowledge_type, 0) + 1

    # reingest：入库前先删同 standard_no 的旧文档（否则唯一约束冲突）。
    # 收藏/批注绑 clause_key（= sha256(doc_id+no)，doc_id 变则 key 变——
    # 但旧文档删除时用户资产按 clause_key 留存，重解析后条款号一致即可在检索中重新关联）
    if reingest and same_no and same_no["doc_id"] != doc_id:
        from src.core.storage import clause_repo as _cr
        _cr.delete_document(same_no["doc_id"])

    # R1: 整个入库单事务（doc + 几何 + 条款 + FTS + 向量 + 边），任一步失败全回滚
    preface = [m for m in models if m.clause_number.startswith("前置")]
    appendix = [m for m in models if m.clause_number.startswith("附录")]
    normal = [m for m in models
              if not m.clause_number.startswith(("前置", "附录"))]
    # 入库自动查 CCS（官方渠道 cssn；失败静默降级本地表/无，不阻塞入库）
    tags = list(domain_tags or [])
    if doc_type == "standard":
        try:
            from src.core.knowledge.ccs_fetcher import fetch_ccs, ccs_to_tag
            ccs = fetch_ccs(standard_no, standard_name)
            tag = ccs_to_tag(ccs, standard_no)
            if tag and tag not in tags:
                tags.append(tag)
        except Exception:
            pass  # 网络/解析失败：无 CCS 标签，分类面板走兜底
    with write_transaction() as txn:
        clause_repo.insert_document(txn, {
            "doc_id": doc_id, "standard_no": standard_no, "standard_name": standard_name,
            "short_code": short_code or standard_no.replace(" ", "").replace("-", ""),
            "current_revision_id": f"rev_{ULID()}",
            "doc_type": doc_type, "legal_hierarchy": legal_hierarchy,
            "domain_tags": tags,
            "file_path": str(pdf_path.resolve()), "file_hash": file_hash,
        })
        clause_repo.insert_page_geometries(txn, doc_id, result["geometries"])
        n_normal = clause_repo.insert_clauses_in_txn(txn, normal)
        n_pre = clause_repo.insert_clauses_in_txn(txn, preface, content_type="前置说明")
        clause_repo.insert_clauses_in_txn(txn, appendix, content_type="附录")
        clause_repo.insert_edges_in_txn(txn, edges)

    # R8 运维日志：入库成功写 operation_log
    with write_transaction() as txn:
        txn.execute(
            "INSERT INTO operation_log (operation, target_type, target_id, detail)"
            " VALUES (?,?,?,?)",
            ("ingest", "doc", doc_id,
             json.dumps({"standard_no": standard_no, "clauses": len(models),
                         "edges": len(edges)}, ensure_ascii=False)))

    # OCR 数字回填（R58 补丁机制）：MinerU 文本层数字缺失时用 pypdf 还原打补丁
    backfilled = 0
    try:
        from src.core.ingestion.pypdf_backfill import backfill_document
        backfilled = backfill_document(doc_id, str(pdf_path))
    except Exception:
        backfilled = 0

    # reingest 的旧文档删除已在入库事务前完成（见上方 reingest 块）

    return {"status": "ok", "doc_id": doc_id,
            "reingested": bool(reingest and same_no),
            "pypdf_backfilled": backfilled,
            "total_clauses": n_normal - n_pre, "preface_clauses": n_pre,
            "evidence_edges": len(edges),
            "pages_parsed": len(result["geometries"]),
            "knowledge_type_distribution": type_dist}


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf_path", type=Path)
    ap.add_argument("--standard-no", required=True)
    ap.add_argument("--name", default="")
    ap.add_argument("--short-code", default=None)
    ap.add_argument("--doc-type", default="standard", choices=["standard", "法律法规"])
    ap.add_argument("--domain-tags", default="")
    ap.add_argument("--legal-hierarchy", default="GB")
    args = ap.parse_args(argv)
    out = run_full_ingest(
        args.pdf_path, args.standard_no, args.name or args.standard_no,
        args.short_code, args.doc_type,
        [t for t in args.domain_tags.split(",") if t], args.legal_hierarchy)
    print(json.dumps(out, ensure_ascii=False, indent=1), flush=True)
    # CLI 场景直接硬退出，避免解释器收尾被残留线程拖挂（worker 已自清理）
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0 if out.get("status") in ("ok", "duplicate", "standard_exists") else 1)


if __name__ == "__main__":
    sys.exit(main())
