# 契约增量 03 · 更新模块数据契约落地

> 日期：2026-08-24 ｜ 依据：pipeline/02-architecture-contract.md §2 数据契约 ｜ 红线流程：contract.md → test_contract.py → schema.sql（本次三件套同步落地）

## 1. 变更内容

schema.sql 追加两张新表（序号延续既有注释风格，落在索引区之前）：

| 序号 | 表 | 主键 | 关键约束 |
|---|---|---|---|
| 29 | `update_check_batch` 更新巡检批次表 | `batch_id TEXT PRIMARY KEY`（ULID 前缀 `upd_`，DDL 注释声明） | `trigger_type` CHECK 二枚举 manual/scheduled；`status` 缺省 pending，CHECK 五枚举 pending/running/paused/done/failed |
| 30 | `update_change_event` 标准变更事件表 | `change_id TEXT PRIMARY KEY`（ULID 前缀 `chg_`，DDL 注释声明） | `change_type` NOT NULL CHECK 五枚举 new_version/superseded/withdrawn/not_found/no_change；`current_legal_status` 可空 + 四枚举 effective/upcoming/superseded/withdrawn；`doc_id` 可空（公告命中但库内无此文档）；`batch_id` NOT NULL 外键 → update_check_batch ON DELETE CASCADE |

索引区追加两条（随表同生共死）：

```sql
CREATE INDEX IF NOT EXISTS idx_change_batch ON update_change_event(batch_id, change_type);
CREATE INDEX IF NOT EXISTS idx_change_doc ON update_change_event(doc_id);
```

tests/test_contract.py 追加 6 个契约用例：两表存在性、ULID 主键风格（TEXT PK + DDL 注释）、批次 trigger_type/status 枚举、事件 change_type 五枚举、legal_status 四枚举与 doc_id 双路径（NULL/回填）、batch_id 外键拒绝孤儿写入 + 删批次级联删事件。

## 2. 影响面

- **改动文件仅 3 个**：`src/core/storage/schema.sql`（+30 行 DDL/注释）、`tests/test_contract.py`（+6 用例）、本文档。其余一概未碰（server.py / App.tsx / sqlite_db.py 均原样——`init_schema` 走 executescript 全量执行，无需注册变更）。
- **存量零侵入**：全部 `IF NOT EXISTS` 幂等；不动既有 1~28 号表、FTS/VEC 虚拟表、SSE 事件与 API 契约。
- **解锁后续实现**：`src/core/update/change_repo.py`、`inspector.py` 的读写落点已就位；巡检写路径仍走 `write_queue`（operation_type=`'update_check'`），审计走 `event_log`（event_type=`'update/change_detected'`），本增量不引入新写通道。
- **复用项确认**：`doc_meta.doc_type` 无 CHECK → `'announcement'` 直接可用；`watch_list` 直接服务 F-14。
- **测试基线**：test_contract.py 由 7 → 13 个用例全绿；全量套件不低于基线 173 passed + 2 skipped。

## 3. 回滚方式

外键存在方向依赖，必须**先子后父**顺序执行：

```sql
DROP TABLE IF EXISTS update_change_event;   -- 子表先删，其两条 idx_change_* 索引随之消失
DROP TABLE IF EXISTS update_check_batch;    -- 父表后删
```

随后还原 `tests/test_contract.py` 的「更新模块数据契约」6 个用例区块即可回到本增量前状态；schema.sql 中删除 29/30 号表注释块与索引区两行等价于上述 DROP 的静态回滚。回滚不影响任何存量表数据。

## 4. 验证记录

- `.venv\Scripts\python.exe -m pytest tests/test_contract.py -q` → **13 passed**（7 存量 + 6 新增）
- 全量 `.venv\Scripts\python.exe -m pytest -q` → **189 passed, 2 skipped**，高于基线 173 passed + 2 skipped

---

# 契约增量 · 阶段六批次2 · 批量导入批次表（巡检侧最小版）

> 日期：2026-08-24 ｜ 依据：pipeline/06-bulk-ingest-design.md §4「落点与契约增量」｜ 红线流程：本文档 → test_contract.py → schema.sql

## 5. 变更内容

schema.sql 追加第 31 号表 `bulk_import_batch`（本批只建巡检侧需要的最小版）：

| 列 | 类型 | 约束/默认 |
|---|---|---|
| batch_id | TEXT PRIMARY KEY | ULID 前缀 `bul_`（DDL 注释声明） |
| batch_kind | TEXT | CHECK 二枚举 inspect/bulk_ingest（bulk_ingest 为批量导入编排预留） |
| trigger_type | TEXT | CHECK 二枚举 manual/scheduled |
| status | TEXT | DEFAULT 'pending'，CHECK 五枚举 pending/running/paused/done/failed |
| total/checked/red_count/yellow_count/green_count/gray_count | INTEGER | DEFAULT 0 |
| tier | TEXT | DEFAULT 'tier1'，CHECK 二枚举 tier0/tier1 |
| checkpoint_json | TEXT | 可空；断点续扫 {queue,done,captcha_pending,pause_reason} |
| started_at / finished_at / created_at | TEXT | 同本体风格（created_at DEFAULT datetime('now')） |

无新索引（最小版原则）；不动既有 1~30 号表与索引区。

## 6. 与 update_check_batch 的镜像锚行约定（inspector 落地语义）

- 巡检编排器（inspector.py）以 `bulk_import_batch(batch_kind='inspect')` 行为控制面记录
  （tier 分层 + checkpoint_json 断点 + 暂停原因）；
- 因 update_change_event.batch_id 外键冻结指向 update_check_batch（29 号表），巡检批次创建时
  在同一写事务内以**同值 batch_id** 在 update_check_batch 插入镜像锚行并同步进度/状态，
  保证 `update_change_event.batch_id == bul_ 批次 id` 直查可用、外键零改动；
- bulk_ingest 类批次不建锚行（其事件落点由后续批量导入批次定义）。

## 7. 影响面与回滚

- 改动文件仅 3 个：schema.sql（+20 行 DDL）、tests/test_contract.py（+3 用例）、本文档。
- 回滚：`DROP TABLE IF EXISTS bulk_import_batch;`（该表无子表引用，可独立删除），随后移除
  test_contract.py 的「批量导入批次表契约」3 个用例区块即回到本增量前状态。
- 测试基线：test_contract.py 由 13 → 16 个用例全绿；全量不低于 214 passed + 2 skipped。

## 8. 验证记录（批次2收口）

- `.venv\Scripts\python.exe -m pytest tests/test_contract.py -q` → **16 passed**（13 存量 + 3 新增）
- 全量 `.venv\Scripts\python.exe -m pytest -q` → **247 passed, 2 skipped**
  （批次2前基线 214 passed + 2 skipped；增量 = 契约 +3 与
  `tests/test_update_inspector.py` +30，只涨不跌达标）

---

# 契约增量 · 阶段六批次3 · 找标子模块（discover）

> 2026-08-24 ｜ 零 DDL、零既有端点/表改动：新增 `src/core/update/ccs_seed.json`（CCS 二级种子树，24 大类 × 3~8 子类，source=seed 待权威本体入库扩充）与 `src/core/update/discover.py`（classify 口语→CCS 路径/一轮追问 ≤3 问、search 经 transport 注入查网络渠道 drill_level≤3 否则 UPD-3002、download_later 待下载清单存 app_config 键 `'discover.download_later'`）；网络查询 mock 表驱动落 `tests/fixtures/discover_web.json`。验证：`tests/test_update_discover.py` 11 passed；全量 **258 passed + 2 skipped**（批次3前基线 247+2，只涨不跌）。
