"""T05 管线测试：切分/分型/边/坐标翻转（合成 fixture）+ 真实 middle.json 集成。"""
import json
from pathlib import Path

import pytest

from src.core.ingestion.pipeline import (
    MidItem, build_clause_models, load_middle_items, resolve_edges,
    split_items_into_clauses,
)
from src.core.knowledge.classifier import classify_clause, normalize_clause_number


def _mk_middle(tmp_path: Path) -> Path:
    """合成一份 2 页 middle.json：封面/前言 + 2 条款(跨页拼接) + 但书 + 表绑定 + 附录。"""
    mj = {
        "pdf_info": [
            {"page_idx": 0, "page_size": [595, 841],
             "para_blocks": [
                 {"type": "text", "bbox": [60, 700, 500, 740], "lines": [
                     {"spans": [{"type": "text", "content": "前  言"}]}]},
                 {"type": "text", "bbox": [60, 600, 500, 660], "lines": [
                     {"spans": [{"type": "text", "content": "本标准代替 GB 30871-2014。"}]}]},
             ],
             "discarded_blocks": [
                 {"type": "header", "bbox": [200, 20, 400, 40], "lines": [
                     {"spans": [{"type": "text", "content": "GB 30871—2022"}]}]}]},
            {"page_idx": 1, "page_size": [595, 841],
             "para_blocks": [
                 {"type": "text", "bbox": [60, 700, 530, 740], "lines": [
                     {"spans": [{"type": "text",
                                 "content": "5.2.1 动火作业应有专人监护，作业前应清除易燃物品。"}]}]},
                 {"type": "text", "bbox": [60, 650, 530, 690], "lines": [
                     {"spans": [{"type": "text",
                                 "content": "但节假日或夜间作业除外，应升级管理。"}]}]},
                 {"type": "table", "bbox": [60, 400, 530, 600], "blocks": [
                     {"type": "table_caption", "lines": [
                         {"spans": [{"type": "text", "content": "表 5.2.1 动火分级"}]}]},
                     {"type": "table_body", "lines": [
                         {"spans": [{"type": "table", "html": "<table><tr><td>级别</td></tr></table>"}]}]},
                 ]},
                 {"type": "text", "bbox": [60, 300, 530, 340], "lines": [
                     {"spans": [{"type": "text",
                                 "content": "5.2.2 动火分析合格标准：可燃气体浓度不大于 0.5%。"}]}]},
             ],
             "discarded_blocks": [
                 {"type": "page_number", "bbox": [280, 800, 320, 820], "lines": [
                     {"spans": [{"type": "text", "content": "2"}]}]}]},
        ]
    }
    p = tmp_path / "fake_middle.json"
    p.write_text(json.dumps(mj, ensure_ascii=False), encoding="utf-8")
    return p


def test_load_middle_items_drops_discarded(tmp_path):
    items, page_sizes = load_middle_items(_mk_middle(tmp_path))
    assert page_sizes[0] == (595.0, 841.0)
    texts = " ".join(i.text for i in items)
    assert "GB 30871—2022" not in texts, "页眉应被丢弃（R65/E4）"
    assert "动火作业" in texts
    kinds = [i.kind for i in items]
    assert "table" in kinds


def test_split_clauses_and_table_binding(tmp_path):
    items, page_sizes = load_middle_items(_mk_middle(tmp_path))
    clauses = split_items_into_clauses(items)
    numbers = [c.number for c in clauses]
    assert "5.2.1" in numbers and "5.2.2" in numbers
    c521 = next(c for c in clauses if c.number == "5.2.1")
    assert "但节假日" in "\n".join(c521.texts), "但书应拼接到母条款（E4 跨块合并）"
    assert c521.table_html and "<table>" in c521.table_html, "表 5.2.1 应绑定母条款（E5）"
    assert c521.table_summary == "动火分级"
    preface = [c for c in clauses if c.number.startswith("前置")]
    assert preface, "前言应成为前置说明"


def test_build_models_classification_and_edges(tmp_path):
    items, page_sizes = load_middle_items(_mk_middle(tmp_path))
    clauses = split_items_into_clauses(items)
    models, raw_edges = build_clause_models("d1", "GB T-2022", "standard", clauses, page_sizes)
    by_no = {m.clause_number: m for m in models}
    m521, m522 = by_no["5.2.1"], by_no["5.2.2"]
    assert m521.knowledge_type == "rule" and m521.modality == "应"
    assert m522.knowledge_type == "data", "含数值量纲应归 data 型"
    assert m522.modality is None, "'可燃气体'的'可'不应误判为模态"
    assert m521.exception and "节假日" in m521.exception
    assert m521.hierarchy_path == "5 > 5.2"
    # 坐标契约（v5 修正）：source_span 原样直存 MinerU bbox（PDF 底部原点，y 向上；
    # 页顶文本 y 接近页高）。前端 PdfViewer 直接 convertToViewportPoint(x, y)，禁止翻转。
    span = m521.source_spans[0]
    assert span.bbox == pytest.approx([60.0, 700.0, 530.0, 740.0])  # 原样直存，未翻转
    number_to_id = {m.clause_number: m.clause_revision_id for m in models}
    edges = resolve_edges(raw_edges, number_to_id)
    assert all(e[0] in ("reference_relation", "exception_relation") for e in edges)


def test_classifier_details():
    tc = classify_clause("高层民用建筑之间的防火间距不应小于13m", doc_type="standard")
    assert tc.knowledge_type == "data" and tc.modality == "不应"
    tc2 = classify_clause("经营者不得利用格式条款排除消费者权利", doc_type="法律法规")
    assert tc2.knowledge_type == "legal" and tc2.subject == "经营者"
    tc3 = classify_clause("本规范第5.2.1条规定了动火监护要求", doc_type="standard")
    assert "5.2.1" in tc3.cross_refs
    assert normalize_clause_number("05.02.01") == "5.2.1"


@pytest.mark.skipif(
    not Path("var/mineru_cli_out/GB30871-2022识别版/auto/GB30871-2022识别版_middle.json").exists(),
    reason="真实 MinerU 产物不存在（本机运行时自动启用）")
def test_real_middle_json_integration():
    items, page_sizes = load_middle_items(
        Path("var/mineru_cli_out/GB30871-2022识别版/auto/GB30871-2022识别版_middle.json"))
    assert len(items) > 100
    clauses = split_items_into_clauses(items)
    numbers = {c.number for c in clauses}
    assert "5.2.1" in numbers and "6.2" in numbers
    c521 = next(c for c in clauses if c.number == "5.2.1")
    assert "专人监护" in c521.texts[0]
