"""六路混合检索 + RRF 融合（T04，依据主计划 v4.3 第 8.3 节）。"""
from __future__ import annotations

import json
import logging
import re
import sqlite3
from typing import Any, Dict, List, Optional

from src.core.domain.models import ClauseRevisionModel, MODALITY_STRENGTH, SEARCH_CHANNELS
from src.core.retrieval import embedder
from src.core.storage.clause_repo import fetch_full_clause
from src.core.storage.sqlite_db import get_db_connection, load_vec_extension

logger = logging.getLogger(__name__)

RRF_K = 60
CHANNEL_WEIGHTS: Dict[str, float] = {
    "exact": 2.0, "fts": 1.0, "vec": 1.0,
    "modality": 0.8, "legal_element": 0.8, "behavior_scope": 1.2,
}

_CLAUSE_NO_RE = re.compile(r"(\d+\.[\d\.]+|第[一二三四五六七八九十百千]+条)")
_MODALTITY_RE = re.compile("严禁|禁止|不得|不应|不能|应当|必须|宜|可以|有权|鼓励|提倡|支持")

# 评测/门禁用：临时覆盖库路径（eval benchmark 对快照库跑，可复现、不依赖本机 %APPDATA%）
_DB_OVERRIDE: Any | None = None


def set_db_override(path: Any | None) -> None:
    """设置/清除检索库路径覆盖（None=恢复默认）。仅 eval/测试使用。"""
    global _DB_OVERRIDE
    _DB_OVERRIDE = path


def _conn():
    return get_db_connection(_DB_OVERRIDE)


def _seg(text: str) -> str:
    import jieba
    return " ".join(w.strip() for w in jieba.cut_for_search(text or "") if len(w.strip()) > 1)


def _fts_query(text: str) -> str:
    """构建 FTS5 MATCH 表达式：对每个分词加引号，避免点号/连字符等触发语法错误。"""
    import re as _re
    words = _seg(text).split()
    quoted = []
    for w in words:
        safe = _re.sub(r'[^\w\u4e00-\u9fff]', ' ', w)  # 只留字母数字/中文
        for tok in safe.split():
            if len(tok) > 1:
                quoted.append(f'"{tok}"')
    return " OR ".join(quoted)


def perform_hybrid_search(
    query: str,
    top_k: int = 5,
    include_superseded: bool = False,
    channels: Optional[List[str]] = None,
    modality_filter: Optional[str] = None,
    subject_filter: Optional[str] = None,
    behavior_scope_filter: Optional[str] = None,
    boost_bookmarks: bool = True,
    rerank: bool = True,
    rerank_n: int = 24,
    rerank_k: Optional[int] = None,
) -> List[ClauseRevisionModel]:
    """六路召回 + RRF(k=60) 融合 + 时效过滤。向量引擎离线时自动降级（R30）。"""
    conn = _conn()
    if channels is None:
        channels = list(SEARCH_CHANNELS)
    scores: Dict[str, float] = {}
    degraded = {"vector_engine": "offline"}

    # 通道 A: 条款号/法条号精确匹配
    if "exact" in channels:
        m = _CLAUSE_NO_RE.search(query)
        if m:
            exact_no = m.group(1)
            rows = conn.execute(
                "SELECT cr.clause_revision_id FROM clause_revision cr"
                " JOIN doc_meta dm ON dm.doc_id = cr.doc_id"
                " WHERE cr.clause_number = ? AND dm.legal_status != 'withdrawn'"
                " ORDER BY dm.legal_status", (exact_no,)).fetchall()
            for rank, row in enumerate(rows):
                scores[row[0]] = scores.get(row[0], 0.0) + CHANNEL_WEIGHTS["exact"] / (RRF_K + rank + 1)

    # 通道 B: FTS5 全文检索
    if "fts" in channels:
        fq = _fts_query(query)
        if fq:
            try:
                rows = conn.execute(
                    "SELECT clause_revision_id FROM clause_fts WHERE clause_fts MATCH ?"
                    " ORDER BY rank LIMIT 20", (fq,)).fetchall()
                for rank, row in enumerate(rows):
                    scores[row[0]] = scores.get(row[0], 0.0) + CHANNEL_WEIGHTS["fts"] / (RRF_K + rank + 1)
            except sqlite3.OperationalError as e:
                logger.warning("FTS 查询失败: %s", e)

    # 通道 C: sqlite-vec 向量检索
    if "vec" in channels and embedder.is_available():
        try:
            load_vec_extension(conn)
            q_emb = embedder.embed_query(query)
            rows = conn.execute(
                "SELECT clause_revision_id, distance FROM clause_vec"
                " WHERE embedding MATCH ? AND k = 20 ORDER BY distance",
                (json.dumps(q_emb),)).fetchall()
            for rank, row in enumerate(rows):
                scores[row[0]] = scores.get(row[0], 0.0) + CHANNEL_WEIGHTS["vec"] / (RRF_K + rank + 1)
            degraded["vector_engine"] = "ok"
        except Exception as e:  # noqa: BLE001
            logger.warning("向量检索降级: %s", e)

    # 通道 D: 模态召回
    if "modality" in channels and modality_filter:
        rows = conn.execute(
            "SELECT cr.clause_revision_id FROM clause_revision cr"
            " JOIN doc_meta dm ON dm.doc_id = cr.doc_id"
            " WHERE cr.modality = ? AND dm.legal_status = 'effective'",
            (modality_filter,)).fetchall()
        for rank, row in enumerate(rows):
            scores[row[0]] = scores.get(row[0], 0.0) + CHANNEL_WEIGHTS["modality"] / (RRF_K + rank + 1)

    # 通道 E: 法理要素召回 (义务主体)
    if "legal_element" in channels and subject_filter:
        rows = conn.execute(
            "SELECT clause_revision_id FROM clause_revision"
            " WHERE subject = ? AND knowledge_type = 'legal'", (subject_filter,)).fetchall()
        for rank, row in enumerate(rows):
            scores[row[0]] = scores.get(row[0], 0.0) + CHANNEL_WEIGHTS["legal_element"] / (RRF_K + rank + 1)

    # 通道 F: 行为客体召回 (合规审查专用)
    if "behavior_scope" in channels and behavior_scope_filter:
        fq = _fts_query(behavior_scope_filter)
        if fq:
            try:
                rows = conn.execute(
                    "SELECT clause_revision_id FROM clause_fts"
                    " WHERE behavior_scope_segmented MATCH ? ORDER BY rank LIMIT 20",
                    (fq,)).fetchall()
                for rank, row in enumerate(rows):
                    scores[row[0]] = scores.get(row[0], 0.0) + CHANNEL_WEIGHTS["behavior_scope"] / (RRF_K + rank + 1)
            except sqlite3.OperationalError as e:
                logger.warning("行为客体 FTS 查询失败: %s", e)

    # R25: 已收藏条款获得轻量排名加分 (+0.15)
    if boost_bookmarks and scores:
        try:
            from src.core.storage.user_data import bookmarked_clause_keys
            bm_keys = bookmarked_clause_keys()
        except Exception:
            bm_keys = set()
        if bm_keys:
            ph = ",".join("?" * len(scores))
            for cid, key in conn.execute(
                    f"SELECT clause_revision_id, clause_key FROM clause_revision"
                    f" WHERE clause_revision_id IN ({ph})", list(scores.keys())).fetchall():
                if key in bm_keys:
                    scores[cid] = scores.get(cid, 0.0) + 0.15

    # RRF 排序与时效过滤（rerank 开启时先取 rerank_n 候选，再裁到 top_k）
    cap = rerank_n if (rerank and rerank_n > top_k) else top_k
    sorted_cids = sorted(scores.keys(), key=lambda cid: scores[cid], reverse=True)
    results: List[ClauseRevisionModel] = []
    for cid in sorted_cids:
        if len(results) >= cap:
            break
        clause = fetch_full_clause(conn, cid)
        if clause is None:
            continue
        if not include_superseded and clause.legal_status == "superseded":
            continue
        results.append(clause)
    if rerank and rerank_n > top_k:
        results, rerank_debug = _rerank_results(query, results, rerank_k or top_k)
        _last_rerank_debug.update(rerank_debug)
    return results


# 最近一次 rerank 的调试信息（search_with_details 合并进 R31 debug）
_last_rerank_debug: dict[str, Any] = {}


def _protect_exception_clauses(kept: List[ClauseRevisionModel],
                               results: List[ClauseRevisionModel],
                               top_k: int) -> List[ClauseRevisionModel]:
    """例外条款保护（P1）：含但书/除外的条款被 rerank 挤出时强制保留。

    例外信息（但书/除外/另有规定）不可被 rerank 淘汰——漏例外=误导用户。
    """
    kept_ids = {c.clause_revision_id for c in kept}
    for r in results:
        if len(kept) >= top_k + 2:
            break
        if (r.exception or "") and r.clause_revision_id not in kept_ids:
            kept.append(r)
            kept_ids.add(r.clause_revision_id)
    return kept[:top_k]


def _rerank_results(query: str, results: List[ClauseRevisionModel],
                    top_k: int) -> tuple[List[ClauseRevisionModel], dict]:
    """Task 10.2 rerank 标准阶段：RRF 融合后 top-N → reranker → top-K。

    例外条款保护：含"但书/除外/另有规定"的条款若在候选中，强制保留进 top-K
    （例外信息不可被 reranker 挤掉，P1 准确性）。
    返回 (重排结果, 调试信息)。模型不可用/异常 → 原序 + rerank_offline=true。
    """
    debug: dict[str, Any] = {"rerank_offline": False, "rerank_score": {}}
    if len(results) <= 1:
        return results, debug
    try:
        from src.core.retrieval import reranker
        if not reranker.is_available():
            debug["rerank_offline"] = True
            debug["rerank_reason"] = reranker.offline_reason()
            return results[:top_k], debug
        texts = [(r.content_text or "")[:512] for r in results]
        scores = reranker.rerank(query, texts)  # 已按得分降序
        ordered = sorted(range(len(results)), key=lambda i: scores[i], reverse=True)
        debug["rerank_score"] = {results[i].clause_revision_id: round(scores[i], 4)
                                 for i in ordered}
        kept: List[ClauseRevisionModel] = [results[i] for i in ordered[:top_k]]
        # 例外条款保护：任何含但书的候选强制保留（若已被挤出）
        return _protect_exception_clauses(kept, results, top_k), debug
    except Exception as e:  # noqa: BLE001
        debug["rerank_offline"] = True
        debug["rerank_reason"] = str(e)
        return results[:top_k], debug


def extract_modality_from_query(query: str) -> Optional[str]:
    """从用户查询中提取模态词，用于通道 D 过滤。

    陷阱: "应该""可能会"等口语复合词会误命中单字模态词(应/可)，
    命中后检查相邻字符排除常见复合词。
    """
    _compound_next = {"应": "该", "可": "能", "宜": "于"}
    for word in sorted(MODALITY_STRENGTH.keys(), key=len, reverse=True):
        idx = query.find(word)
        while idx != -1:
            nxt = query[idx + len(word):idx + len(word) + 1]
            if word in _compound_next and nxt == _compound_next[word]:
                idx = query.find(word, idx + 1)
                continue
            return word
    return None


# R9 条件追问：指代词/过短问题判定（追问增强用）
_FOLLOWUP_MARKERS = ("那", "这", "它", "其", "上述", "该条款", "该条", "上面", "之前", "刚刚", "你")


def expand_query_with_history(query: str, history: list[dict] | None) -> str:
    """R9 条件追问检索增强：当前问过短、含指代词，或是在补充上一轮提问的回答时
    （以"是/对/在/属于/设备/车间/有"等开头），把原始问题并入检索词，避免脱靶。

    纯规则实现（零 LLM 消耗）：first_user + ' ' + current。
    """
    if not history:
        return query
    q = query.strip()
    short = len(q) < 4
    has_marker = any(m in query for m in _FOLLOWUP_MARKERS)
    starts_with_answer = q.startswith(("是", "对", "好", "在", "属于", "位于", "有",
                                       "不知道", "不清楚", "设备", "车间", "厂房",
                                       "生产", "装置区", "密度", "大概", "差不多",
                                       "就", "应该", "可能"))
    if not (short or has_marker or starts_with_answer):
        return query
    first_user = ""
    for turn in history:
        if turn.get("role") == "user":
            first_user = (turn.get("content") or "").strip()
            break
    if not first_user:
        return query
    if first_user == q:
        return q
    return f"{first_user} {q}"


def expand_evidence_chain(conn: sqlite3.Connection,
                          seed_ids: list[str],
                          max_hops: int = 1,
                          limit: int = 3) -> list[dict]:
    """R5a 证据链扩展：沿 evidence_edge 扩 1~2 跳，防例外/但书/引用遗漏。

    返回 [{clause(模型), expanded_from, edge_type}]，仅沿 active 边。
    """
    expanded: list[dict] = []
    seen = set(seed_ids)
    frontier = list(seed_ids)
    for _hop in range(max_hops):
        if not frontier or len(expanded) >= limit:
            break
        placeholders = ",".join("?" * len(frontier))
        rows = conn.execute(
            f"SELECT edge_type, source_clause_id, target_clause_id FROM evidence_edge"
            f" WHERE status='active' AND source_clause_id IN ({placeholders})",
            frontier).fetchall()
        next_frontier = []
        for r in rows:
            for cid in (r["target_clause_id"],):
                if cid in seen:
                    continue
                seen.add(cid)
                clause = fetch_full_clause(conn, cid)
                if clause is None:
                    continue
                expanded.append({"clause": clause,
                                 "expanded_from": r["source_clause_id"],
                                 "edge_type": r["edge_type"]})
                next_frontier.append(cid)
                if len(expanded) >= limit:
                    break
        frontier = next_frontier
    return expanded


def search_with_details(query: str, **kwargs: Any) -> Dict[str, Any]:
    """R31 检索可解释性：返回结果 + 调试元数据。"""
    modality_filter = kwargs.pop("modality_filter", None)
    if modality_filter is None:
        modality_filter = extract_modality_from_query(query)
    expand_chain = kwargs.pop("expand_chain", True)
    results = perform_hybrid_search(query, modality_filter=modality_filter, **kwargs)
    expanded: list[dict] = []
    if expand_chain and results:
        expanded = expand_evidence_chain(
            conn := _conn(),
            [r.clause_revision_id for r in results], max_hops=1)
    return {
        "results": results,
        "expanded": expanded,
        "debug": {
            "modality_filter": modality_filter,
            "vector_engine": "ok" if embedder.is_available() else "offline",
            "channels": kwargs.get("channels") or list(SEARCH_CHANNELS),
            "result_count": len(results),
            "expanded_count": len(expanded),
            "rerank": dict(_last_rerank_debug),
        },
    }
