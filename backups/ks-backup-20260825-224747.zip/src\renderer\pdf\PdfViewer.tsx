// PDF 原件穿透区（R7 / v4.3）：连续滚动模式
// - 所有页垂直排列（连续阅读，非单页翻页）
// - 高亮用 pdfjs viewport.convertToViewportRectangle 变换
// - 跳转时高亮块滚动到视口垂直居中
import { useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.js?url';
import { anchorClauseNumber } from './highlightAnchor';
import type { AnchorRect, AnchorToken } from './highlightAnchor';

pdfjsLib.GlobalWorkerOptions.workerSrc = workerUrl;

export interface HighlightSpan {
  page_number: number;
  bbox: [number, number, number, number];
  cid?: string;
  /** 条款号（如 4.1）：存在时只框该条款号标题（短而唯一），缺省回退原 bbox 单框 */
  clauseNumber?: string;
}

interface Box { left: number; top: number; w: number; h: number; cid?: string }

interface Props {
  pdfBytes: ArrayBuffer | null;
  jumpToPage: number | null;
  highlights: HighlightSpan[];
  onSpanHover?: (cid: string, x: number, y: number) => void;
  // 目录/任意跳转的目标页：渲染队列优先渲染该页（否则等前序页渲染完，30 页 PDF 数秒才跳）
  priorityPage?: number | null;
}

export default function PdfViewer({ pdfBytes, jumpToPage, highlights, onSpanHover, priorityPage }: Props) {
  const docRef = useRef<pdfjsLib.PDFDocumentProxy | null>(null);
  // 记录 docRef 对应的 pdfBytes 引用：渲染前校验，防止"旧 doc 渲染到新页容器"（换文档后需关开才显示）
  const docBytesRef = useRef<ArrayBuffer | null>(null);
  const pageEls = useRef<Map<number, HTMLDivElement>>(new Map());
  const [pageCount, setPageCount] = useState(0);
  const [zoom, setZoom] = useState(1.25);
  const [rendered, setRendered] = useState<number[]>([]);
  const [boxes, setBoxes] = useState<Record<number, Box[]>>({});
  // boxes 镜像 ref：渲染 effect 以合并语义更新（旧引用黄框保留，仅换文档时清空），
  // 修复"连续点两条引用时前一条黄框消失"（2026-08-24）
  const boxesRef = useRef<Record<number, Box[]>>({});
  const renderToken = useRef(0);
  const renderedRef = useRef<Set<number>>(new Set());
  useEffect(() => { renderedRef.current = new Set(); }, [zoom]); // 缩放变化需全量重渲染
  // 文本页自动方向纠正：按文本基线的旋转角度检测 90/180/270 度倒置页并自动补偿（无需手工按钮）
  const orientRef = useRef<Record<number, number>>({});
  const detectOrient = async (page: pdfjsLib.PDFPageProxy): Promise<number> => {
    try {
      const tc = await page.getTextContent();
      const buckets: Record<number, number> = { 0: 0, 90: 0, 180: 0, 270: 0 };
      let cnt = 0;
      for (const it of tc.items as any[]) {
        if (!it.transform) continue;
        const a = it.transform[0], b = it.transform[1];
        if (Math.abs(a) < 1e-9 && Math.abs(b) < 1e-9) continue;
        const norm = ((Math.round(Math.atan2(b, a) * 180 / Math.PI) % 360) + 360) % 360;
        const key = norm === 180 ? 180 : (norm === 90 || norm === 270) ? (norm === 90 ? 90 : 270) : 0;
        buckets[key] = (buckets[key] || 0) + 1;
        cnt++;
      }
      if (cnt < 10) return 0; // 无文本层或文本太少（纯扫描页）无法检测，保持原样
      let best = 0, bestN = 0;
      for (const k of [0, 90, 180, 270]) if (buckets[k] > bestN) { bestN = buckets[k]; best = k; }
      // 仅当绝大多数文本（≥90%）一致倾斜时才补偿，避免混合版面/表格页误判
      if (best === 0 || bestN < cnt * 0.9) return 0;
      // 把文本转到正立：180 补 180；90 补 270；270 补 90
      return best === 180 ? 180 : (360 - best) % 360;
    } catch { return 0; }
  };

  // 加载文档（序列化：只有最新一次加载生效；旧 doc 延迟到新 doc 就绪后再销毁，
  // 避免销毁在途渲染的 page 导致 pdfjs Transport destroyed → 后续加载永久 pending（卡死））
  const loadSeq = useRef(0);
  useEffect(() => {
    const seq = ++loadSeq.current;
    let cancelled = false;
    renderedRef.current = new Set();
    if (!pdfBytes) {
      setPageCount(0); setRendered([]); setBoxes({}); boxesRef.current = {};
      docBytesRef.current = null;
      return;
    }
    (async () => {
      try {
        const task = pdfjsLib.getDocument({ data: pdfBytes.slice(0) });
        const doc = await task.promise;
        if (cancelled || seq !== loadSeq.current) { doc.destroy(); return; }
        const old = docRef.current;
        docRef.current = doc;
        docBytesRef.current = pdfBytes;   // 绑定当前 bytes 引用（渲染前校验用）
        orientRef.current = {}; // 换文档必须清空方向缓存（页号会在不同文档间复用）
        setPageCount(doc.numPages);
        setRendered([]); setBoxes({}); boxesRef.current = {};
        // 清掉所有旧画布（换文档后页容器复用，杜绝上一个文档残留像素）
        pageEls.current.forEach((el) => {
          el.querySelector('canvas')?.remove();
          el.style.width = ''; el.style.height = '';
        });
        // 旧 doc 延迟销毁（给在途渲染一帧时间退出）
        if (old) setTimeout(() => { try { old.destroy(); } catch { /* 已销毁 */ } }, 300);
      } catch (e) { console.error('PDF 加载失败', e); }
    })();
    return () => { cancelled = true; };
  }, [pdfBytes]);

  // 分批渲染所有页（每帧 2 页，避免卡死）
  useEffect(() => {
    const doc = docRef.current;
    // 关键校验：docRef 必须对应当前 pdfBytes（换文档时旧 doc 可能尚未被销毁/替换，
    // 若用旧 doc 渲染到新页容器 → 画面空白/错乱）。校验失败安排一次重试兜底，
    // 防止加载完成早于本 effect 触发导致永远跳过（白屏卡死）。
    if (!doc || pageCount === 0 || docBytesRef.current !== pdfBytes) {
      const t = setTimeout(() => setRendered((r) => [...r]), 200);
      return () => clearTimeout(t);
    }
    const token = ++renderToken.current;
    let stop = false;
    (async () => {
      const done: number[] = [];
      // 只画当前证据的高亮：不再从旧的 boxes 合并（旧法会让多个引用/跨时间线的框累积）。
      // 点新引用时旧框清除，只保留当前条款的框（用户只需提醒"这一条在哪"）。
      const boxMap: Record<number, Box[]> = {};
      // 高亮页 + priorityPage（目录点击）优先渲染（引用/目录跳转快速显示），其余按序补齐
      const hlPages = [...new Set(highlights.map((s) => s.page_number))];
      if (priorityPage && priorityPage >= 1 && priorityPage <= pageCount
          && !hlPages.includes(priorityPage)) {
        hlPages.push(priorityPage);
      }
      const order = [...hlPages];
      for (let n = 1; n <= pageCount; n++) {
        if (!order.includes(n)) order.push(n);
      }
      for (const n of order) {
        if (stop || token !== renderToken.current) return;
        const hsNow = highlights.filter((s) => s.page_number === n);
        // 已渲染且本页无高亮：跳过重渲染（避免每次点引用全量重画造成的抖动/乱跳）
        if (renderedRef.current.has(n) && hsNow.length === 0) continue;
        try {
          const page = await doc.getPage(n);
          const container = pageEls.current.get(n);
          // 宽度适配：纵向连续阅读，页面宽度不超过容器（不产生横向滚动）
          if (orientRef.current[n] === undefined) {
            orientRef.current[n] = await detectOrient(page);
          }
          const extra = orientRef.current[n] || 0;
          const rot = (page.rotate + extra) % 360;
          const baseW = page.getViewport({ scale: 1, rotation: rot }).width;
          const scrollEl = container?.parentElement;
          const availW = (scrollEl ? scrollEl.clientWidth : 900) - 8;
          const scale = Math.max(0.5, Math.min(zoom, availW / baseW));
          const viewport = page.getViewport({ scale, rotation: rot });
          if (container) {
            container.dataset.rot = String(rot);
            container.dataset.extra = String(extra);
            container.dataset.rotate = String(page.rotate);
            container.style.width = viewport.width + 'px';
            container.style.height = viewport.height + 'px';
            let canvas = container.querySelector('canvas') as HTMLCanvasElement | null;
            if (!canvas) {
              canvas = document.createElement('canvas');
              container.appendChild(canvas);
            }
            canvas.width = viewport.width;
            canvas.height = viewport.height;
            canvas.style.width = viewport.width + 'px';
            canvas.style.height = viewport.height + 'px';
            await page.render({ canvasContext: canvas.getContext('2d')!, viewport }).promise;
          }
          const hs = highlights.filter((s) => s.page_number === n);
          // bbox 契约（v5 实测修复）：MinerU middle.json 的 bbox 是 **PDF 底部原点**（左下，y 向上，
          // 页顶文本 y≈页高），pipeline 原样直存。pdfjs convertToViewportPoint 同样期望
          // PDF 底部原点坐标 —— 直接传入即可，**禁止再做 H−y 翻转**（会双重翻转导致黄标镜像）。
          //
          // 内容锚定（2026-08-25 改造）：不再"几何邻域 1.2x 加宽取并集"（旧法跨条/跨表疯涨）。
          // 文本项坐标同为 PDF 底部原点（与 bbox 同系），仍只经 convertToViewportRectangle 转换，
          // 禁止再做 H−y 翻转。
          const pageBoxes: Box[] = [];
          if (hs.length) {
            let items: any[] | null = null;
            try {
              const tc = await page.getTextContent();
              items = (tc.items as any[]).filter((it) => it.str && it.str.trim().length > 0);
            } catch { /* 无文本层：items=null 走回退 */ }
            // 文本项统一转成带 viewport 矩形的 token，供"条款号匹配"使用
            let tokens: AnchorToken[] | null = null;
            if (items && items.length) {
              tokens = items.map((it) => {
                const ir = viewport.convertToViewportRectangle([
                  it.transform[4], it.transform[5],
                  it.transform[4] + (it.width || 0), it.transform[5] + (it.height || 0),
                ]);
                return {
                  str: it.str,
                  left: Math.min(ir[0], ir[2]), top: Math.min(ir[1], ir[3]),
                  right: Math.max(ir[0], ir[2]), bottom: Math.max(ir[1], ir[3]),
                };
              });
            }
            for (const s of hs) {
              const [x1, y1, x2, y2] = s.bbox;
              const rr = viewport.convertToViewportRectangle(
                [Math.min(x1, x2), Math.min(y1, y2), Math.max(x1, x2), Math.max(y1, y2)]);
              const bboxRect: AnchorRect = {
                left: Math.min(rr[0], rr[2]), top: Math.min(rr[1], rr[3]),
                right: Math.max(rr[0], rr[2]), bottom: Math.max(rr[1], rr[3]),
              };
              // 只框条款号（短而唯一，数字几乎不会被 OCR 弄花）；无文本层/未命中 → 回退原 bbox 单框。
              // 不再做整段正文匹配 / 1.2x 并集 / 逐行——那些在扫描件上易错位、易吞表。
              let out: AnchorRect | null = null;
              if (tokens && s.clauseNumber && s.clauseNumber.trim()) {
                out = anchorClauseNumber(tokens, s.clauseNumber);
              }
              // 条款号匹配失败时：框住条款区域顶部第一条文字行（标题所在），比整段 bbox 更聚焦
              if (!out && tokens) {
                let best: AnchorRect | null = null;
                for (const t of tokens) {
                  if (t.bottom >= bboxRect.top && t.top <= bboxRect.bottom) {
                    if (!best || t.top < best.top) best = { left: t.left, top: t.top, right: t.right, bottom: t.bottom };
                  }
                }
                if (best) out = best;
              }
              if (!out) out = bboxRect;
              pageBoxes.push({ left: out.left, top: out.top, w: out.right - out.left, h: out.bottom - out.top, cid: s.cid });
            }
          }
          if (pageBoxes.length) boxMap[n] = pageBoxes;
          renderedRef.current.add(n);
          done.push(n);
        } catch (e) {
          // 单页渲染失败：清掉该页画布，避免残留上一文档的像素
          const c = pageEls.current.get(n)?.querySelector('canvas');
          if (c) c.getContext('2d')?.clearRect(0, 0, c.width, c.height);
        }
        setRendered([...done]);
        if (Object.keys(boxMap).length) { setBoxes(boxMap); boxesRef.current = boxMap; }
        // page.render 的 await 本身已让步主线程；不再额外等待（后台标签页定时器会被节流）
      }
    })();
    return () => { stop = true; };
  }, [pageCount, zoom, pdfBytes, highlights, priorityPage]);

  // 跳页：等目标页渲染后滚动到视口垂直居中（黄标未渲染时反复轮询，避免跳到页首）
  // 用 behavior:'auto'（即时）替代 'smooth'——smooth 在大页距下要滚几秒，感知上"点一下好几秒才跳"（2026-08-23 修）
  useEffect(() => {
    if (!jumpToPage) return;
    const waitFor = (attempt: number) => {
      const el = pageEls.current.get(jumpToPage);
      const hl = el?.querySelector('.pdf-highlight') as HTMLElement | null;
      const target = hl ?? el;
      if (target) {
        // 已在视口中部附近就不再滚动（避免多轮 setState 触发反复滚动 = 乱跳）
        const r = target.getBoundingClientRect();
        const cy = r.top + r.height / 2;
        if (Math.abs(cy - window.innerHeight / 2) > 150) {
          target.scrollIntoView({ block: 'center', behavior: 'auto' });
        }
        return;
      }
      if (attempt < 50) {
        setTimeout(() => waitFor(attempt + 1), 100);
      } else if (el) {
        el.scrollIntoView({ block: 'center', behavior: 'auto' });
      }
    };
    waitFor(0);
  }, [jumpToPage, boxes, rendered]);

  if (!pdfBytes) {
    return (
      <div className="pdf-placeholder">
        <div className="pdf-placeholder-icon">📖</div>
        <div className="pdf-placeholder-title">PDF 原件证据穿透区</div>
        <div className="pdf-placeholder-sub">点击回答中的引用，自动翻页并用黄框圈出原文位置</div>
      </div>
    );
  }

  return (
    <div className="pdf-outer">
      <div className="pdf-toolbar">
        <span className="pdf-pagecount">{pageCount > 0 ? `共 ${pageCount} 页` : '加载中…'}</span>
        <span>连续阅读</span>
        <div className="pdf-zoom-group">
          <button onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))} title="缩小">−</button>
          <span className="pdf-zoom-label">{Math.round(zoom * 100)}%</span>
          <button onClick={() => setZoom((z) => Math.min(3, z + 0.25))} title="放大">＋</button>
        </div>
      </div>
      <div className="pdf-scroll">
        {Array.from({ length: pageCount }, (_, i) => i + 1).map((n) => (
          <div key={n}
            ref={(el) => { if (el) pageEls.current.set(n, el); }}
            className="pdf-page">
            {(boxes[n] || []).map((b, i) => (
              <div key={i} className="pdf-highlight"
                style={{ left: b.left, top: b.top, width: b.w, height: b.h }}
                onMouseOver={(e) => { if (b.cid) onSpanHover?.(b.cid, e.clientX, e.clientY); }}
                onMouseOut={() => onSpanHover?.('', 0, 0)} />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
